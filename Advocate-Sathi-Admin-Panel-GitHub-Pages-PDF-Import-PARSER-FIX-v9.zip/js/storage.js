// Advocate Sathi - Local Storage & Data Store Layer
// 100% on-device / in-browser persistent data management. Zero telemetry or network requests.

const STORAGE_KEYS = {
  ACTS: 'advocate_sathi_acts_v1',
  SECTIONS: 'advocate_sathi_sections_v1',
  AUDIT: 'advocate_sathi_audit_v1',
  SETTINGS: 'advocate_sathi_settings_v1'
};

class AdvocateStorage {
  constructor() {
    this.init();
  }

  init() {
    if (!localStorage.getItem(STORAGE_KEYS.ACTS)) {
      this.resetToSeedData();
    }
  }

  // --- ACTS MANAGEMENT ---
  getActs() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.ACTS);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      console.error('Error reading acts:', e);
      return [];
    }
  }

  getActByCode(code) {
    if (!code) return null;
    return this.getActs().find(a => a.code.toUpperCase() === code.toUpperCase()) || null;
  }

  saveAct(actData, isEdit = false) {
    const acts = this.getActs();
    const cleanCode = actData.code.trim().toUpperCase();

    // Check duplicate code if adding new
    if (!isEdit && acts.some(a => a.code.toUpperCase() === cleanCode)) {
      throw new Error(`अधिनियम कोड '${cleanCode}' पहले से मौजूद है। कृपया भिन्न कोड दर्ज करें।`);
    }

    const cleanAct = {
      ...actData,
      code: cleanCode,
      year: parseInt(actData.year) || new Date().getFullYear(),
      totalChapters: parseInt(actData.totalChapters) || 0,
      totalSections: parseInt(actData.totalSections) || 0,
      updatedAt: new Date().toISOString()
    };

    let updatedActs;
    if (isEdit) {
      updatedActs = acts.map(a => a.code.toUpperCase() === cleanCode ? cleanAct : a);
      this.logAction('ACT_UPDATED', `अधिनियम '${cleanAct.hindiShortName}' अद्यतन किया गया`);
    } else {
      cleanAct.createdAt = new Date().toISOString();
      updatedActs = [...acts, cleanAct];
      this.logAction('ACT_CREATED', `नया अधिनियम '${cleanAct.hindiShortName}' जोड़ा गया`);
    }

    localStorage.setItem(STORAGE_KEYS.ACTS, JSON.stringify(updatedActs));
    return cleanAct;
  }

  deleteAct(code) {
    const acts = this.getActs();
    const cleanCode = code.trim().toUpperCase();
    const target = acts.find(a => a.code.toUpperCase() === cleanCode);
    if (!target) return false;

    const remaining = acts.filter(a => a.code.toUpperCase() !== cleanCode);
    localStorage.setItem(STORAGE_KEYS.ACTS, JSON.stringify(remaining));

    // Also delete or uncouple associated sections
    const sections = this.getSections();
    const remainingSections = sections.filter(s => s.actCode.toUpperCase() !== cleanCode);
    localStorage.setItem(STORAGE_KEYS.SECTIONS, JSON.stringify(remainingSections));

    this.logAction('ACT_DELETED', `अधिनियम '${target.hindiShortName}' और इसकी धाराएं हटाई गईं`);
    return true;
  }

  // --- SECTIONS MANAGEMENT ---
  getSections(filter = {}) {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.SECTIONS);
      let list = raw ? JSON.parse(raw) : [];

      if (filter.actCode) {
        list = list.filter(s => s.actCode.toUpperCase() === filter.actCode.toUpperCase());
      }

      if (filter.status) {
        list = list.filter(s => s.verificationStatus === filter.status);
      }

      if (filter.query) {
        const q = filter.query.toLowerCase().trim();
        list = list.filter(s => 
          (s.sectionNumber && s.sectionNumber.toLowerCase().includes(q)) ||
          (s.officialHeading && s.officialHeading.toLowerCase().includes(q)) ||
          (s.officialHeadingHindi && s.officialHeadingHindi.toLowerCase().includes(q)) ||
          (s.simpleExplanationHindi && s.simpleExplanationHindi.toLowerCase().includes(q)) ||
          (s.officialTextOrApprovedSummary && s.officialTextOrApprovedSummary.toLowerCase().includes(q)) ||
          (s.correspondingSection && s.correspondingSection.toLowerCase().includes(q))
        );
      }

      if (filter.bailable !== undefined && filter.bailable !== '') {
        list = list.filter(s => s.bailableStatus && s.bailableStatus.includes(filter.bailable));
      }

      if (filter.cognizable !== undefined && filter.cognizable !== '') {
        list = list.filter(s => s.cognizableStatus && s.cognizableStatus.includes(filter.cognizable));
      }

      return list;
    } catch (e) {
      console.error('Error reading sections:', e);
      return [];
    }
  }

  getSectionById(recordId) {
    if (!recordId) return null;
    return this.getSections().find(s => s.recordId === recordId) || null;
  }

  saveSection(sectionData, isEdit = false) {
    const sections = this.getSections();
    const act = this.getActByCode(sectionData.actCode);
    if (!act) {
      throw new Error(`अमान्य अधिनियम कोड: '${sectionData.actCode}'`);
    }

    const secNum = sectionData.sectionNumber.trim();
    if (!secNum) {
      throw new Error("धारा संख्या अनिवार्य है।");
    }

    const recordId = isEdit && sectionData.recordId 
      ? sectionData.recordId 
      : `${sectionData.actCode.toLowerCase()}_sec_${secNum.replace(/[^a-zA-Z0-9]/g, '_').toLowerCase()}_${Date.now()}`;

    // Ensure safe default verification status (NEVER default to VERIFIED or PUBLISHED)
    let status = sectionData.verificationStatus || 'DRAFT';
    if (!isEdit && (status === 'VERIFIED' || status === 'PUBLISHED')) {
      status = 'DRAFT'; // Force DRAFT on new entries unless through explicit review flow
    }

    const cleanSection = {
      recordId,
      actCode: act.code,
      officialActTitle: act.englishName,
      shortName: act.hindiShortName,
      actYear: act.year,
      sectionNumber: secNum,
      officialHeading: sectionData.officialHeading || `Section ${secNum}`,
      officialHeadingHindi: sectionData.officialHeadingHindi || `धारा ${secNum}`,
      officialTextOrApprovedSummary: sectionData.officialTextOrApprovedSummary || "",
      simpleExplanationHindi: sectionData.simpleExplanationHindi || "",
      keyElements: Array.isArray(sectionData.keyElements) 
        ? sectionData.keyElements 
        : (sectionData.keyElements ? sectionData.keyElements.split('\n').filter(x => x.trim()) : []),
      punishmentText: sectionData.punishmentText || "प्रावधान के अनुसार",
      bailableStatus: sectionData.bailableStatus || "लागू नहीं",
      cognizableStatus: sectionData.cognizableStatus || "लागू नहीं",
      trialCourt: sectionData.trialCourt || "संबद्ध क्षेत्राधिकारी न्यायालय",
      compoundableStatus: sectionData.compoundableStatus || "लागू नहीं",
      commencementStatus: sectionData.commencementStatus || act.commencementStatus || "IN_FORCE",
      effectiveFrom: sectionData.effectiveFrom || act.commencementDate || null,
      effectiveTo: sectionData.effectiveTo || null,
      sourceTitle: sectionData.sourceTitle || act.sourceTitle || "Official Gazette",
      officialSourceUrl: sectionData.officialSourceUrl || act.officialSourceUrl || null,
      sourcePublicationOrGazetteDate: sectionData.sourcePublicationOrGazetteDate || act.enactmentDate || null,
      lastVerifiedAt: status === 'VERIFIED' ? (sectionData.lastVerifiedAt || new Date().toISOString().split('T')[0]) : null,
      verificationStatus: status,
      correspondingSection: sectionData.correspondingSection || "",
      crossReferenceType: sectionData.crossReferenceType || "CORRESPONDING_PROVISION",
      applicabilityNotes: sectionData.applicabilityNotes || "1 जुलाई 2024 के आपराधिक संक्रमण नियम लागू होंगे।",
      proceduralCaveat: sectionData.proceduralCaveat || "यह प्रविष्टि सामान्य विधिक जानकारी हेतु है; यह अदालत का निर्णय या अधिवक्ता की राय नहीं है।",
      reviewNotes: sectionData.reviewNotes || "",
      updatedAt: new Date().toISOString()
    };

    let updatedSections;
    const existingIndex = sections.findIndex(s => s.recordId === recordId);
    if (existingIndex >= 0) {
      updatedSections = [...sections];
      updatedSections[existingIndex] = cleanSection;
      this.logAction('SECTION_UPDATED', `${act.code} धारा ${secNum} अद्यतन की गई (${status})`);
    } else {
      cleanSection.createdAt = new Date().toISOString();
      updatedSections = [...sections, cleanSection];
      this.logAction('SECTION_CREATED', `${act.code} धारा ${secNum} जोड़ी गई (${status})`);
    }

    localStorage.setItem(STORAGE_KEYS.SECTIONS, JSON.stringify(updatedSections));
    return cleanSection;
  }

  deleteSection(recordId) {
    const sections = this.getSections();
    const target = sections.find(s => s.recordId === recordId);
    if (!target) return false;

    const remaining = sections.filter(s => s.recordId !== recordId);
    localStorage.setItem(STORAGE_KEYS.SECTIONS, JSON.stringify(remaining));
    this.logAction('SECTION_DELETED', `${target.actCode} धारा ${target.sectionNumber} हटाई गई`);
    return true;
  }

  updateSectionStatus(recordId, newStatus, reviewerNotes = "", officialUrl = "") {
    const sections = this.getSections();
    const section = sections.find(s => s.recordId === recordId);
    if (!section) throw new Error("धारा नहीं मिली।");

    section.verificationStatus = newStatus;
    section.updatedAt = new Date().toISOString();
    if (reviewerNotes) section.reviewNotes = reviewerNotes;
    if (officialUrl) section.officialSourceUrl = officialUrl;

    if (newStatus === 'VERIFIED') {
      section.lastVerifiedAt = new Date().toISOString().split('T')[0];
    }

    localStorage.setItem(STORAGE_KEYS.SECTIONS, JSON.stringify(sections));
    this.logAction('STATUS_CHANGED', `${section.actCode} धारा ${section.sectionNumber} स्थिति: ${newStatus}`);
    return section;
  }

  // --- STATS COMPUTATION ---
  getStats() {
    const acts = this.getActs();
    const sections = this.getSections();

    const counts = {
      totalActs: acts.length,
      totalSections: sections.length,
      drafts: 0,
      needsReview: 0,
      verified: 0,
      published: 0
    };

    sections.forEach(s => {
      switch (s.verificationStatus) {
        case 'DRAFT': counts.drafts++; break;
        case 'NEEDS_REVIEW': counts.needsReview++; break;
        case 'VERIFIED': counts.verified++; break;
        case 'PUBLISHED': counts.published++; break;
        default: counts.drafts++; break;
      }
    });

    return counts;
  }

  // --- AUDIT LOG ---
  logAction(type, description) {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.AUDIT);
      const list = raw ? JSON.parse(raw) : [];
      list.unshift({
        id: 'audit_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        timestamp: new Date().toISOString(),
        type,
        description
      });
      // Keep last 100 entries
      localStorage.setItem(STORAGE_KEYS.AUDIT, JSON.stringify(list.slice(0, 100)));
    } catch (e) {
      console.warn('Could not log audit:', e);
    }
  }

  getAuditLog() {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.AUDIT);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  // --- RESET & BACKUP ---
  resetToSeedData() {
    const acts = typeof window !== 'undefined' && window.INITIAL_ACTS ? window.INITIAL_ACTS : [];
    const sections = typeof window !== 'undefined' && window.INITIAL_SECTIONS ? window.INITIAL_SECTIONS : [];

    localStorage.setItem(STORAGE_KEYS.ACTS, JSON.stringify(acts));
    localStorage.setItem(STORAGE_KEYS.SECTIONS, JSON.stringify(sections));
    this.logAction('RESET_SEED', 'डेटाबेस को प्रारंभिक आधिकारिक रिकॉर्ड पर रीसेट किया गया');
    return true;
  }

  clearAllData() {
    localStorage.setItem(STORAGE_KEYS.ACTS, JSON.stringify([]));
    localStorage.setItem(STORAGE_KEYS.SECTIONS, JSON.stringify([]));
    this.logAction('CLEAR_ALL', 'सभी स्थानीय डेटा रिक्त किया गया');
  }

  exportFullBackup() {
    return {
      version: "1.0",
      appName: "Advocate Sathi",
      exportedAt: new Date().toISOString(),
      acts: this.getActs(),
      sections: this.getSections(),
      audit: this.getAuditLog()
    };
  }

  restoreBackup(backupData) {
    if (!backupData || !Array.isArray(backupData.acts) || !Array.isArray(backupData.sections)) {
      throw new Error("अमान्य बैकअप फाइल। JSON संरचना में acts और sections सूचियां अनिवार्य हैं।");
    }

    localStorage.setItem(STORAGE_KEYS.ACTS, JSON.stringify(backupData.acts));
    localStorage.setItem(STORAGE_KEYS.SECTIONS, JSON.stringify(backupData.sections));
    if (backupData.audit && Array.isArray(backupData.audit)) {
      localStorage.setItem(STORAGE_KEYS.AUDIT, JSON.stringify(backupData.audit));
    }

    this.logAction('RESTORE_BACKUP', `बैकअप पुनर्स्थापित किया गया (${backupData.acts.length} अधिनियम, ${backupData.sections.length} धाराएं)`);
    return { actsCount: backupData.acts.length, sectionsCount: backupData.sections.length };
  }
}

// Global instance
window.advocateStore = new AdvocateStorage();
