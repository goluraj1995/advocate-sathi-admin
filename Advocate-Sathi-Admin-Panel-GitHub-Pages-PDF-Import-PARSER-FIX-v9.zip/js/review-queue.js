// Advocate Sathi - Legal Verification & Review Queue
// Enforces rigorous stage gating: DRAFT -> NEEDS_REVIEW -> VERIFIED -> PUBLISHED.

class AdvocateReviewQueue {
  constructor(store) {
    this.store = store;
    this.currentReviewItem = null;
  }

  getPendingItems(actCode = '') {
    const sections = this.store.getSections();
    return sections.filter(s => {
      const matchesAct = !actCode || s.actCode.toUpperCase() === actCode.toUpperCase();
      const isPending = s.verificationStatus === 'DRAFT' || s.verificationStatus === 'NEEDS_REVIEW';
      return matchesAct && isPending;
    });
  }

  openReviewModal(recordId) {
    const item = this.store.getSectionById(recordId);
    if (!item) {
      alert("रिकॉर्ड नहीं मिला।");
      return;
    }
    this.currentReviewItem = item;

    document.getElementById('review-sec-title').textContent = `${item.actCode} धारा ${item.sectionNumber}: ${item.officialHeadingHindi || item.officialHeading}`;
    document.getElementById('review-status-badge').innerHTML = `<span class="status-badge ${item.verificationStatus.toLowerCase()}">${this.getStatusLabel(item.verificationStatus)}</span>`;

    // Left Panel: Official Statutory Source
    document.getElementById('review-official-title').textContent = item.officialHeading || "—";
    document.getElementById('review-official-text').textContent = item.officialTextOrApprovedSummary || "कोई मूल पाठ उपलब्ध नहीं है।";
    document.getElementById('review-source-title').textContent = item.sourceTitle || "—";
    
    const sourceLinkEl = document.getElementById('review-source-link');
    const noUrlEl = document.getElementById('review-no-url');
    if (item.officialSourceUrl) {
      sourceLinkEl.href = item.officialSourceUrl;
      sourceLinkEl.textContent = item.officialSourceUrl;
      sourceLinkEl.style.display = 'inline';
      if (noUrlEl) noUrlEl.style.display = 'none';
    } else {
      sourceLinkEl.style.display = 'none';
      if (noUrlEl) {
        noUrlEl.style.display = 'block';
        noUrlEl.textContent = "कोई आधिकारिक यूआरएल लिंक नहीं है (सत्यापन से पूर्व यूआरएल जोड़ना अनिवार्य है)।";
      }
    }

    // Right Panel: Citizen Plain Hindi Explanation
    document.getElementById('review-plain-text').textContent = item.simpleExplanationHindi || "नागरिक व्याख्या अभी नहीं लिखी गई है।";
    document.getElementById('review-punishment').textContent = item.punishmentText || "—";
    document.getElementById('review-bailable').textContent = item.bailableStatus || "—";
    document.getElementById('review-cognizable').textContent = item.cognizableStatus || "—";
    document.getElementById('review-elements').innerHTML = (item.keyElements && item.keyElements.length > 0)
      ? item.keyElements.map(k => `<li>${k}</li>`).join('')
      : "<li>कोई बिंदु दर्ज नहीं</li>";

    document.getElementById('reviewer-notes-input').value = item.reviewNotes || "";
    document.getElementById('reviewer-url-input').value = item.officialSourceUrl || "";

    // Show modal
    document.getElementById('modal-review').classList.add('active');
  }

  submitTransition(targetStatus) {
    if (!this.currentReviewItem) return;

    const notes = document.getElementById('reviewer-notes-input').value.trim();
    const url = document.getElementById('reviewer-url-input').value.trim();

    // Safety rules
    if (targetStatus === 'VERIFIED') {
      if (!url && !this.currentReviewItem.officialSourceUrl) {
        alert("आधिकारिक रूप से सत्यापित करने के लिए प्राथमिक स्रोत (राजपत्र या इंडिया कोड यूआरएल) अनिवार्य है।");
        return;
      }
      if (!this.currentReviewItem.officialTextOrApprovedSummary) {
        alert("मूल वैधानिक पाठ (Official Text) के बिना धारा को सत्यापित नहीं किया जा सकता।");
        return;
      }
    }

    if (targetStatus === 'DRAFT' && !notes) {
      const confirmReject = confirm("ड्राफ्ट में वापस लौटाते समय कारण / समीक्षा टिप्पणी लिखना अनुशंसित है। क्या आप बिना टिप्पणी के जारी रखना चाहते हैं?");
      if (!confirmReject) return;
    }

    this.store.updateSectionStatus(
      this.currentReviewItem.recordId,
      targetStatus,
      notes || `स्थिति परिवर्तित: ${targetStatus}`,
      url
    );

    document.getElementById('modal-review').classList.remove('active');
    this.currentReviewItem = null;

    if (window.advocateApp) {
      window.advocateApp.renderAll();
      window.advocateApp.showToast(`धारा की स्थिति '${this.getStatusLabel(targetStatus)}' में अद्यतन की गई`, 'success');
    }
  }

  getStatusLabel(status) {
    switch (status) {
      case 'DRAFT': return 'प्रारूप (Draft)';
      case 'NEEDS_REVIEW': return 'समीक्षाधीन (Needs Review)';
      case 'VERIFIED': return 'सत्यापित (Verified)';
      case 'PUBLISHED': return 'प्रकाशित (Published)';
      default: return status;
    }
  }
}

window.advocateReviewQueue = new AdvocateReviewQueue(window.advocateStore);
