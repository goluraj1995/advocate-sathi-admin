// Advocate Sathi - Bulk Importer (CSV / JSON)
// Full in-browser file parsing, live schema validation, conflict resolution, and strict draft gating.

class AdvocateBulkImporter {
  constructor() {
    this.parsedData = [];
    this.validationReport = null;
  }

  /**
   * Parse CSV string into array of objects with robust quote handling.
   * @param {string} csvText 
   */
  parseCsv(csvText) {
    const lines = [];
    let currentLine = [];
    let currentToken = '';
    let insideQuotes = false;

    for (let i = 0; i < csvText.length; i++) {
      const char = csvText[i];
      const nextChar = csvText[i + 1];

      if (char === '"') {
        if (insideQuotes && nextChar === '"') {
          currentToken += '"';
          i++; // skip escaped quote
        } else {
          insideQuotes = !insideQuotes;
        }
      } else if (char === ',' && !insideQuotes) {
        currentLine.push(currentToken.trim());
        currentToken = '';
      } else if ((char === '\r' || char === '\n') && !insideQuotes) {
        if (char === '\r' && nextChar === '\n') {
          i++;
        }
        currentLine.push(currentToken.trim());
        if (currentLine.length > 1 || currentLine[0] !== '') {
          lines.push(currentLine);
        }
        currentLine = [];
        currentToken = '';
      } else {
        currentToken += char;
      }
    }

    if (currentToken || currentLine.length > 0) {
      currentLine.push(currentToken.trim());
      lines.push(currentLine);
    }

    if (lines.length < 2) {
      throw new Error("CSV फाइल में कम से कम एक हेडर पंक्ति और एक डेटा पंक्ति होनी चाहिए।");
    }

    const headers = lines[0].map(h => h.trim().toLowerCase());
    const rows = [];

    for (let r = 1; r < lines.length; r++) {
      const line = lines[r];
      if (line.length === 1 && !line[0]) continue;
      const rowObj = {};
      headers.forEach((h, idx) => {
        rowObj[h] = line[idx] !== undefined ? line[idx] : "";
      });
      rows.push(rowObj);
    }

    return rows;
  }

  /**
   * Parse JSON string (supports array of objects or { sections: [...] } object).
   * @param {string} jsonText 
   */
  parseJson(jsonText) {
    const parsed = JSON.parse(jsonText);
    if (Array.isArray(parsed)) {
      return parsed;
    } else if (parsed && Array.isArray(parsed.sections)) {
      return parsed.sections;
    } else if (parsed && Array.isArray(parsed.records)) {
      return parsed.records;
    } else {
      throw new Error("JSON संरचना में धाराओं की सूची (Array) प्राप्त नहीं हुई।");
    }
  }

  /**
   * Validate candidate records against local database.
   * @param {Array<Object>} rawRows 
   * @param {Object} storeInstance 
   */
  validateRecords(rawRows, storeInstance) {
    const validRows = [];
    const invalidRows = [];
    const duplicateRows = [];
    const existingSections = storeInstance.getSections();
    const existingActs = storeInstance.getActs();
    const actCodes = new Set(existingActs.map(a => a.code.toUpperCase()));

    rawRows.forEach((row, index) => {
      const actCode = (row.actcode || row.actCode || row.act || "").toString().trim().toUpperCase();
      const secNum = (row.sectionnumber || row.sectionNumber || row.section || "").toString().trim();
      const errors = [];
      const warnings = [];

      if (!actCode) {
        errors.push("अधिनियम कोड (actCode) अनुपस्थित है");
      } else if (!actCodes.has(actCode)) {
        errors.push(`अधिनियम '${actCode}' डेटाबेस में नहीं है (पहले यह Act जोड़ें)`);
      }

      if (!secNum) {
        errors.push("धारा संख्या (sectionNumber) अनुपस्थित है");
      }

      const headingHi = row.officialheadinghindi || row.officialHeadingHindi || row.titleHindi || "";
      const text = row.officialtextorapprovedsummary || row.officialTextOrApprovedSummary || row.officialText || row.text || "";

      if (!text && !headingHi) {
        warnings.push("वैधानिक पाठ या शीर्षक रिक्त है");
      }

      // Check if duplicate exists
      const isDup = existingSections.some(s => s.actCode.toUpperCase() === actCode && s.sectionNumber === secNum);
      if (isDup) {
        warnings.push("यह धारा डेटाबेस में पहले से मौजूद है");
      }

      // Strict verification gating
      let requestedStatus = (row.verificationstatus || row.verificationStatus || "DRAFT").toUpperCase();
      if (requestedStatus === "VERIFIED" || requestedStatus === "PUBLISHED") {
        warnings.push("सत्यापन सुरक्षा: आयातित रिकॉर्ड को स्वतः VERIFIED नहीं बनाया जा सकता, स्थिति 'NEEDS_REVIEW' की गई।");
        requestedStatus = "NEEDS_REVIEW";
      }

      const normalized = {
        rowNumber: index + 1,
        actCode,
        sectionNumber: secNum,
        officialHeading: row.officialheading || row.officialHeading || row.titleEnglish || `Section ${secNum}`,
        officialHeadingHindi: headingHi || `धारा ${secNum}`,
        officialTextOrApprovedSummary: text,
        simpleExplanationHindi: row.simpleexplanationhindi || row.simpleExplanationHindi || "",
        punishmentText: row.punishmenttext || row.punishmentText || row.punishment || "प्रावधान के अनुसार",
        bailableStatus: row.bailablestatus || row.bailableStatus || "लागू नहीं",
        cognizableStatus: row.cognizablestatus || row.cognizableStatus || "लागू नहीं",
        sourceTitle: row.sourcetitle || row.sourceTitle || "Bulk Import",
        officialSourceUrl: row.officialsourceurl || row.officialSourceUrl || "",
        verificationStatus: requestedStatus || "DRAFT",
        isDuplicate: isDup,
        errors,
        warnings
      };

      if (errors.length > 0) {
        invalidRows.push(normalized);
      } else {
        validRows.push(normalized);
        if (isDup) duplicateRows.push(normalized);
      }
    });

    this.validationReport = {
      total: rawRows.length,
      validCount: validRows.length,
      invalidCount: invalidRows.length,
      duplicateCount: duplicateRows.length,
      validRows,
      invalidRows
    };

    return this.validationReport;
  }

  /**
   * Commit validated records into database based on conflict resolution strategy.
   * @param {string} conflictStrategy ('skip' | 'update_draft' | 'add_draft')
   * @param {Object} storeInstance 
   */
  commitImport(conflictStrategy, storeInstance) {
    if (!this.validationReport || this.validationReport.validRows.length === 0) {
      throw new Error("आयात करने हेतु कोई वैध रिकॉर्ड उपलब्ध नहीं है।");
    }

    let insertedCount = 0;
    let updatedCount = 0;
    let skippedCount = 0;

    const existingSections = storeInstance.getSections();

    this.validationReport.validRows.forEach(row => {
      const existing = existingSections.find(s => 
        s.actCode.toUpperCase() === row.actCode.toUpperCase() && 
        s.sectionNumber === row.sectionNumber
      );

      if (existing) {
        if (conflictStrategy === 'skip') {
          skippedCount++;
          return;
        } else if (conflictStrategy === 'update_draft') {
          // Only update if existing is draft or needs_review (preserve verified)
          if (existing.verificationStatus === 'VERIFIED' || existing.verificationStatus === 'PUBLISHED') {
            skippedCount++;
            return;
          }
          storeInstance.saveSection({
            ...existing,
            ...row,
            recordId: existing.recordId,
            verificationStatus: 'DRAFT'
          }, true);
          updatedCount++;
        } else {
          // add_draft with unique id
          storeInstance.saveSection({
            ...row,
            verificationStatus: 'DRAFT'
          }, false);
          insertedCount++;
        }
      } else {
        storeInstance.saveSection({
          ...row,
          verificationStatus: row.verificationStatus || 'DRAFT'
        }, false);
        insertedCount++;
      }
    });

    storeInstance.logAction('BULK_IMPORT', `थोक आयात पूर्ण: ${insertedCount} नए जोड़े गए, ${updatedCount} अद्यतन, ${skippedCount} छोड़े गए`);

    return { insertedCount, updatedCount, skippedCount };
  }

  /**
   * Download sample CSV template.
   */
  downloadCsvTemplate() {
    const csvContent = 
`actCode,sectionNumber,officialHeadingHindi,officialHeading,officialTextOrApprovedSummary,simpleExplanationHindi,punishmentText,bailableStatus,cognizableStatus,sourceTitle,officialSourceUrl,verificationStatus
BNS,303(1),चोरी,Theft,"Whoever, intending to take dishonestly any movable property out of the possession of any person...","किसी की संपत्ति बिना सहमति बेईमानी से लेना चोरी है।","3 वर्ष तक कारावास या जुर्माना","गैर-जमानती (Non-Bailable)","संज्ञेय (Cognizable)","Gazette of India Act 45 of 2023","https://www.indiacode.nic.in/handle/123456789/21734",DRAFT
BNS,351(1),आपराधिक अभित्रास,Criminal Intimidation,"Whoever threatens another with any injury to his person, reputation or property...","धमकी देकर किसी को भयभीत करना अपराध है।","2 वर्ष तक कारावास या जुर्माना","जमानती (Bailable)","असंज्ञेय (Non-Cognizable)","Gazette of India Act 45 of 2023","https://www.indiacode.nic.in/handle/123456789/21734",DRAFT`;

    this._triggerDownload(csvContent, 'template_advocate_sathi_sections.csv', 'text/csv;charset=utf-8;');
  }

  /**
   * Download sample JSON template.
   */
  downloadJsonTemplate() {
    const sample = [
      {
        actCode: "BNS",
        sectionNumber: "303(1)",
        officialHeadingHindi: "चोरी",
        officialHeading: "Theft",
        officialTextOrApprovedSummary: "Whoever, intending to take dishonestly any movable property...",
        simpleExplanationHindi: "किसी की संपत्ति बिना सहमति बेईमानी से लेना चोरी है।",
        punishmentText: "3 वर्ष तक कारावास या जुर्माना",
        bailableStatus: "गैर-जमानती (Non-Bailable)",
        cognizableStatus: "संज्ञेय (Cognizable)",
        sourceTitle: "Gazette of India Act 45 of 2023",
        officialSourceUrl: "https://www.indiacode.nic.in/handle/123456789/21734",
        verificationStatus: "DRAFT"
      }
    ];

    this._triggerDownload(JSON.stringify(sample, null, 2), 'template_advocate_sathi_sections.json', 'application/json;charset=utf-8;');
  }

  _triggerDownload(content, filename, contentType) {
    const blob = new Blob([content], { type: contentType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

window.advocateBulkImporter = new AdvocateBulkImporter();
