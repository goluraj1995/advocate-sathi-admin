// Advocate Sathi - Local PDF & Gazette Statutory Parser
// 100% In-Browser Local Processing. Zero bytes uploaded to any network or cloud service.

class AdvocatePdfParser {
  constructor() {
    this.initPdfJs();
  }

  initPdfJs() {
    if (typeof window !== 'undefined' && window.pdfjsLib) {
      const isSubdir = window.location.pathname.endsWith("/admin/") || window.location.pathname.includes("/admin/index.html");
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = "./lib/pdf.worker.min.js";
    }
  }

  /**
   * Extract selectable text from PDF file page-by-page.
   * @param {File} file 
   * @param {Function} progressCallback ({ page, totalPages, percent })
   * @returns {Promise<{ fullText: string, totalPages: number, isScannedPdf: boolean }>}
   */
  async extractTextFromPdf(file, progressCallback = null) {
    if (!window.pdfjsLib) {
      throw new Error("PDF.js लाइब्रेरी लोड नहीं हो सकी।");
    }

    const arrayBuffer = await file.arrayBuffer();
    const loadingTask = window.pdfjsLib.getDocument({ data: arrayBuffer });
    const pdfDoc = await loadingTask.promise;
    const totalPages = pdfDoc.numPages;

    let fullText = "";
    let pageTexts = [];

    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      const page = await pdfDoc.getPage(pageNum);
      const textContent = await page.getTextContent();
      
      // PDF.js item order and hasEOL are not reliable enough for statutes:
      // they can split a heading from its section number or interleave columns.
      // Sort strictly by vertical coordinate first, then group items by baseline,
      // then sort each baseline left-to-right. Do not flush on hasEOL because it
      // can occur in the middle of a visual line in some IndiaCode PDF pages.
      const items = textContent.items
        .filter(item => typeof item.str === "string" && item.str.length > 0 && item.transform)
        .map(item => ({
          str: item.str,
          x: Number(item.transform[4]) || 0,
          y: Number(item.transform[5]) || 0
        }))
        .sort((a, b) => (b.y - a.y) || (a.x - b.x));

      const lines = [];
      let lineItems = [];
      let baselineY = null;
      const flushLine = () => {
        if (!lineItems.length) return;
        lineItems.sort((a, b) => a.x - b.x);
        const line = lineItems.map(item => item.str).join(" ").replace(/\s+/g, " ").trim();
        if (line) lines.push(line);
        lineItems = [];
        baselineY = null;
      };

      for (const item of items) {
        if (baselineY !== null && Math.abs(item.y - baselineY) > 2.5) flushLine();
        if (baselineY === null) baselineY = item.y;
        lineItems.push(item);
      }
      flushLine();
      const pageStr = lines.filter(Boolean).join("\n");

      pageTexts.push(pageStr);
      fullText += pageStr + "\n\n";

      if (progressCallback) {
        progressCallback({
          page: pageNum,
          totalPages,
          percent: Math.round((pageNum / totalPages) * 100)
        });
      }
    }

    const cleanLength = fullText.replace(/\s+/g, '').length;
    // If under 120 chars total or average < 20 chars per page, it's a scanned/image PDF
    const isScannedPdf = cleanLength < 120 || (cleanLength / totalPages) < 20;

    return {
      fullText,
      pageTexts,
      totalPages,
      isScannedPdf
    };
  }

  /**
   * Detect Act metadata from text (Title, Act Number, Year, Enactment Date).
   * @param {string} text 
   */
  extractActMetadata(text) {
    const meta = {
      detectedTitleHindi: "",
      detectedTitleEnglish: "",
      detectedShortCode: "",
      detectedActNumber: "",
      detectedYear: new Date().getFullYear(),
      detectedEnactmentDate: ""
    };
    const firstText = (text || "").slice(0, 12000).replace(/\s+/g, " ");
    const upper = firstText.toUpperCase();

    // Official, deterministic metadata for the three 2023 criminal-law Acts.
    if (upper.includes("BHARATIYA NYAYA SANHITA")) {
      meta.detectedShortCode = "BNS";
      meta.detectedTitleEnglish = "The Bharatiya Nyaya Sanhita, 2023";
      meta.detectedTitleHindi = "भारतीय न्याय संहिता, 2023";
      meta.detectedActNumber = "Act No. 45 of 2023";
      meta.detectedYear = 2023;
    } else if (upper.includes("BHARATIYA NAGARIK SURAKSHA")) {
      meta.detectedShortCode = "BNSS";
      meta.detectedTitleEnglish = "The Bharatiya Nagarik Suraksha Sanhita, 2023";
      meta.detectedTitleHindi = "भारतीय नागरिक सुरक्षा संहिता, 2023";
      meta.detectedActNumber = "Act No. 46 of 2023";
      meta.detectedYear = 2023;
    } else if (upper.includes("BHARATIYA SAKSHYA ADHINIYAM")) {
      meta.detectedShortCode = "BSA";
      meta.detectedTitleEnglish = "The Bharatiya Sakshya Adhiniyam, 2023";
      meta.detectedTitleHindi = "भारतीय साक्ष्य अधिनियम, 2023";
      meta.detectedActNumber = "Act No. 47 of 2023";
      meta.detectedYear = 2023;
    } else {
      const actNumMatch = firstText.match(/(?:ACT\s+)?NO\.?\s*([0-9]+)\s+OF\s+([0-9]{4})/i);
      if (actNumMatch) {
        meta.detectedActNumber = `Act No. ${actNumMatch[1]} of ${actNumMatch[2]}`;
        meta.detectedYear = parseInt(actNumMatch[2], 10);
      }
      const titleEnMatch = firstText.match(/THE\s+([A-Z][A-Z\s]{3,80}?(?:ACT|SANHITA|ADHINIYAM|CODE))\s*,?\s*(19|20)\d{2}/i);
      if (titleEnMatch) meta.detectedTitleEnglish = titleEnMatch[0].trim().replace(/\s+/g, " ");
      const titleHiMatch = (text || "").match(/(भारतीय\s+[^\n\r]{2,60}(?:संहिता|अधिनियम|विधि)[^\n\r]*)/);
      if (titleHiMatch) meta.detectedTitleHindi = titleHiMatch[1].trim().replace(/\s+/g, " ");
      if (upper.includes("PENAL CODE")) meta.detectedShortCode = "IPC";
      else if (upper.includes("CRIMINAL PROCEDURE")) meta.detectedShortCode = "CRPC";
      else if (meta.detectedTitleEnglish) {
        meta.detectedShortCode = meta.detectedTitleEnglish.replace(/^THE\s+/i, "").split(/\s+/).map(w => w[0]).join("").slice(0, 6).toUpperCase();
      }
    }
    const dateMatch = firstText.match(/\[?([0-9]{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]+,\s*[0-9]{4})\]?/);
    if (dateMatch) meta.detectedEnactmentDate = dateMatch[1];
    return meta;
  }

  /**
   * Parse sections from raw text using Indian legislative patterns.
   * STRICT GATING: All parsed sections default to DRAFT or NEEDS_REVIEW.
   * @param {string} text 
   * @param {string} actCode 
   * @returns {Array<Object>}
   */
  parseSectionsFromText(text, actCode = "CUSTOM") {
    if (!text || !text.trim()) return [];
    const code = String(actCode || "CUSTOM").toUpperCase();
    const normalized = text.replace(/\r\n?/g, "\n");
    let lines = normalized.split("\n");
    const isBNS = code === "BNS";
    const maxSection = isBNS ? 358 : 599;

    // For BNS, start at the actual first statutory section, not the enactment
    // formula. Preamble/commencement text can otherwise be mistaken for a section.
    if (isBNS) {
      let firstSectionIndex = -1;
      for (let i = 0; i < lines.length; i++) {
        const windowText = lines.slice(i, i + 10).join(" ").replace(/\s+/g, " ");
        if (/\b1\s*[.．。]\s*Short\s+title\b/i.test(windowText)) {
          // Keep the last occurrence: the earlier one is often the table of contents;
          // the last occurrence is normally the actual statutory text.
          firstSectionIndex = i;
        }
      }
      if (firstSectionIndex < 0) return [];
      lines = lines.slice(firstSectionIndex);
    }
    const sectionsByNumber = new Map();
    let current = null;
    let body = [];
    let inBody = false;

    const finalize = () => {
      if (!current) return;
      const textBody = body.join("\n").replace(/\n{3,}/g, "\n\n").trim();
      const title = current.title.trim().replace(/[.\-–—:;\s]+$/, "");
      let cleanedBody = textBody;
      if (cleanedBody) {
        const bodyLines = cleanedBody.split("\n");
        const firstBodyLine = (bodyLines[0] || "").trim();
        if (firstBodyLine.toLowerCase() === title.toLowerCase()) {
          cleanedBody = bodyLines.slice(1).join("\n").trim();
        } else if (firstBodyLine.toLowerCase().startsWith(title.toLowerCase() + " ")) {
          bodyLines[0] = firstBodyLine.slice(title.length).trim();
          cleanedBody = bodyLines.join("\n").trim();
        }
      }
      const combined = `${title}${cleanedBody ? "\n" + cleanedBody : ""}`.trim();
      // Keep only candidates with meaningful statutory content, never chapter labels or TOC-only rows.
      const headingLooksLikeChapter = /^(?:CHAPTER|PART|SCHEDULE|अध्याय|भाग|अनुसूची)\b/i.test(title);
      const hasContent = textBody.length >= 20;
      const validHeading = title.length >= 3 && !headingLooksLikeChapter;
      if (validHeading && hasContent) {
        const { punishment, bailable, cognizable } = this.extractLegalAttributes(combined);
        const candidate = {
          actCode: code,
          sectionNumber: String(current.number),
          officialHeading: title,
          officialHeadingHindi: `धारा ${current.number} - ${title}`,
          officialTextOrApprovedSummary: combined,
          simpleExplanationHindi: "",
          keyElements: [],
          punishmentText: punishment || "प्रावधान के अनुसार",
          bailableStatus: bailable || "परिस्थिति अनुसार / समीक्षाधीन",
          cognizableStatus: cognizable || "समीक्षाधीन",
          trialCourt: "समीक्षाधीन",
          compoundableStatus: "समीक्षाधीन",
          verificationStatus: "DRAFT",
          reviewNotes: "PDF से स्वतः आयातित; मूल अधिनियम से धारा-वार मानवीय सत्यापन आवश्यक",
          sourceTitle: isBNS ? "The Bharatiya Nyaya Sanhita, 2023 (Act No. 45 of 2023)" : "Imported Act Document"
        };
        const old = sectionsByNumber.get(candidate.sectionNumber);
        // Prefer the occurrence with the longer body; this normally selects the statute text over the contents page.
        if (!old || candidate.officialTextOrApprovedSummary.length > old.officialTextOrApprovedSummary.length) {
          sectionsByNumber.set(candidate.sectionNumber, candidate);
        }
      }
      current = null;
      body = [];
    };

    // A statute heading is more restrictive than a numbered line: require a legal heading separator.
    // This avoids treating TOC page numbers, chapter labels, and ordinary numbered paragraphs as sections.
    // BNS PDFs vary: the heading and body may be on one line, split across
    // lines, or omit the usual dot-dash separator in PDF.js text extraction.
    // We only apply this permissive pattern after the enactment formula/first
    // statutory heading has been located, so contents pages are not scanned.
    const statutoryHeading = isBNS
      ? /^(\d{1,3})\s*\.\s*(?:[—–-]\s*)?(.{3,180}?)(?:\s*(?:\.\s*[—–-]|[—–-])\s*(.*))?$/
      : /^(?:(?:Section|धारा)\s+)?(\d{1,3}[A-Z]?)\s*\.\s+(.{3,180}?)(?:\s*[.—–—]\s*)(.*)$/i;
    const explicitHeading = /^(?:Section|धारा)\s+(\d{1,3}[A-Z]?)\s*[.:—-]\s*(.{3,180})$/i;

    for (const rawLine of lines) {
      const line = rawLine.trim();
      if (!line) { if (current) body.push(""); continue; }
      if (/THE GAZETTE OF INDIA|EXTRAORDINARY|^SEC\.\s*\d+/i.test(line)) continue;
      if (isBNS && /^(?:(?:\d{1,3})\s*[.．。]\s*)?(?:1st|first)\s+day\s+of\s+July,?\s+2024\b/i.test(line)) continue;
      if (isBNS && /^(?:(?:\d{1,3})\s*[.．。]\s*)?(?:Now,?\s+it\s+is\s+proposed\s+to\s+enact|An\s+Act\s+to\s+|Be\s+it\s+enacted)\b/i.test(line)) continue;
      if (/^(?:DRA?FT|प्रारूप(?:\s+रूप)?|\(प्रारूप\s+रूप\))$/i.test(line)) continue;
      if (/^(?:CHAPTER|PART|SCHEDULE|अध्याय|भाग|अनुसूची)\b/i.test(line)) continue;

      let match = line.match(statutoryHeading);
      let explicit = false;
      if (!match && !isBNS) { match = line.match(explicitHeading); explicit = !!match; }
      if (match) {
        const number = match[1];
        const n = parseInt(number, 10);
        let title = match[2].trim();
        let tail = explicit ? "" : (match[3] || "").trim();

        // A separator-less BNS line can contain heading plus opening text.
        // Split only at statutory punctuation followed by a known body marker.
        if (isBNS && !tail) {
          const split = title.match(/^(.{3,180}?)(?:\s*\.\s*)(?=(?:\(\d+\)|Whoever\b|Wherever\b|Nothing\b|In\s+this\s+Sanhita\b|The\s+punishments\b|Any\s+person\b))/i);
          if (split) {
            tail = title.slice(split[0].length).trim();
            title = split[1].trim();
          }
        }

        // Reject preamble, commencement date, and explanatory lines even when PDF.js
        // has merged a printed/TOC number with the line (e.g. "1. 1st day of July, 2024").
        const normalizedTitle = title.replace(/\s+/g, " ").trim();
        const badTitle = /^(?:DRA?FT|प्रारूप|भारत का राजपत्र|THE GAZETTE OF INDIA)$/i.test(normalizedTitle);
        const isBNSPreambleTitle = isBNS && (
          /^(?:1st|first)\s+day\s+of\s+July,?\s+2024\b/i.test(normalizedTitle) ||
          /^now,?\s+it\s+is\s+proposed\s+to\s+enact\b/i.test(normalizedTitle) ||
          /^an\s+act\s+to\s+/i.test(normalizedTitle) ||
          /^it\s+is\s+hereby\s+enacted\b/i.test(normalizedTitle) ||
          /^be\s+it\s+enacted\b/i.test(normalizedTitle)
        );
        // Section 1 is a hard anchor: never accept a different title as BNS section 1.
        const wrongBNSSectionOne = isBNS && n === 1 && !/^short\s+title\b/i.test(normalizedTitle);
        if (n >= 1 && n <= maxSection && normalizedTitle.length >= 3 && !badTitle && !isBNSPreambleTitle && !wrongBNSSectionOne && !/^\d{1,3}$/.test(tail)) {
          finalize();
          current = { number, title: title.replace(/[.\s]+$/, "") };
          body = tail ? [tail] : [];
          inBody = true;
          continue;
        }
      }
      if (inBody && current) body.push(line);
    }
    finalize();

    let sections = Array.from(sectionsByNumber.values()).sort((a, b) => Number(a.sectionNumber) - Number(b.sectionNumber));
    // A BNS import must never expose more than the 358 statutory sections.
    if (isBNS && sections.length > 358) sections = sections.slice(0, 358);
    return sections;
  }

  /**
   * Detect punishment, bailable and cognizable clauses from statutory body.
   */
  extractLegalAttributes(bodyText) {
    let punishment = "";
    let bailable = "";
    let cognizable = "";

    const lower = bodyText.toLowerCase();

    // Punishment patterns
    const punishMatch = bodyText.match(/(?:shall be punished with|सज़ा दी जाएगी|punished with imprisonment)[^\.\;\n]{5,180}/i);
    if (punishMatch) {
      punishment = punishMatch[0].trim();
    }

    // Bailability
    if (lower.includes("non-bailable") || lower.includes("गैर-जमानती")) {
      bailable = "गैर-जमानती (Non-Bailable)";
    } else if (lower.includes("bailable") || lower.includes("जमानती")) {
      bailable = "जमानती (Bailable)";
    }

    // Cognizability
    if (lower.includes("non-cognizable") || lower.includes("असंज्ञेय")) {
      cognizable = "असंज्ञेय (Non-Cognizable)";
    } else if (lower.includes("cognizable") || lower.includes("संज्ञेय")) {
      cognizable = "संज्ञेय (Cognizable)";
    }

    return { punishment, bailable, cognizable };
  }
}

window.advocatePdfParser = new AdvocatePdfParser();
