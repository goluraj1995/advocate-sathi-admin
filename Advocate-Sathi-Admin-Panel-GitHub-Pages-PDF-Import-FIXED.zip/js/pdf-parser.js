// Advocate Sathi - Local PDF & Gazette Statutory Parser
// 100% In-Browser Local Processing. Zero bytes uploaded to any network or cloud service.

class AdvocatePdfParser {
  constructor() {
    this.initPdfJs();
  }

  initPdfJs() {
    if (typeof window !== 'undefined' && window.pdfjsLib) {
      const isSubdir = window.location.pathname.endsWith("/admin/") || window.location.pathname.includes("/admin/index.html");
      window.pdfjsLib.GlobalWorkerOptions.workerSrc = "./lib/pdf.worker.min.js";
    }
  }

  /**
   * Extract selectable text from PDF file page-by-page.
   * @param {File} file 
   * @param {Function} progressCallback ({ page, totalPages, percent })
   * @returns {Promise<{ fullText: string, totalPages: number, isScannedPdf: boolean }>}
   */
  async extractTextFromPdf(file, progressCallback = null) {
    if (!window.pdfjsLib) {
      throw new Error("PDF.js लाइब्रेरी लोड नहीं हो सकी।");
    }

    const arrayBuffer = await file.arrayBuffer();
    const loadingTask = window.pdfjsLib.getDocument({ data: arrayBuffer });
    const pdfDoc = await loadingTask.promise;
    const totalPages = pdfDoc.numPages;

    let fullText = "";
    let pageTexts = [];

    for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
      const page = await pdfDoc.getPage(pageNum);
      const textContent = await page.getTextContent();
      
      // Group text items by line
      let lastY = null;
      let pageStr = "";
      for (const item of textContent.items) {
        if (lastY !== null && Math.abs(item.transform[5] - lastY) > 5) {
          pageStr += "\n";
        } else if (pageStr.length > 0 && !pageStr.endsWith("\n") && !pageStr.endsWith(" ")) {
          pageStr += " ";
        }
        pageStr += item.str;
        lastY = item.transform[5];
      }

      pageTexts.push(pageStr);
      fullText += pageStr + "\n\n";

      if (progressCallback) {
        progressCallback({
          page: pageNum,
          totalPages,
          percent: Math.round((pageNum / totalPages) * 100)
        });
      }
    }

    const cleanLength = fullText.replace(/\s+/g, '').length;
    // If under 120 chars total or average < 20 chars per page, it's a scanned/image PDF
    const isScannedPdf = cleanLength < 120 || (cleanLength / totalPages) < 20;

    return {
      fullText,
      pageTexts,
      totalPages,
      isScannedPdf
    };
  }

  /**
   * Detect Act metadata from text (Title, Act Number, Year, Enactment Date).
   * @param {string} text 
   */
  extractActMetadata(text) {
    const meta = {
      detectedTitleHindi: "",
      detectedTitleEnglish: "",
      detectedShortCode: "",
      detectedActNumber: "",
      detectedYear: new Date().getFullYear(),
      detectedEnactmentDate: ""
    };

    const first5000 = text.slice(0, 5000);

    // Act Number pattern: "NO. 45 OF 2023" or "ACT NO. 45 OF 2023"
    const actNumMatch = first5000.match(/(?:ACT\s+)?NO\.?\s*([0-9]+)\s+OF\s+([0-9]{4})/i);
    if (actNumMatch) {
      meta.detectedActNumber = `Act No. ${actNumMatch[1]} of ${actNumMatch[2]}`;
      meta.detectedYear = parseInt(actNumMatch[2]);
    }

    // Title English: "THE BHARATIYA NYAYA SANHITA, 2023" or similar
    const titleEnMatch = first5000.match(/THE\s+([A-Z\s]{4,60}(?:ACT|SANHITA|ADHINIYAM|CODE)[A-Z\s,0-9]*)/i);
    if (titleEnMatch) {
      meta.detectedTitleEnglish = titleEnMatch[0].trim().replace(/\s+/g, ' ');
    }

    // Title Hindi: e.g. "भारतीय न्याय संहिता"
    const titleHiMatch = first5000.match(/(भारतीय\s+[^\n\r]{4,50}(?:संहिता|अधिनियम|विधि)[^\n\r0-9]*)/);
    if (titleHiMatch) {
      meta.detectedTitleHindi = titleHiMatch[0].trim().replace(/\s+/g, ' ');
    }

    // Short Code Heuristics
    const upperText = (meta.detectedTitleEnglish || first5000).toUpperCase();
    if (upperText.includes("BHARATIYA NYAYA SANHITA")) {
      meta.detectedShortCode = "BNS";
      meta.detectedTitleHindi = meta.detectedTitleHindi || "भारतीय न्याय संहिता, 2023";
    } else if (upperText.includes("BHARATIYA NAGARIK SURAKSHA")) {
      meta.detectedShortCode = "BNSS";
      meta.detectedTitleHindi = meta.detectedTitleHindi || "भारतीय नागरिक सुरक्षा संहिता, 2023";
    } else if (upperText.includes("BHARATIYA SAKSHYA")) {
      meta.detectedShortCode = "BSA";
      meta.detectedTitleHindi = meta.detectedTitleHindi || "भारतीय साक्ष्य अधिनियम, 2023";
    } else if (upperText.includes("PENAL CODE")) {
      meta.detectedShortCode = "IPC";
      meta.detectedTitleHindi = meta.detectedTitleHindi || "भारतीय दंड संहिता, 1860";
    } else if (upperText.includes("CRIMINAL PROCEDURE")) {
      meta.detectedShortCode = "CRPC";
      meta.detectedTitleHindi = meta.detectedTitleHindi || "दंड प्रक्रिया संहिता, 1973";
    } else if (meta.detectedTitleEnglish) {
      // Create acronym from English title
      const words = meta.detectedTitleEnglish.replace(/THE\s+/i, '').split(/\s+/);
      meta.detectedShortCode = words.map(w => w[0]).join('').substring(0, 6).toUpperCase();
    }

    // Enactment Date: "25th December, 2023" or "[25th December, 2023]"
    const dateMatch = first5000.match(/\[?([0-9]{1,2}(?:st|nd|rd|th)?\s+[A-Za-z]+,\s*[0-9]{4})\]?/);
    if (dateMatch) {
      meta.detectedEnactmentDate = dateMatch[1];
    }

    return meta;
  }

  /**
   * Parse sections from raw text using Indian legislative patterns.
   * STRICT GATING: All parsed sections default to DRAFT or NEEDS_REVIEW.
   * @param {string} text 
   * @param {string} actCode 
   * @returns {Array<Object>}
   */
  parseSectionsFromText(text, actCode = "CUSTOM") {
    const sections = [];
    if (!text || text.trim().length === 0) return sections;

    // Normalize text
    const normalized = text.replace(/\r\n/g, '\n');

    // Split text into lines
    const lines = normalized.split('\n');

    // Regex for Section start:
    // Match: "1. Short title..." or "303. (1) Whoever..." or "Section 303. Theft" or "धारा 303. चोरी"
    const sectionStartRegex = /^(?:(?:Section|धारा)\s+)?(\d+[A-Z]?(?:\(\d+\))*)\.?\s+([^\n]+)?$/i;

    let currentSection = null;
    let buffer = [];

    const finalizeSection = () => {
      if (!currentSection) return;
      const body = buffer.join('\n').trim();
      if (body.length > 0 || currentSection.title.length > 0) {
        // Extract punishment & legal flags
        const { punishment, bailable, cognizable } = this.extractLegalAttributes(body);

        sections.push({
          actCode: actCode.toUpperCase(),
          sectionNumber: currentSection.number,
          officialHeading: currentSection.title || `Section ${currentSection.number}`,
          officialHeadingHindi: `धारा ${currentSection.number} - ${currentSection.title || ''}`,
          officialTextOrApprovedSummary: body || currentSection.title,
          simpleExplanationHindi: "", // Requires human review
          keyElements: [],
          punishmentText: punishment || "प्रावधान के अनुसार",
          bailableStatus: bailable || "परिस्थिति अनुसार / समीक्षाधीन",
          cognizableStatus: cognizable || "समीक्षाधीन",
          trialCourt: "संबद्ध क्षेत्राधिकारी न्यायालय",
          compoundableStatus: "समीक्षाधीन",
          verificationStatus: "DRAFT", // STRICT: ALWAYS DRAFT
          reviewNotes: "PDF/टेक्स्ट से स्वतः आयातित - विधिक सत्यापन अपेक्षित",
          sourceTitle: "Imported Act Document"
        });
      }
      currentSection = null;
      buffer = [];
    };

    // Filter out preamble or TOC if present
    let inBody = false;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line) {
        if (currentSection) buffer.push("");
        continue;
      }

      // Ignore standard header/footer watermarks
      if (line.includes("THE GAZETTE OF INDIA") || line.includes("EXTRAORDINARY") || line.match(/^SEC\.\s*\d+/i)) {
        continue;
      }

      const match = line.match(sectionStartRegex);
      // Valid section number must be integer or followed by letter
      if (match && parseInt(match[1]) > 0 && parseInt(match[1]) < 600) {
        inBody = true;
        finalizeSection();

        currentSection = {
          number: match[1],
          title: (match[2] || "").trim()
        };
      } else if (inBody && currentSection) {
        buffer.push(line);
      }
    }

    // Finalize last section
    finalizeSection();

    // Fallback if regex didn't catch standard numbers (e.g. paragraph blocks)
    if (sections.length === 0) {
      // Chunk by paragraphs
      const paragraphs = normalized.split(/\n\s*\n/).filter(p => p.trim().length > 30);
      paragraphs.slice(0, 30).forEach((p, idx) => {
        const secNum = `${idx + 1}`;
        const firstLine = p.split('\n')[0].substring(0, 60);
        sections.push({
          actCode: actCode.toUpperCase(),
          sectionNumber: secNum,
          officialHeading: firstLine,
          officialHeadingHindi: `धारा ${secNum}`,
          officialTextOrApprovedSummary: p.trim(),
          simpleExplanationHindi: "",
          keyElements: [],
          punishmentText: "समीक्षाधीन",
          bailableStatus: "समीक्षाधीन",
          cognizableStatus: "समीक्षाधीन",
          trialCourt: "संबद्ध क्षेत्राधिकारी न्यायालय",
          compoundableStatus: "समीक्षाधीन",
          verificationStatus: "DRAFT",
          reviewNotes: "अनुच्छेद से प्रारूप के रूप में स्वतः विभाजित",
          sourceTitle: "Imported Document"
        });
      });
    }

    return sections;
  }

  /**
   * Detect punishment, bailable and cognizable clauses from statutory body.
   */
  extractLegalAttributes(bodyText) {
    let punishment = "";
    let bailable = "";
    let cognizable = "";

    const lower = bodyText.toLowerCase();

    // Punishment patterns
    const punishMatch = bodyText.match(/(?:shall be punished with|सज़ा दी जाएगी|punished with imprisonment)[^\.\;\n]{5,180}/i);
    if (punishMatch) {
      punishment = punishMatch[0].trim();
    }

    // Bailability
    if (lower.includes("non-bailable") || lower.includes("गैर-जमानती")) {
      bailable = "गैर-जमानती (Non-Bailable)";
    } else if (lower.includes("bailable") || lower.includes("जमानती")) {
      bailable = "जमानती (Bailable)";
    }

    // Cognizability
    if (lower.includes("non-cognizable") || lower.includes("असंज्ञेय")) {
      cognizable = "असंज्ञेय (Non-Cognizable)";
    } else if (lower.includes("cognizable") || lower.includes("संज्ञेय")) {
      cognizable = "संज्ञेय (Cognizable)";
    }

    return { punishment, bailable, cognizable };
  }
}

window.advocatePdfParser = new AdvocatePdfParser();
