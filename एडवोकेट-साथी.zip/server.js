// Advocate Sathi Admin Server
// High-resilience static server for Admin Panel on port 3000.
// Serves both workspace root and /admin paths seamlessly.
const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;
const ROOT_DIR = __dirname;
const ADMIN_DIR = path.join(__dirname, 'admin');

const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.js': 'application/javascript; charset=UTF-8',
  '.json': 'application/json; charset=UTF-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon',
  '.csv': 'text/csv; charset=UTF-8',
  '.pdf': 'application/pdf',
  '.txt': 'text/plain; charset=UTF-8'
};

function tryFindFile(reqPath) {
  // Normalize path
  let cleanPath = decodeURI(reqPath.split('?')[0]);
  if (cleanPath === '/' || cleanPath === '') {
    cleanPath = '/index.html';
  }

  // Candidate 1: directly under ROOT_DIR (e.g. /index.html or /admin/...)
  let candidate1 = path.join(ROOT_DIR, cleanPath);
  if (candidate1.startsWith(ROOT_DIR) && fs.existsSync(candidate1) && fs.statSync(candidate1).isFile()) {
    return candidate1;
  }

  // Candidate 2: directory index in ROOT_DIR
  if (candidate1.startsWith(ROOT_DIR) && fs.existsSync(candidate1) && fs.statSync(candidate1).isDirectory()) {
    let indexInDir = path.join(candidate1, 'index.html');
    if (fs.existsSync(indexInDir) && fs.statSync(indexInDir).isFile()) {
      return indexInDir;
    }
  }

  // Candidate 3: directly under ADMIN_DIR (e.g. /css/admin.css or /js/app.js)
  let candidate3 = path.join(ADMIN_DIR, cleanPath);
  if (candidate3.startsWith(ADMIN_DIR) && fs.existsSync(candidate3) && fs.statSync(candidate3).isFile()) {
    return candidate3;
  }

  // Candidate 4: root index.html fallback
  let rootIndex = path.join(ROOT_DIR, 'index.html');
  if (fs.existsSync(rootIndex)) {
    return rootIndex;
  }

  return null;
}

const server = http.createServer((req, res) => {
  // Health check endpoint
  if (req.url === '/api/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ 
      status: 'ok', 
      app: 'Advocate Sathi Admin Panel', 
      version: '1.0.0',
      port: PORT,
      timestamp: new Date().toISOString()
    }));
    return;
  }

  const resolvedFile = tryFindFile(req.url);

  if (!resolvedFile) {
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=UTF-8' });
    res.end('404 Not Found: ' + req.url);
    return;
  }

  const ext = path.extname(resolvedFile).toLowerCase();
  const contentType = MIME_TYPES[ext] || 'application/octet-stream';

  fs.readFile(resolvedFile, (err, content) => {
    if (err) {
      res.writeHead(500, { 'Content-Type': 'text/plain; charset=UTF-8' });
      res.end('500 Internal Server Error: ' + err.message);
    } else {
      res.writeHead(200, {
        'Content-Type': contentType,
        'Cache-Control': 'no-cache',
        'X-Content-Type-Options': 'nosniff'
      });
      res.end(content);
    }
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Advocate Sathi Admin Server listening on http://0.0.0.0:${PORT}`);
});
