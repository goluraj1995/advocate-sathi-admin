package com.example.ocr

enum class ExtractionMethod(val labelHindi: String, val isOffline: Boolean = true) {
    IMAGE_OCR("इमेज ऑन-डिवाइस OCR (ML Kit Devanagari / Latin)", true),
    PDF_EMBEDDED("पीडीएफ डिजिटल टेक्स्ट निष्कर्षण", true),
    PDF_RENDERED_OCR("पीडीएफ पृष्ठ OCR (PdfRenderer + ML Kit)", true),
    HYBRID_PDF("मिश्रित निष्कर्षण (डिजिटल टेक्स्ट + पृष्ठ OCR)", true),
    MANUAL_ENTRY("उपयोगकर्ता द्वारा मैन्युअल प्रविष्टि", true)
}

data class OcrProgress(
    val stageMessage: String,
    val currentPage: Int = 0,
    val totalPages: Int = 0,
    val progressFraction: Float = 0f
)

sealed class OcrResult {
    data class Success(
        val text: String,
        val method: ExtractionMethod,
        val pageCount: Int,
        val warningNotice: String? = null
    ) : OcrResult()

    data class Empty(
        val method: ExtractionMethod,
        val reasonMessage: String
    ) : OcrResult()

    data class Error(
        val userMessage: String,
        val technicalDetail: String? = null,
        val recoveryHelp: String
    ) : OcrResult()
}
