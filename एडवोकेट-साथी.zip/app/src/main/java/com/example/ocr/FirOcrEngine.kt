package com.example.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.util.Log
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.pdmodel.encryption.InvalidPasswordException
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.InputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.max
import kotlin.math.min

/**
 * Real On-Device OCR Engine for Indian FIR documents.
 * - Supports Hindi (Devanagari) and English (Latin) scripts locally using ML Kit Bundled model.
 * - Extracts digital embedded text from searchable PDFs using PDFBox Android.
 * - Renders scanned PDF pages sequentially with Android PdfRenderer and OCRs them locally.
 * - Zero cloud upload; zero persistence of sensitive contents.
 */
class FirOcrEngine(private val context: Context) {

    companion object {
        private const val TAG = "FirOcrEngine"
        private const val MAX_IMAGE_DIMENSION = 2048
        private const val MAX_SAFE_PDF_PAGES = 30
        private const val MIN_EMBEDDED_TEXT_CHARS = 25
    }

    private val recognizer by lazy {
        TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
    }

    /**
     * Process an Image file (JPEG/PNG/WEBP) from Uri using ML Kit Devanagari on-device OCR.
     */
    suspend fun processImage(
        uri: Uri,
        onProgress: (OcrProgress) -> Unit = {}
    ): OcrResult = withContext(Dispatchers.IO) {
        var bitmap: Bitmap? = null
        try {
            ensureActive()
            onProgress(OcrProgress(stageMessage = "छवि लोड की जा रही है...", progressFraction = 0.15f))

            bitmap = decodeSampledBitmapFromUri(context, uri, MAX_IMAGE_DIMENSION)
                ?: return@withContext OcrResult.Error(
                    userMessage = "छवि फ़ाइल को डिकोड नहीं किया जा सका।",
                    technicalDetail = "Bitmap decoding returned null for URI: $uri",
                    recoveryHelp = "कृपया एक वैध, स्पष्ट JPG या PNG फोटो चुनें।"
                )

            ensureActive()
            onProgress(OcrProgress(stageMessage = "ऑन-डिवाइस OCR (देवनागरी / हिंदी) चल रहा है...", progressFraction = 0.5f))

            val inputImage = InputImage.fromBitmap(bitmap, 0)
            val visionText = suspendCancellableCoroutine { cont ->
                val task = recognizer.process(inputImage)
                task.addOnSuccessListener { text ->
                    if (cont.isActive) cont.resume(text)
                }.addOnFailureListener { exc ->
                    if (cont.isActive) cont.resumeWithException(exc)
                }
                cont.invokeOnCancellation {
                    // Task cancellation acknowledgment
                }
            }

            ensureActive()
            val rawText = visionText.text.trim()
            onProgress(OcrProgress(stageMessage = "समीक्षा पूर्ण!", progressFraction = 1.0f))

            if (rawText.isBlank()) {
                OcrResult.Empty(
                    method = ExtractionMethod.IMAGE_OCR,
                    reasonMessage = "छवि में कोई स्पष्ट देवनागरी या अंग्रेजी पाठ नहीं पहचाना जा सका। कृपया प्रकाश और फोकस सही रखकर दोबारा फोटो लें।"
                )
            } else {
                OcrResult.Success(
                    text = rawText,
                    method = ExtractionMethod.IMAGE_OCR,
                    pageCount = 1,
                    warningNotice = "ऑन-डिवाइस OCR द्वारा निकाला गया पाठ। हस्तलिखित या धुंधले अक्षरों में त्रुटि संभव है, कृपया नीचे समीक्षा करें।"
                )
            }
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            Log.e(TAG, "Error during image OCR", e)
            OcrResult.Error(
                userMessage = "छवि OCR प्रसंस्करण के दौरान त्रुटि आई।",
                technicalDetail = e.localizedMessage ?: e.javaClass.simpleName,
                recoveryHelp = "कृपया फ़ाइल की गुणवत्ता जाँचें अथवा सीधे टेक्स्ट बॉक्स में विवरण दर्ज करें।"
            )
        } finally {
            try {
                bitmap?.recycle()
            } catch (_: Exception) {}
        }
    }

    /**
     * Process a PDF file from Uri.
     * 1. Inspects pages for embedded text.
     * 2. For scanned/image pages, renders each page sequentially via PdfRenderer and runs Devanagari OCR.
     */
    suspend fun processPdf(
        uri: Uri,
        onProgress: (OcrProgress) -> Unit = {}
    ): OcrResult = withContext(Dispatchers.IO) {
        var pdDocument: PDDocument? = null
        var inputStream: InputStream? = null

        try {
            ensureActive()
            onProgress(OcrProgress(stageMessage = "पीडीएफ संरचना जाँची जा रही है...", progressFraction = 0.1f))

            // 1. Check with PDFBox for encryption and page metadata
            try {
                inputStream = context.contentResolver.openInputStream(uri)
                    ?: return@withContext OcrResult.Error(
                        userMessage = "पीडीएफ फ़ाइल खोली नहीं जा सकी।",
                        technicalDetail = "openInputStream returned null",
                        recoveryHelp = "कृपया फ़ाइल का चयन पुनः करें।"
                    )
                pdDocument = PDDocument.load(inputStream)
            } catch (e: InvalidPasswordException) {
                return@withContext OcrResult.Error(
                    userMessage = "यह पीडीएफ पासवर्ड-संरक्षित (Encrypted) है।",
                    technicalDetail = "InvalidPasswordException: Document is protected by a password",
                    recoveryHelp = "कृपया पीडीएफ का पासवर्ड हटाकर या अनलॉक की गई प्रति चुनें।"
                )
            } catch (e: Exception) {
                if (e.message?.contains("password", ignoreCase = true) == true) {
                    return@withContext OcrResult.Error(
                        userMessage = "यह पीडीएफ पासवर्ड-संरक्षित है।",
                        technicalDetail = e.message,
                        recoveryHelp = "कृपया बिना पासवर्ड वाली प्रति चुनें।"
                    )
                }
                throw e
            }

            if (pdDocument.isEncrypted) {
                return@withContext OcrResult.Error(
                    userMessage = "यह पीडीएफ एन्क्रिप्टेड है।",
                    technicalDetail = "Document is encrypted",
                    recoveryHelp = "सुरक्षा कारणों से एन्क्रिप्टेड पीडीएफ प्रोसेस नहीं की जा सकती। कृपया अनप्रोटेक्टेड प्रति चुनें।"
                )
            }

            val totalPages = pdDocument.numberOfPages
            if (totalPages == 0) {
                return@withContext OcrResult.Empty(
                    method = ExtractionMethod.PDF_EMBEDDED,
                    reasonMessage = "पीडीएफ में कोई पृष्ठ उपलब्ध नहीं है।"
                )
            }

            val pagesToProcess = min(totalPages, MAX_SAFE_PDF_PAGES)
            val resultBuilder = StringBuilder()
            var embeddedPageCount = 0
            var scannedOcrPageCount = 0
            val stripper = PDFTextStripper()

            for (pageIndex in 0 until pagesToProcess) {
                ensureActive()
                val pageNumber = pageIndex + 1

                onProgress(
                    OcrProgress(
                        stageMessage = "पृष्ठ $pageNumber / $pagesToProcess का विश्लेषण हो रहा है...",
                        currentPage = pageNumber,
                        totalPages = pagesToProcess,
                        progressFraction = (pageIndex.toFloat() / pagesToProcess) * 0.9f
                    )
                )

                // Step A: Check for embedded digital text on this specific page
                stripper.startPage = pageNumber
                stripper.endPage = pageNumber
                val embeddedText = try {
                    stripper.getText(pdDocument).trim()
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to strip text on page $pageNumber", e)
                    ""
                }

                ensureActive()

                if (embeddedText.length >= MIN_EMBEDDED_TEXT_CHARS) {
                    // Page has selectable digital text!
                    embeddedPageCount++
                    appendPageText(resultBuilder, pageNumber, totalPages, embeddedText)
                } else {
                    // Step B: Scanned / Flattened page -> Render to Bitmap and run ML Kit OCR
                    onProgress(
                        OcrProgress(
                            stageMessage = "पृष्ठ $pageNumber (स्कैन) का ऑन-डिवाइस OCR चल रहा है...",
                            currentPage = pageNumber,
                            totalPages = pagesToProcess,
                            progressFraction = ((pageIndex + 0.5f) / pagesToProcess) * 0.9f
                        )
                    )

                    val pageOcrText = renderAndOcrPdfPage(context, uri, pageIndex)
                    ensureActive()

                    if (pageOcrText.isNotBlank()) {
                        scannedOcrPageCount++
                        appendPageText(resultBuilder, pageNumber, totalPages, pageOcrText)
                    } else if (embeddedText.isNotBlank()) {
                        appendPageText(resultBuilder, pageNumber, totalPages, embeddedText)
                    }
                }
            }

            ensureActive()
            onProgress(OcrProgress(stageMessage = "विश्लेषण पूर्ण!", progressFraction = 1.0f))

            val finalExtractedText = resultBuilder.toString().trim()
            if (finalExtractedText.isBlank()) {
                OcrResult.Empty(
                    method = if (scannedOcrPageCount > 0) ExtractionMethod.PDF_RENDERED_OCR else ExtractionMethod.PDF_EMBEDDED,
                    reasonMessage = "इस पीडीएफ दस्तावेज़ से कोई सुपाठ्य पाठ नहीं पहचाना जा सका। कृपया स्पष्ट डिजिटल पीडीएफ या साफ स्कैन का उपयोग करें।"
                )
            } else {
                val method = when {
                    embeddedPageCount > 0 && scannedOcrPageCount > 0 -> ExtractionMethod.HYBRID_PDF
                    scannedOcrPageCount > 0 -> ExtractionMethod.PDF_RENDERED_OCR
                    else -> ExtractionMethod.PDF_EMBEDDED
                }

                val warningNotice = if (totalPages > MAX_SAFE_PDF_PAGES) {
                    "स्मृति सुरक्षा हेतु प्रथम $MAX_SAFE_PDF_PAGES पृष्ठ प्रोसेस किए गए (कुल $totalPages पृष्ठ)।"
                } else null

                OcrResult.Success(
                    text = finalExtractedText,
                    method = method,
                    pageCount = pagesToProcess,
                    warningNotice = warningNotice
                )
            }
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            Log.e(TAG, "Error processing PDF", e)
            OcrResult.Error(
                userMessage = "पीडीएफ दस्तावेज़ के विश्लेषण में त्रुटि आई।",
                technicalDetail = e.localizedMessage ?: e.javaClass.simpleName,
                recoveryHelp = "जाँचें कि क्या पीडीएफ वैध है, या सीधे टेक्स्ट बॉक्स में एफआईआर विवरण लिखें।"
            )
        } finally {
            try {
                pdDocument?.close()
            } catch (_: Exception) {}
            try {
                inputStream?.close()
            } catch (_: Exception) {}
        }
    }

    private fun appendPageText(builder: StringBuilder, pageNumber: Int, totalPages: Int, text: String) {
        if (totalPages > 1) {
            if (builder.isNotEmpty()) {
                builder.append("\n\n")
            }
            builder.append("--- पृष्ठ $pageNumber ---\n")
        }
        builder.append(text)
    }

    /**
     * Renders a single PDF page using native Android PdfRenderer and runs ML Kit Devanagari OCR.
     */
    private suspend fun renderAndOcrPdfPage(context: Context, uri: Uri, pageIndex: Int): String {
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        var page: PdfRenderer.Page? = null
        var bitmap: Bitmap? = null

        return try {
            pfd = context.contentResolver.openFileDescriptor(uri, "r") ?: return ""
            renderer = PdfRenderer(pfd)
            if (pageIndex >= renderer.pageCount) return ""

            page = renderer.openPage(pageIndex)

            // Scale factor 1.8x for optimal Devanagari clarity without memory explosion
            val targetWidth = min((page.width * 1.8f).toInt(), MAX_IMAGE_DIMENSION)
            val targetHeight = min((page.height * 1.8f).toInt(), MAX_IMAGE_DIMENSION)

            bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
            bitmap.eraseColor(Color.WHITE)

            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

            // Close page immediately before OCR to reduce memory footprint
            try {
                page.close()
            } catch (_: Exception) {}
            page = null

            val inputImage = InputImage.fromBitmap(bitmap, 0)
            val visionText = suspendCancellableCoroutine { cont ->
                val task = recognizer.process(inputImage)
                task.addOnSuccessListener { text ->
                    if (cont.isActive) cont.resume(text)
                }.addOnFailureListener { exc ->
                    if (cont.isActive) cont.resumeWithException(exc)
                }
            }

            visionText.text.trim()
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            Log.w(TAG, "renderAndOcrPdfPage failed on page $pageIndex", e)
            ""
        } finally {
            try {
                bitmap?.recycle()
            } catch (_: Exception) {}
            try {
                page?.close()
            } catch (_: Exception) {}
            try {
                renderer?.close()
            } catch (_: Exception) {}
            try {
                pfd?.close()
            } catch (_: Exception) {}
        }
    }

    private fun decodeSampledBitmapFromUri(context: Context, uri: Uri, maxDimension: Int): Bitmap? {
        val options = BitmapFactory.Options().apply {
            inJustDecodeBounds = true
        }
        try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, options)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to read bitmap bounds from URI $uri", e)
            return null
        }

        val originalWidth = options.outWidth
        val originalHeight = options.outHeight
        if (originalWidth <= 0 || originalHeight <= 0) return null

        var inSampleSize = 1
        val maxOriginalDim = max(originalWidth, originalHeight)
        if (maxOriginalDim > maxDimension) {
            inSampleSize = (maxOriginalDim / maxDimension)
        }

        val decodeOptions = BitmapFactory.Options().apply {
            this.inSampleSize = inSampleSize
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }

        return try {
            context.contentResolver.openInputStream(uri)?.use { stream ->
                BitmapFactory.decodeStream(stream, null, decodeOptions)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to decode sampled bitmap from URI $uri", e)
            null
        }
    }

    fun close() {
        try {
            recognizer.close()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to close recognizer", e)
        }
    }
}
