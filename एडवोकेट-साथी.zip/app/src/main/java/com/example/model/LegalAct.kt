package com.example.model

/**
 * Represents the primary criminal legal acts in India.
 */
enum class LegalAct(
    val code: String,
    val hindiShortName: String,
    val hindiFullName: String,
    val englishName: String,
    val year: Int,
    val isNewCriminalLaw: Boolean,
    val applicablePeriod: String,
    val totalChapters: Int,
    val totalSections: Int,
    val descriptionHindi: String
) {
    BNS(
        code = "BNS",
        hindiShortName = "बीएनएस (BNS)",
        hindiFullName = "भारतीय न्याय संहिता, 2023",
        englishName = "Bharatiya Nyaya Sanhita, 2023",
        year = 2023,
        isNewCriminalLaw = true,
        applicablePeriod = "1 जुलाई 2024 एवं उसके पश्चात् घटित अपराधों के लिए",
        totalChapters = 20,
        totalSections = 358,
        descriptionHindi = "आईपीसी (IPC) का स्थान लेने वाली नई संहिता, जिसमें अपराधों की परिभाषा तथा दंड का प्रावधान है।"
    ),
    BNSS(
        code = "BNSS",
        hindiShortName = "बीएनएसएस (BNSS)",
        hindiFullName = "भारतीय नागरिक सुरक्षा संहिता, 2023",
        englishName = "Bharatiya Nagarik Suraksha Sanhita, 2023",
        year = 2023,
        isNewCriminalLaw = true,
        applicablePeriod = "1 जुलाई 2024 से आपराधिक जांच, गिरफ़्तारी, ज़मानत एवं ट्रायल प्रक्रिया हेतु",
        totalChapters = 39,
        totalSections = 531,
        descriptionHindi = "सीआरपीसी (CrPC) का स्थान लेने वाली संहिता, जिसमें एफआईआर, जांच, गिरफ़्तारी एवं न्यायालय की प्रक्रिया निर्धारित है।"
    ),
    BSA(
        code = "BSA",
        hindiShortName = "बीएसए (BSA)",
        hindiFullName = "भारतीय साक्ष्य अधिनियम, 2023",
        englishName = "Bharatiya Sakshya Adhiniyam, 2023",
        year = 2023,
        isNewCriminalLaw = true,
        applicablePeriod = "1 जुलाई 2024 से साक्ष्य एवं दस्तावेजी प्रमाणों की ग्राह्यता हेतु",
        totalChapters = 12,
        totalSections = 170,
        descriptionHindi = "भारतीय साक्ष्य अधिनियम 1872 का स्थान लेने वाला नया कानून, जिसमें डिजिटल व इलेक्ट्रॉनिक साक्ष्यों के व्यापक नियम हैं।"
    ),
    IPC(
        code = "IPC",
        hindiShortName = "आईपीसी (IPC)",
        hindiFullName = "भारतीय दंड संहिता, 1860",
        englishName = "Indian Penal Code, 1860",
        year = 1860,
        isNewCriminalLaw = false,
        applicablePeriod = "1 जुलाई 2024 से पूर्व घटित अपराधों के मामलों में लागू",
        totalChapters = 23,
        totalSections = 511,
        descriptionHindi = "भारत का ऐतिहासिक दांडिक कानून, जो 1 जुलाई 2024 से पूर्व की घटनाओं के मुकदमों में अब भी प्रासंगिक है।"
    ),
    CRPC(
        code = "CrPC",
        hindiShortName = "सीआरपीसी (CrPC)",
        hindiFullName = "दंड प्रक्रिया संहिता, 1973",
        englishName = "Code of Criminal Procedure, 1973",
        year = 1973,
        isNewCriminalLaw = false,
        applicablePeriod = "1 जुलाई 2024 से पूर्व दर्ज मुकदमों की पुरानी प्रक्रियाओं में प्रभावी",
        totalChapters = 37,
        totalSections = 484,
        descriptionHindi = "पूर्ववर्ती दांडिक प्रक्रिया संहिता, जिसके अंतर्गत पुरानी एफआईआर और जांच की कार्यवाही संचालित हुई।"
    ),
    IEA(
        code = "IEA",
        hindiShortName = "आईईए (IEA)",
        hindiFullName = "भारतीय साक्ष्य अधिनियम, 1872",
        englishName = "Indian Evidence Act, 1872",
        year = 1872,
        isNewCriminalLaw = false,
        applicablePeriod = "पुराने मुकदमों के साक्ष्य निर्धारण में प्रासंगिक",
        totalChapters = 11,
        totalSections = 167,
        descriptionHindi = "1872 का मूल साक्ष्य कानून, जिसकी कई धाराएं (जैसे धारा 65B) ऐतिहासिक निर्णयों का आधार रही हैं।"
    );

    companion object {
        fun fromCode(code: String): LegalAct? = entries.firstOrNull { it.code.equals(code, ignoreCase = true) }
    }
}
