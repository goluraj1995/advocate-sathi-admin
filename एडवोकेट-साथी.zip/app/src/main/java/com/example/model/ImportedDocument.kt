package com.example.model

/**
 * Metadata for a selected local FIR document (PDF or Photo).
 * Note: In Milestone 1, no document is uploaded, sent to any server, or permanently stored.
 */
data class ImportedDocument(
    val uriString: String?,
    val fileName: String,
    val fileSizeFormatted: String,
    val fileType: DocumentType,
    val selectedTimestamp: Long = System.currentTimeMillis()
)

enum class DocumentType(val labelHindi: String) {
    PDF("पीडीएफ दस्तावेज़ (PDF)"),
    IMAGE("फोटो / स्कैन इमेज (Image)")
}
