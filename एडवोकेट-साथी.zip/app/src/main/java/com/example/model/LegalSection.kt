package com.example.model

/**
 * Data model for a legal section with clear indicator that demo data is illustrative.
 */
data class LegalSection(
    val id: String,
    val act: LegalAct,
    val sectionNumber: String,
    val titleHindi: String,
    val titleEnglish: String,
    val simpleExplanationHindi: String,
    val keyProvisionsHindi: List<String>,
    val samplePunishmentText: String,
    val isBailable: Boolean,
    val isCognizable: Boolean,
    val compoundableStatusHindi: String,
    val correspondingSectionInfo: String,
    val transitionalNoticeHindi: String = "धारा का लागू होना अपराध की घटना तिथि (1 जुलाई 2024 से पूर्व या पश्चात्) एवं विशिष्ट परिस्थितियों पर निर्भर करता है। वकील से परामर्श अनिवार्य है।",
    val isDemoData: Boolean = true
) {
    val bailableLabelHindi: String
        get() = if (isBailable) "जमानती (Bailable)" else "गैर-जमानती (Non-Bailable)"

    val cognizableLabelHindi: String
        get() = if (isCognizable) "संज्ञेय (Cognizable - पुलिस बिना वारंट गिरफ़्तारी कर सकती है)" else "असंज्ञेय (Non-Cognizable - वारंट आवश्यक)"
}
