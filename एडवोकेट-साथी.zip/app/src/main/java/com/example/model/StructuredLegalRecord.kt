package com.example.model

/**
 * Verification lifecycle status for legal records.
 * STRICT GATING: Only VERIFIED and PUBLISHED records may be described as verified to citizens.
 */
enum class VerificationStatus(
    val code: String,
    val labelHindi: String,
    val isOfficiallyVerified: Boolean
) {
    PUBLISHED("PUBLISHED", "प्रकाशित व सत्यापित", true),
    VERIFIED("VERIFIED", "आधिकारिक स्रोत से सत्यापित", true),
    NEEDS_REVIEW("NEEDS_REVIEW", "समीक्षाधीन (अपुष्ट)", false),
    DRAFT("DRAFT", "प्रारूप (Draft)", false),
    DEMO("DEMO", "नमूना / डेमो डेटा", false)
}

/**
 * Commencement status of an Act or specific section.
 */
enum class CommencementStatus(val labelHindi: String) {
    IN_FORCE("लागू (In Force)"),
    REPEALED_WITH_SAVINGS("निरसित किंतु पूर्ववर्ती मामलों में प्रभावी (Repealed with Savings)"),
    HELD_IN_ABEYANCE("अधिसूचना द्वारा स्थगित (Held in Abeyance)"),
    PENDING_NOTIFICATION("अधिसूचना प्रतीक्षित (Pending Notification)")
}

/**
 * Nature of cross-reference relationship between older and newer statutory provisions.
 * Sourced relationship modeling — never assumes absolute 1:1 equivalence.
 */
enum class CrossReferenceType(val labelHindi: String) {
    CORRESPONDING_PROVISION("समतुल्य पूर्ववर्ती / परवर्ती प्रावधान (Corresponding Provision)"),
    PARTIAL_OVERLAP("आंशिक सादृश्य व संशोधित दायरा (Partial Overlap)"),
    NEW_PROVISION_NO_PRIOR_EQUIVALENT("नवीन प्रावधान (New Provision / No Prior Equivalent)"),
    REPEALED_WITHOUT_REPLACEMENT("निरसित (Repealed / Omitted)")
}

/**
 * Cross-reference model connecting sections across statutory transitions.
 */
data class SectionCrossReference(
    val targetAct: LegalAct,
    val targetSectionNumber: String,
    val targetHeading: String,
    val relationshipType: CrossReferenceType,
    val applicabilityCaveat: String = "धारा का लागू होना अपराध की घटना तिथि (1 जुलाई 2024 से पूर्व या पश्चात्), संक्रमणकालीन नियमों (Transitional provisions) और विशिष्ट तथ्यों पर निर्भर करता है।",
    val statutoryAuthorityNote: String
)

/**
 * Structured, source-traceable legal record for Indian criminal laws.
 */
data class StructuredLegalRecord(
    val recordId: String,
    val act: LegalAct,
    val officialActTitle: String,
    val shortName: String,
    val actYear: Int,
    val sectionNumber: String,
    val officialHeading: String,
    val officialHeadingHindi: String,
    val officialTextOrApprovedSummary: String,
    val keyElements: List<String> = emptyList(),
    val bailableStatus: String? = null,
    val cognizableStatus: String? = null,
    val trialCourt: String? = null,
    val commencementStatus: CommencementStatus,
    val effectiveFrom: String?,
    val effectiveTo: String? = null,
    val sourceTitle: String,
    val officialSourceUrl: String?,
    val sourcePublicationOrGazetteDate: String?,
    val lastVerifiedAt: String?,
    val verificationStatus: VerificationStatus,
    val crossReferences: List<SectionCrossReference> = emptyList(),
    val applicabilityNotes: String,
    val proceduralCaveat: String = "यह प्रविष्टि सामान्य विधिक जानकारी हेतु है; यह अदालत का निर्णय या अधिवक्ता की राय नहीं है।"
)
