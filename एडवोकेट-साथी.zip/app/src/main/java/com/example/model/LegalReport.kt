package com.example.model

/**
 * Model representing a generated legal analysis report.
 * In Milestone 1, this represents a sample / demo report clearly marked as illustrative.
 */
data class LegalReport(
    val id: String,
    val title: String,
    val reportDate: String,
    val firDetailsSample: String,
    val policeStationSample: String,
    val sections: List<LegalSection>,
    val plainSummaryHindi: String,
    val citizenRightsHindi: List<String>,
    val recommendedNextStepsHindi: List<String>,
    val isDemo: Boolean = true
)
