package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.AdvocateTopAppBar
import com.example.ui.navigation.AppScreen
import com.example.ui.screens.ExtractedTextScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ImportFirScreen
import com.example.ui.screens.LegalLibraryScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SectionSearchScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AdvocateSathiTheme
import com.example.viewmodel.AdvocateViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AdvocateSathiTheme {
                AdvocateSathiApp()
            }
        }
    }
}

@Composable
fun AdvocateSathiApp(
    viewModel: AdvocateViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()

    // Global back handling
    BackHandler(enabled = uiState.currentScreen != AppScreen.Home || uiState.backStack.size > 1) {
        viewModel.navigateBack()
    }

    val topBarTitle = when (uiState.currentScreen) {
        AppScreen.Home -> "एडवोकेट साथी"
        AppScreen.ImportFir -> "एफआईआर दस्तावेज़"
        AppScreen.ExtractedText -> "एफआईआर टेक्स्ट समीक्षा"
        AppScreen.SectionSearch -> "कानून की धारा खोजें"
        AppScreen.Reports -> "कानूनी रिपोर्ट"
        AppScreen.LegalLibrary -> "कानून पुस्तकालय"
        AppScreen.Settings -> "नियम व शर्तें"
    }

    val topBarSubtitle = when (uiState.currentScreen) {
        AppScreen.Home -> "FIR और कानून को सरल हिंदी में समझें"
        AppScreen.ImportFir -> "सुरक्षित ऑन-डिवाइस चयन"
        AppScreen.ExtractedText -> "विवरण जाँचें व सुधारें"
        AppScreen.SectionSearch -> "BNS, BNSS, BSA, IPC, CrPC"
        AppScreen.Reports -> "नागरिक अधिकार व प्रक्रिया"
        AppScreen.LegalLibrary -> "6 प्रमुख आपराधिक संहिताएँ"
        AppScreen.Settings -> "गोपनीयता, अस्वीकरण व संस्करण"
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            AdvocateTopAppBar(
                title = topBarTitle,
                subtitle = topBarSubtitle,
                showBackButton = uiState.currentScreen != AppScreen.Home,
                onBackClick = { viewModel.navigateBack() },
                onInfoClick = if (uiState.currentScreen != AppScreen.Settings) {
                    { viewModel.navigateTo(AppScreen.Settings) }
                } else null
            )
        },
        bottomBar = {
            NavigationBar(
                windowInsets = WindowInsets.navigationBars,
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                modifier = Modifier.testTag("bottom_nav_bar")
            ) {
                AppScreen.bottomNavItems.forEach { screen ->
                    val isSelected = uiState.currentScreen == screen
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.navigateTo(screen) },
                        icon = {
                            Icon(
                                imageVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon,
                                contentDescription = screen.titleHindi
                            )
                        },
                        label = {
                            Text(
                                text = screen.titleHindi,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 11.sp
                                )
                            )
                        },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedTextColor = MaterialTheme.colorScheme.primary,
                            indicatorColor = MaterialTheme.colorScheme.primaryContainer,
                            unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        modifier = Modifier.testTag("nav_item_${screen.route}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentAlignment = Alignment.TopCenter
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 760.dp)
            ) {
                when (uiState.currentScreen) {
                    AppScreen.Home -> HomeScreen(
                        uiState = uiState,
                        onNavigate = { viewModel.navigateTo(it) }
                    )

                    AppScreen.ImportFir -> ImportFirScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )

                    AppScreen.ExtractedText -> ExtractedTextScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )

                    AppScreen.SectionSearch -> SectionSearchScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { viewModel.navigateBack() }
                    )

                    AppScreen.Reports -> ReportsScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onNavigate = { viewModel.navigateTo(it) },
                        onBack = { viewModel.navigateBack() }
                    )

                    AppScreen.LegalLibrary -> LegalLibraryScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { viewModel.navigateBack() }
                    )

                    AppScreen.Settings -> SettingsScreen(
                        uiState = uiState,
                        viewModel = viewModel,
                        onBack = { viewModel.navigateBack() }
                    )
                }
            }
        }
    }
}
