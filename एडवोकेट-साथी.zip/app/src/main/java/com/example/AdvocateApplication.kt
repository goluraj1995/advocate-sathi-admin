package com.example

import android.app.Application
import android.util.Log
import com.example.data.OfficialLegalRepository
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader

class AdvocateApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            PDFBoxResourceLoader.init(applicationContext)
        } catch (e: Exception) {
            Log.e("AdvocateApp", "Failed to initialize PDFBoxResourceLoader", e)
        }

        try {
            OfficialLegalRepository.initialize(applicationContext)
        } catch (e: Exception) {
            Log.e("AdvocateApp", "Failed to initialize OfficialLegalRepository from local storage", e)
        }
    }
}
