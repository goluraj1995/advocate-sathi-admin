package com.example.pdf

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.core.content.FileProvider
import com.example.model.StructuredLegalRecord
import com.example.model.VerificationStatus
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Input configuration and data for generating the genuine on-device PDF report.
 */
data class PdfReportData(
    val reportTitle: String = "दस्तावेज़ समीक्षा रिपोर्ट",
    val appName: String = "एडवोकेट साथी",
    val generationDate: String = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale("hi", "IN")).format(Date()),
    val documentName: String? = null,
    val documentTypeLabel: String? = null,
    val extractionMethodLabel: String? = null,
    val pagesProcessed: Int = 0,
    val firText: String? = null,
    val includeFirText: Boolean = false,
    val linkedSections: List<StructuredLegalRecord> = emptyList(),
    val isDemoData: Boolean = false
)

/**
 * Result of the on-device PDF generation process.
 */
data class PdfGenerationResult(
    val success: Boolean,
    val pageCount: Int = 0,
    val totalBytes: Long = 0L,
    val shareUri: Uri? = null,
    val errorMessage: String? = null
)

/**
 * Genuine on-device PDF report generator for Advocate Sathi ("एडवोकेट साथी").
 * Uses Android's built-in android.graphics.pdf.PdfDocument and StaticLayout for robust
 * Devanagari (Hindi) and Latin typography, line wrapping, pagination, and visual hierarchy.
 *
 * SAFETY GUARANTEES:
 * - 100% On-device execution with zero network transmission.
 * - Sourced legal verification statuses (VERIFIED vs NEEDS_REVIEW vs DEMO) are prominently rendered.
 * - Mandatory disclaimer that this is informational and not formal legal advice, nor does it guarantee bail.
 */
class LocalPdfReportGenerator(private val context: Context) {

    companion object {
        // Standard A4 dimensions in typographic points (72 points = 1 inch)
        const val PAGE_WIDTH = 595
        const val PAGE_HEIGHT = 842

        // Margins & content bounds
        const val MARGIN_LEFT = 40f
        const val MARGIN_RIGHT = 40f
        const val MARGIN_TOP = 40f
        const val MARGIN_BOTTOM = 40f
        const val CONTENT_WIDTH = (PAGE_WIDTH - MARGIN_LEFT - MARGIN_RIGHT).toInt() // 515 pt

        // Vertical content limits per page (between header divider and footer divider)
        const val CONTENT_START_Y = 82f
        const val CONTENT_END_Y = 796f
        const val MAX_CONTENT_HEIGHT = CONTENT_END_Y - CONTENT_START_Y // 714 pt

        // Brand colors (Hex ARGB)
        val COLOR_BRAND_DARK_GREEN = Color.parseColor("#1B3E20")
        val COLOR_BRAND_MED_GREEN = Color.parseColor("#2E5C35")
        val COLOR_GOLD_ACCENT = Color.parseColor("#C29B38")
        val COLOR_TEXT_PRIMARY = Color.parseColor("#1C1B1F")
        val COLOR_TEXT_SECONDARY = Color.parseColor("#49454F")
        val COLOR_TEXT_MUTED = Color.parseColor("#79747E")
        val COLOR_DIVIDER = Color.parseColor("#D0D5DD")
        val COLOR_BG_LIGHT_GREEN = Color.parseColor("#EBF3EC")
        val COLOR_BG_WARNING_AMBER = Color.parseColor("#FFF4E5")
        val COLOR_WARNING_AMBER = Color.parseColor("#B54708")
        val COLOR_BG_DEMO_BLUE = Color.parseColor("#EFF8FF")
        val COLOR_DEMO_BLUE = Color.parseColor("#175CD3")
        val COLOR_CARD_BORDER = Color.parseColor("#EAECF0")
    }

    // Text paints initialized with system sans-serif which includes Noto Sans Devanagari
    private val appTitlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = COLOR_BRAND_DARK_GREEN
        textSize = 15f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    private val reportTitlePaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = COLOR_BRAND_DARK_GREEN
        textSize = 18f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    private val sectionHeaderPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = COLOR_BRAND_DARK_GREEN
        textSize = 13f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    private val bodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = COLOR_TEXT_PRIMARY
        textSize = 9.5f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
    }

    private val boldBodyPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = COLOR_TEXT_PRIMARY
        textSize = 9.5f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    private val captionPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        color = COLOR_TEXT_SECONDARY
        textSize = 8.5f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
    }

    private val badgeTextPaint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 8f
        typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    }

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = COLOR_DIVIDER
        strokeWidth = 0.75f
    }

    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 0.75f
    }

    /**
     * Generates a complete PDF into the supplied OutputStream (e.g. from SAF Uri).
     * Prefers Android's native android.graphics.pdf.PdfDocument with Skia vector rendering,
     * seamlessly falling back to standard ISO 32000-1 Canvas raster rendering in environments
     * without native Skia PDF bindings (e.g. Robolectric JVM tests).
     */
    fun generateToStream(data: PdfReportData, outputStream: OutputStream): PdfGenerationResult {
        return try {
            generateWithNativePdfDocument(data, outputStream)
        } catch (e: Exception) {
            val message = e.message ?: ""
            if (e is IllegalStateException && (message.contains("document is closed") || message.contains("mNativeDocument"))) {
                // JVM / Robolectric environment where native Skia PDF engine is unbound
                generateFallbackPdf(data, outputStream)
            } else {
                val sw = java.io.StringWriter()
                e.printStackTrace(java.io.PrintWriter(sw))
                PdfGenerationResult(
                    success = false,
                    errorMessage = sw.toString()
                )
            }
        }
    }

    private fun generateWithNativePdfDocument(data: PdfReportData, outputStream: OutputStream): PdfGenerationResult {
        val pdfDocument = PdfDocument()
        val pages = layoutReportPages(data)
        val totalPages = pages.size.coerceAtLeast(1)

        pages.forEachIndexed { index, pageItems ->
            val pageIndex = index + 1
            val pageInfo = PdfDocument.PageInfo.Builder(PAGE_WIDTH, PAGE_HEIGHT, pageIndex).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas

            // 1. Draw persistent Header
            drawHeader(canvas, data, pageIndex)

            // 2. Draw Page Content Items
            var currentY = CONTENT_START_Y
            for (item in pageItems) {
                currentY += item.draw(canvas, MARGIN_LEFT, currentY, CONTENT_WIDTH.toFloat())
            }

            // 3. Draw persistent Footer
            drawFooter(canvas, pageIndex, totalPages)

            pdfDocument.finishPage(page)
        }

        var bytesWritten = 0L
        val countingStream = object : OutputStream() {
            override fun write(b: Int) {
                outputStream.write(b)
                bytesWritten++
            }

            override fun write(b: ByteArray, off: Int, len: Int) {
                outputStream.write(b, off, len)
                bytesWritten += len
            }

            override fun flush() {
                outputStream.flush()
            }

            override fun close() {
                outputStream.close()
            }
        }

        pdfDocument.writeTo(countingStream)
        pdfDocument.close()

        return PdfGenerationResult(
            success = true,
            pageCount = totalPages,
            totalBytes = bytesWritten
        )
    }

    private fun generateFallbackPdf(data: PdfReportData, outputStream: OutputStream): PdfGenerationResult {
        return try {
            val pages = layoutReportPages(data)
            val totalPages = pages.size.coerceAtLeast(1)
            val jpegPages = mutableListOf<ByteArray>()

            for ((index, pageItems) in pages.withIndex()) {
                val pageIndex = index + 1
                val bitmap = Bitmap.createBitmap(PAGE_WIDTH, PAGE_HEIGHT, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                canvas.drawColor(Color.WHITE)

                drawHeader(canvas, data, pageIndex)
                var currentY = CONTENT_START_Y
                for (item in pageItems) {
                    currentY += item.draw(canvas, MARGIN_LEFT, currentY, CONTENT_WIDTH.toFloat())
                }
                drawFooter(canvas, pageIndex, totalPages)

                val baos = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 90, baos)
                bitmap.recycle()
                jpegPages.add(baos.toByteArray())
            }

            val writtenBytes = writeJpegPdfToStream(jpegPages, PAGE_WIDTH, PAGE_HEIGHT, outputStream)
            PdfGenerationResult(
                success = true,
                pageCount = totalPages,
                totalBytes = writtenBytes
            )
        } catch (e: Exception) {
            val sw = java.io.StringWriter()
            e.printStackTrace(java.io.PrintWriter(sw))
            PdfGenerationResult(
                success = false,
                errorMessage = sw.toString()
            )
        }
    }

    private fun writeJpegPdfToStream(
        jpegPages: List<ByteArray>,
        pageWidth: Int,
        pageHeight: Int,
        out: OutputStream
    ): Long {
        val countingOut = CountingOutputStream(out)
        val offsets = mutableListOf<Long>()

        countingOut.writeAscii("%PDF-1.4\r\n%\u00E2\u00E3\u00CF\u00D3\r\n")

        val n = jpegPages.size
        val totalObjects = 2 + 3 * n

        offsets.add(0L)

        // Object 1: Catalog
        offsets.add(countingOut.bytesWritten)
        countingOut.writeAscii("1 0 obj\r\n<< /Type /Catalog /Pages 2 0 R >>\r\nendobj\r\n")

        // Object 2: Pages tree
        offsets.add(countingOut.bytesWritten)
        val kidsStr = (0 until n).joinToString(" ") { "${3 + 3 * it} 0 R" }
        countingOut.writeAscii("2 0 obj\r\n<< /Type /Pages /Kids [ $kidsStr ] /Count $n >>\r\nendobj\r\n")

        // Per-page objects
        for (i in 0 until n) {
            val pageObjId = 3 + 3 * i
            val imgObjId = pageObjId + 1
            val contentObjId = pageObjId + 2
            val jpegData = jpegPages[i]

            val drawCommand = "q $pageWidth 0 0 $pageHeight 0 0 cm /Im$i Do Q\r\n"
            val drawCommandBytes = drawCommand.toByteArray(Charsets.US_ASCII)

            // Page Object
            offsets.add(countingOut.bytesWritten)
            countingOut.writeAscii(
                "$pageObjId 0 obj\r\n<< /Type /Page /Parent 2 0 R /MediaBox [ 0 0 $pageWidth $pageHeight ] " +
                "/Resources << /XObject << /Im$i $imgObjId 0 R >> /ProcSet [ /PDF /ImageC ] >> " +
                "/Contents $contentObjId 0 R >>\r\nendobj\r\n"
            )

            // Image XObject
            offsets.add(countingOut.bytesWritten)
            countingOut.writeAscii(
                "$imgObjId 0 obj\r\n<< /Type /XObject /Subtype /Image /Width $pageWidth /Height $pageHeight " +
                "/ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${jpegData.size} >>\r\nstream\r\n"
            )
            countingOut.write(jpegData)
            countingOut.writeAscii("\r\nendstream\r\nendobj\r\n")

            // Content Stream Object
            offsets.add(countingOut.bytesWritten)
            countingOut.writeAscii(
                "$contentObjId 0 obj\r\n<< /Length ${drawCommandBytes.size} >>\r\nstream\r\n"
            )
            countingOut.write(drawCommandBytes)
            countingOut.writeAscii("endstream\r\nendobj\r\n")
        }

        // Cross-reference table
        val xrefOffset = countingOut.bytesWritten
        countingOut.writeAscii("xref\r\n0 ${totalObjects + 1}\r\n")
        countingOut.writeAscii("0000000000 65535 f \r\n")
        for (i in 1..totalObjects) {
            val offsetStr = String.format(Locale.US, "%010d 00000 n \r\n", offsets[i])
            countingOut.writeAscii(offsetStr)
        }

        // Trailer
        countingOut.writeAscii(
            "trailer\r\n<< /Size ${totalObjects + 1} /Root 1 0 R >>\r\nstartxref\r\n$xrefOffset\r\n%%EOF\r\n"
        )
        countingOut.flush()
        return countingOut.bytesWritten
    }

    private class CountingOutputStream(private val wrapped: OutputStream) : OutputStream() {
        var bytesWritten = 0L

        fun writeAscii(s: String) {
            val bytes = s.toByteArray(Charsets.US_ASCII)
            write(bytes)
        }

        override fun write(b: Int) {
            wrapped.write(b)
            bytesWritten++
        }

        override fun write(b: ByteArray, off: Int, len: Int) {
            wrapped.write(b, off, len)
            bytesWritten += len
        }

        override fun flush() {
            wrapped.flush()
        }

        override fun close() {
            wrapped.close()
        }
    }

    /**
     * Cleans up stale temporary report files from the cache directory.
     * Removes files older than maxAgeMillis (default: 1 hour) or retains at most maxFiles.
     */
    fun cleanupStaleReports(
        reportsDir: File = File(context.cacheDir, "reports"),
        maxAgeMillis: Long = 60 * 60 * 1000L,
        maxRetainedFiles: Int = 5
    ) {
        try {
            if (reportsDir.exists() && reportsDir.isDirectory) {
                val files = reportsDir.listFiles() ?: return
                val now = System.currentTimeMillis()
                val sortedFiles = files.filter { it.isFile }.sortedByDescending { it.lastModified() }
                sortedFiles.forEachIndexed { index, file ->
                    if (index >= maxRetainedFiles || (now - file.lastModified() > maxAgeMillis)) {
                        file.delete()
                    }
                }
            }
        } catch (_: Exception) {
            // Ignore non-fatal cache cleanup errors
        }
    }

    /**
     * Generates a temporary report PDF and returns a secure FileProvider Uri for sharing.
     */
    fun generateForShare(data: PdfReportData): PdfGenerationResult {
        return try {
            val reportsDir = File(context.cacheDir, "reports")
            if (!reportsDir.exists()) {
                reportsDir.mkdirs()
            }
            // Safely prune older temporary report files to protect device storage
            cleanupStaleReports(reportsDir)

            val fileName = "AdvocateSathi_Report_${System.currentTimeMillis()}.pdf"
            val targetFile = File(reportsDir, fileName)

            val result = FileOutputStream(targetFile).use { fos ->
                generateToStream(data, fos)
            }

            if (result.success) {
                val uri = try {
                    FileProvider.getUriForFile(
                        context,
                        "${com.example.BuildConfig.APPLICATION_ID}.fileprovider",
                        targetFile
                    )
                } catch (e: Exception) {
                    FileProvider.getUriForFile(
                        context,
                        "${context.packageName}.fileprovider",
                        targetFile
                    )
                }
                result.copy(shareUri = uri)
            } else {
                result
            }
        } catch (e: Exception) {
            PdfGenerationResult(
                success = false,
                errorMessage = e.localizedMessage ?: "शेयर हेतु PDF तैयार करने में विफलता।"
            )
        }
    }

    // =========================================================================
    // PAGE LAYOUT ENGINE & PAGINATION
    // =========================================================================

    private fun layoutReportPages(data: PdfReportData): List<List<RenderableItem>> {
        val allItems = mutableListOf<RenderableItem>()

        // 1. Report Title and Subtitle Block
        allItems.add(TitleBlockItem(data.reportTitle, data.isDemoData))

        // 2. Mandatory Legal and Safety Disclaimer Banner
        allItems.add(
            LegalNoticeBannerItem(
                noticeTitle = "महत्वपूर्ण विधिक एवं तकनीकी सूचना (Mandatory Legal Notice)",
                notices = listOf(
                    "यह रिपोर्ट ऑन-डिवाइस सामान्य विधिक जागरूकता एवं संदर्भ हेतु स्वतः संकलित की गई है।",
                    "यह किसी न्यायालय का फैसला, विधिक सलाह (Legal Advice) या अधिवक्ता की राय नहीं है।",
                    "यह रिपोर्ट किसी भी पक्ष की दोषसिद्धि तय नहीं करती और न ही ज़मानत (Bail) की कोई गारंटी देती है।",
                    "ऑन-डिवाइस OCR निष्कर्षण में हस्तलेखन अथवा धुंधले स्कैन के कारण अशुद्धियाँ संभव हैं; मूल दस्तावेज़ से मिलान अवश्य करें।"
                )
            )
        )

        // 3. Document Details & Metadata Block
        allItems.add(
            MetadataCardItem(
                metadata = listOf(
                    "तैयार करने की तिथि" to data.generationDate,
                    "दस्तावेज़ का नाम" to (data.documentName ?: "सीधे प्रविष्ट / संपादित पाठ"),
                    "दस्तावेज़ का प्रकार" to (data.documentTypeLabel ?: "डिजिटल / टेक्स्ट"),
                    "निष्कर्षण तकनीक" to (data.extractionMethodLabel ?: "मैन्युअल प्रविष्टि"),
                    "विश्लेषित पृष्ठ" to "${data.pagesProcessed.coerceAtLeast(1)} पृष्ठ"
                )
            )
        )

        // 4. Extracted FIR Text (if requested by user via toggle)
        if (data.includeFirText && !data.firText.isNullOrBlank()) {
            allItems.add(SectionHeadingItem("1. प्राथमिकी (FIR) का निकाला गया पाठ", "उपयोगकर्ता द्वारा समीक्षित एवं संपादित पाठ"))
            // Break long text into paragraphs so it wraps across pages without overflowing
            val paragraphs = data.firText.split("\n\n", "\n").filter { it.isNotBlank() }
            if (paragraphs.isEmpty()) {
                allItems.add(FirTextParagraphItem(data.firText.trim()))
            } else {
                for (para in paragraphs) {
                    allItems.add(FirTextParagraphItem(para.trim()))
                }
            }
        }

        // 5. Linked Legal Sections Block
        val sectionIndexPrefix = if (data.includeFirText && !data.firText.isNullOrBlank()) "2" else "1"
        allItems.add(
            SectionHeadingItem(
                "$sectionIndexPrefix. समीक्षित कानूनी धाराएँ एवं आधिकारिक प्रावधान",
                "प्राथमिकी संदर्भ एवं आधिकारिक विधायी स्थिति (India Code / Gazette of India)"
            )
        )

        if (data.linkedSections.isEmpty()) {
            allItems.add(
                EmptySectionsNoticeItem(
                    title = "कोई विधिक धारा संबद्ध नहीं है",
                    message = "वर्तमान में इस दस्तावेज़ से कोई विशिष्ट धारा संबद्ध नहीं की गई है। धारा खोज (Section Search) से संबंधित धाराओं को देख सकते हैं।"
                )
            )
        } else {
            for (record in data.linkedSections) {
                allItems.add(LegalRecordCardItem(record))
            }
        }

        // 6. Citizen Rights & Guidance Notice
        allItems.add(
            GuidanceBoxItem(
                title = "नागरिक के लिए विधिक मार्गदर्शन एवं अग्रिम कदम",
                steps = listOf(
                    "प्राथमिकी की एक प्रति (Free FIR Copy) प्राप्त करना प्रत्येक नागरिक का वैधानिक अधिकार है (BNSS धारा 173(2) / CrPC धारा 154(2))।",
                    "यदि गिरफ्तारी की स्थिति उत्पन्न होती है, तो गिरफ्तारी का कारण जानने तथा अपने अधिवक्ता से मिलने का अधिकार है (BNSS धारा 37, 38 / संविधान अनुच्छेद 22)।",
                    "किसी भी कानूनी कदम या अदालत में पेशी से पूर्व योग्य अधिवक्ता अथवा ज़िला विधिक सेवा प्राधिकरण (DLSA - मुफ़्त कानूनी सहायता) से संपर्क करें।"
                )
            )
        )

        // Greedy multi-page packing
        val pages = mutableListOf<MutableList<RenderableItem>>()
        var currentPage = mutableListOf<RenderableItem>()
        var remainingHeight = MAX_CONTENT_HEIGHT

        for (item in allItems) {
            val itemHeight = item.measureHeight(CONTENT_WIDTH.toFloat())
            if (itemHeight <= remainingHeight) {
                currentPage.add(item)
                remainingHeight -= itemHeight
            } else {
                // If current page already has items, push to new page
                if (currentPage.isNotEmpty()) {
                    pages.add(currentPage)
                    currentPage = mutableListOf()
                    remainingHeight = MAX_CONTENT_HEIGHT
                }
                currentPage.add(item)
                remainingHeight -= itemHeight
            }
        }

        if (currentPage.isNotEmpty()) {
            pages.add(currentPage)
        }

        return pages
    }

    // =========================================================================
    // HEADER & FOOTER RENDERING
    // =========================================================================

    private fun drawHeader(canvas: Canvas, data: PdfReportData, pageIndex: Int) {
        // App brand name
        canvas.drawText("एडवोकेट साथी", MARGIN_LEFT, 54f, appTitlePaint)

        // Subtitle & app tag
        val tagPaint = TextPaint(captionPaint).apply { color = COLOR_BRAND_MED_GREEN }
        canvas.drawText("ऑन-डिवाइस कानूनी सहायता प्रणाली", MARGIN_LEFT, 67f, tagPaint)

        // Date right-aligned
        val dateText = "दिनांक: ${data.generationDate}"
        val dateWidth = captionPaint.measureText(dateText)
        canvas.drawText(dateText, PAGE_WIDTH - MARGIN_RIGHT - dateWidth, 54f, captionPaint)

        // Subtle Gold accent line under brand
        fillPaint.color = COLOR_GOLD_ACCENT
        canvas.drawRect(MARGIN_LEFT, 72f, MARGIN_LEFT + 120f, 74f, fillPaint)

        // Full width divider
        canvas.drawLine(MARGIN_LEFT, 75f, PAGE_WIDTH - MARGIN_RIGHT, 75f, linePaint)
    }

    private fun drawFooter(canvas: Canvas, pageIndex: Int, totalPages: Int) {
        // Top divider
        canvas.drawLine(MARGIN_LEFT, 804f, PAGE_WIDTH - MARGIN_RIGHT, 804f, linePaint)

        // Left disclaimer
        canvas.drawText(
            "एडवोकेट साथी • ऑन-डिवाइस समीक्षा • विधिक सलाह नहीं है",
            MARGIN_LEFT,
            818f,
            captionPaint
        )

        // Right page number
        val pageText = "पृष्ठ $pageIndex / $totalPages"
        val pageWidth = boldBodyPaint.measureText(pageText)
        canvas.drawText(pageText, PAGE_WIDTH - MARGIN_RIGHT - pageWidth, 818f, boldBodyPaint)
    }

    // =========================================================================
    // RENDERABLE ITEMS INTERFACE & IMPLEMENTATIONS
    // =========================================================================

    private interface RenderableItem {
        fun measureHeight(contentWidth: Float): Float
        fun draw(canvas: Canvas, startX: Float, startY: Float, contentWidth: Float): Float
    }

    /**
     * Main Title Banner
     */
    private inner class TitleBlockItem(
        private val title: String,
        private val isDemo: Boolean
    ) : RenderableItem {
        override fun measureHeight(contentWidth: Float): Float = 36f

        override fun draw(canvas: Canvas, startX: Float, startY: Float, contentWidth: Float): Float {
            val titleY = startY + 20f
            canvas.drawText(title, startX, titleY, reportTitlePaint)

            if (isDemo) {
                val demoText = " [डेमो रिपोर्ट / DEMO] "
                val titleWidth = reportTitlePaint.measureText(title)
                val demoPaint = TextPaint(badgeTextPaint).apply { color = COLOR_WARNING_AMBER }
                canvas.drawText(demoText, startX + titleWidth + 10f, titleY, demoPaint)
            }
            return measureHeight(contentWidth)
        }
    }

    /**
     * Mandatory Legal & Technical Notice Banner
     */
    private inner class LegalNoticeBannerItem(
        private val noticeTitle: String,
        private val notices: List<String>
    ) : RenderableItem {
        private var cachedHeight: Float = 0f

        override fun measureHeight(contentWidth: Float): Float {
            var h = 18f // Title height + top padding
            for (line in notices) {
                val layout = createStaticLayout("• $line", captionPaint, (contentWidth - 24).toInt())
                h += layout.height + 3f
            }
            cachedHeight = h + 14f // bottom padding
            return cachedHeight
        }

        override fun draw(canvas: Canvas, startX: Float, startY: Float, contentWidth: Float): Float {
            val h = if (cachedHeight > 0f) cachedHeight else measureHeight(contentWidth)
            val rect = RectF(startX, startY + 4f, startX + contentWidth, startY + h)

            // Warning background
            fillPaint.color = COLOR_BG_WARNING_AMBER
            canvas.drawRoundRect(rect, 6f, 6f, fillPaint)

            strokePaint.color = COLOR_WARNING_AMBER
            canvas.drawRoundRect(rect, 6f, 6f, strokePaint)

            // Title
            val titlePaint = TextPaint(boldBodyPaint).apply { color = COLOR_WARNING_AMBER }
            canvas.drawText(noticeTitle, startX + 10f, startY + 18f, titlePaint)

            var curY = startY + 28f
            for (line in notices) {
                val layout = createStaticLayout("• $line", captionPaint, (contentWidth - 20).toInt())
                canvas.save()
                canvas.translate(startX + 10f, curY)
                layout.draw(canvas)
                canvas.restore()
                curY += layout.height + 3f
            }

            return h + 8f
        }
    }

    /**
     * Document Metadata Card
     */
    private inner class MetadataCardItem(
        private val metadata: List<Pair<String, String>>
    ) : RenderableItem {
        override fun measureHeight(contentWidth: Float): Float {
            return (metadata.size * 16f) + 24f
        }

        override fun draw(canvas: Canvas, startX: Float, startY: Float, contentWidth: Float): Float {
            val h = measureHeight(contentWidth)
            val rect = RectF(startX, startY + 4f, startX + contentWidth, startY + h)

            fillPaint.color = Color.parseColor("#F8F9FA")
            canvas.drawRoundRect(rect, 6f, 6f, fillPaint)

            strokePaint.color = COLOR_DIVIDER
            canvas.drawRoundRect(rect, 6f, 6f, strokePaint)

            var curY = startY + 18f
            for ((key, value) in metadata) {
                canvas.drawText(key, startX + 12f, curY, captionPaint)
                canvas.drawText(":", startX + 120f, curY, captionPaint)
                canvas.drawText(value, startX + 130f, curY, boldBodyPaint)
                curY += 16f
            }

            return h + 8f
        }
    }

    /**
     * Section Heading Item
     */
    private inner class SectionHeadingItem(
        private val title: String,
        private val subtitle: String?
    ) : RenderableItem {
        override fun measureHeight(contentWidth: Float): Float {
            return if (subtitle != null) 34f else 24f
        }

        override fun draw(canvas: Canvas, startX: Float, startY: Float, contentWidth: Float): Float {
            canvas.drawText(title, startX, startY + 16f, sectionHeaderPaint)
            if (subtitle != null) {
                canvas.drawText(subtitle, startX, startY + 28f, captionPaint)
            }
            return measureHeight(contentWidth)
        }
    }

    /**
     * FIR Extracted Text Paragraph
     */
    private inner class FirTextParagraphItem(private val text: String) : RenderableItem {
        private var cachedLayout: StaticLayout? = null

        private fun getLayout(contentWidth: Float): StaticLayout {
            val existing = cachedLayout
            if (existing != null) return existing
            val l = createStaticLayout(text, bodyPaint, (contentWidth - 24).toInt())
            cachedLayout = l
            return l
        }

        override fun measureHeight(contentWidth: Float): Float {
            val layout = getLayout(contentWidth)
            return layout.height + 14f
        }

        override fun draw(canvas: Canvas, startX: Float, startY: Float, contentWidth: Float): Float {
            val layout = getLayout(contentWidth)
            val h = layout.height + 10f
            val rect = RectF(startX, startY + 2f, startX + contentWidth, startY + h)

            // Text background
            fillPaint.color = Color.parseColor("#FAFAFA")
            canvas.drawRoundRect(rect, 4f, 4f, fillPaint)

            strokePaint.color = Color.parseColor("#E0E0E0")
            canvas.drawRoundRect(rect, 4f, 4f, strokePaint)

            canvas.save()
            canvas.translate(startX + 12f, startY + 6f)
            layout.draw(canvas)
            canvas.restore()

            return h + 6f
        }
    }

    /**
     * Legal Record Box
     */
    private inner class LegalRecordCardItem(
        private val record: StructuredLegalRecord
    ) : RenderableItem {
        private var cachedHeight: Float = 0f

        override fun measureHeight(contentWidth: Float): Float {
            var h = 30f // Top header + badge

            // Summary text layout
            val summaryLayout = createStaticLayout(
                record.officialTextOrApprovedSummary,
                bodyPaint,
                (contentWidth - 24).toInt()
            )
            h += summaryLayout.height + 8f

            // Statutory details (Bailable, Cognizable, Court)
            h += 16f

            // Official source line
            val sourceText = "स्रोत: ${record.sourceTitle}${if (record.officialSourceUrl != null) " • " + record.officialSourceUrl else ""}"
            val sourceLayout = createStaticLayout(sourceText, captionPaint, (contentWidth - 24).toInt())
            h += sourceLayout.height + 6f

            // Verification date & caveat
            val caveatLayout = createStaticLayout("टिप्पणी: ${record.applicabilityNotes}", captionPaint, (contentWidth - 24).toInt())
            h += caveatLayout.height + 18f

            cachedHeight = h
            return cachedHeight
        }

        override fun draw(canvas: Canvas, startX: Float, startY: Float, contentWidth: Float): Float {
            val h = if (cachedHeight > 0f) cachedHeight else measureHeight(contentWidth)
            val rect = RectF(startX, startY + 4f, startX + contentWidth, startY + h)

            fillPaint.color = Color.WHITE
            canvas.drawRoundRect(rect, 6f, 6f, fillPaint)

            strokePaint.color = COLOR_CARD_BORDER
            canvas.drawRoundRect(rect, 6f, 6f, strokePaint)

            // Section Header title
            val headerTitle = "${record.act.code} धारा ${record.sectionNumber}: ${record.officialHeadingHindi}"
            canvas.drawText(headerTitle, startX + 12f, startY + 20f, boldBodyPaint)

            // Verification Badge
            drawVerificationBadge(canvas, record.verificationStatus, startX + contentWidth - 160f, startY + 10f)

            var curY = startY + 34f

            // Official summary
            val summaryLayout = createStaticLayout(
                record.officialTextOrApprovedSummary,
                bodyPaint,
                (contentWidth - 24).toInt()
            )
            canvas.save()
            canvas.translate(startX + 12f, curY)
            summaryLayout.draw(canvas)
            canvas.restore()
            curY += summaryLayout.height + 8f

            // Legal classification attributes
            val bailable = record.bailableStatus ?: "अपुष्ट"
            val cognizable = record.cognizableStatus ?: "अपुष्ट"
            val court = record.trialCourt ?: "अपुष्ट"
            val classLine = "ज़मानत: $bailable  |  संज्ञेयता: $cognizable  |  विचारण: $court"
            canvas.drawText(classLine, startX + 12f, curY + 8f, captionPaint)
            curY += 16f

            // Source
            val sourceText = "स्रोत: ${record.sourceTitle}${if (record.officialSourceUrl != null) " • " + record.officialSourceUrl else ""}"
            val sourceLayout = createStaticLayout(sourceText, captionPaint, (contentWidth - 24).toInt())
            canvas.save()
            canvas.translate(startX + 12f, curY)
            sourceLayout.draw(canvas)
            canvas.restore()
            curY += sourceLayout.height + 4f

            // Applicability Notes
            val caveatText = "टिप्पणी: ${record.applicabilityNotes}"
            val caveatLayout = createStaticLayout(caveatText, captionPaint, (contentWidth - 24).toInt())
            canvas.save()
            canvas.translate(startX + 12f, curY)
            caveatLayout.draw(canvas)
            canvas.restore()

            return h + 8f
        }

        private fun drawVerificationBadge(
            canvas: Canvas,
            status: VerificationStatus,
            badgeX: Float,
            badgeY: Float
        ) {
            val badgeWidth = 148f
            val badgeHeight = 16f
            val badgeRect = RectF(badgeX, badgeY, badgeX + badgeWidth, badgeY + badgeHeight)

            val (bgColor, textColor, label) = when (status) {
                VerificationStatus.PUBLISHED, VerificationStatus.VERIFIED ->
                    Triple(COLOR_BG_LIGHT_GREEN, COLOR_BRAND_MED_GREEN, "✓ राजपत्र से सत्यापित")
                VerificationStatus.NEEDS_REVIEW ->
                    Triple(COLOR_BG_WARNING_AMBER, COLOR_WARNING_AMBER, "⚠ समीक्षाधीन (अपुष्ट)")
                VerificationStatus.DEMO, VerificationStatus.DRAFT ->
                    Triple(COLOR_BG_DEMO_BLUE, COLOR_DEMO_BLUE, "ⓘ नमूना डेटा (Demo)")
            }

            fillPaint.color = bgColor
            canvas.drawRoundRect(badgeRect, 3f, 3f, fillPaint)

            badgeTextPaint.color = textColor
            canvas.drawText(label, badgeX + 6f, badgeY + 11.5f, badgeTextPaint)
        }
    }

    /**
     * Guidance box with next steps
     */
    private inner class GuidanceBoxItem(
        private val title: String,
        private val steps: List<String>
    ) : RenderableItem {
        override fun measureHeight(contentWidth: Float): Float {
            var h = 24f
            for (step in steps) {
                val layout = createStaticLayout("✓ $step", captionPaint, (contentWidth - 24).toInt())
                h += layout.height + 4f
            }
            return h + 12f
        }

        override fun draw(canvas: Canvas, startX: Float, startY: Float, contentWidth: Float): Float {
            val h = measureHeight(contentWidth)
            val rect = RectF(startX, startY + 4f, startX + contentWidth, startY + h)

            fillPaint.color = COLOR_BG_LIGHT_GREEN
            canvas.drawRoundRect(rect, 6f, 6f, fillPaint)

            strokePaint.color = COLOR_BRAND_MED_GREEN
            canvas.drawRoundRect(rect, 6f, 6f, strokePaint)

            val titlePaint = TextPaint(boldBodyPaint).apply { color = COLOR_BRAND_DARK_GREEN }
            canvas.drawText(title, startX + 12f, startY + 18f, titlePaint)

            var curY = startY + 26f
            for (step in steps) {
                val layout = createStaticLayout("✓ $step", captionPaint, (contentWidth - 24).toInt())
                canvas.save()
                canvas.translate(startX + 12f, curY)
                layout.draw(canvas)
                canvas.restore()
                curY += layout.height + 4f
            }

            return h + 8f
        }
    }

    /**
     * Empty state item when no sections are linked
     */
    private inner class EmptySectionsNoticeItem(
        private val title: String,
        private val message: String
    ) : RenderableItem {
        override fun measureHeight(contentWidth: Float): Float = 44f

        override fun draw(canvas: Canvas, startX: Float, startY: Float, contentWidth: Float): Float {
            val h = measureHeight(contentWidth)
            val rect = RectF(startX, startY + 4f, startX + contentWidth, startY + h)

            fillPaint.color = Color.parseColor("#F5F5F5")
            canvas.drawRoundRect(rect, 4f, 4f, fillPaint)

            canvas.drawText(title, startX + 12f, startY + 20f, boldBodyPaint)
            val layout = createStaticLayout(message, captionPaint, (contentWidth - 24).toInt())
            canvas.save()
            canvas.translate(startX + 12f, startY + 26f)
            layout.draw(canvas)
            canvas.restore()

            return h + 6f
        }
    }

    // =========================================================================
    // STATICLAYOUT HELPER FOR ROBUST DEVANAGARI WRAPPING
    // =========================================================================

    private fun createStaticLayout(
        text: CharSequence,
        paint: TextPaint,
        width: Int
    ): StaticLayout {
        val safeWidth = width.coerceAtLeast(100)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            StaticLayout.Builder.obtain(text, 0, text.length, paint, safeWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setLineSpacing(0f, 1.15f)
                .setIncludePad(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            StaticLayout(
                text,
                paint,
                safeWidth,
                Layout.Alignment.ALIGN_NORMAL,
                1.15f,
                0f,
                true
            )
        }
    }
}
