package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.Search
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Navigation destinations for Advocate Sathi.
 */
sealed class AppScreen(
    val route: String,
    val titleHindi: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val showInBottomBar: Boolean = true
) {
    data object Home : AppScreen(
        route = "home",
        titleHindi = "मुख्य",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home,
        showInBottomBar = true
    )

    data object ImportFir : AppScreen(
        route = "import_fir",
        titleHindi = "FIR चुनें",
        selectedIcon = Icons.Filled.Description,
        unselectedIcon = Icons.Outlined.Description,
        showInBottomBar = false
    )

    data object ExtractedText : AppScreen(
        route = "extracted_text",
        titleHindi = "टेक्स्ट जाँचें",
        selectedIcon = Icons.Filled.Description,
        unselectedIcon = Icons.Outlined.Description,
        showInBottomBar = false
    )

    data object SectionSearch : AppScreen(
        route = "section_search",
        titleHindi = "धारा खोज",
        selectedIcon = Icons.Filled.Search,
        unselectedIcon = Icons.Outlined.Search,
        showInBottomBar = true
    )

    data object Reports : AppScreen(
        route = "reports",
        titleHindi = "रिपोर्ट",
        selectedIcon = Icons.Filled.Description,
        unselectedIcon = Icons.Outlined.Description,
        showInBottomBar = true
    )

    data object LegalLibrary : AppScreen(
        route = "library",
        titleHindi = "पुस्तकालय",
        selectedIcon = Icons.Filled.MenuBook,
        unselectedIcon = Icons.Outlined.MenuBook,
        showInBottomBar = true
    )

    data object Settings : AppScreen(
        route = "settings",
        titleHindi = "नियम व शर्तें",
        selectedIcon = Icons.Filled.Info,
        unselectedIcon = Icons.Outlined.Info,
        showInBottomBar = true
    )

    companion object {
        val bottomNavItems: List<AppScreen>
            get() = listOf(
                Home,
                SectionSearch,
                Reports,
                LegalLibrary,
                Settings
            )
    }
}
