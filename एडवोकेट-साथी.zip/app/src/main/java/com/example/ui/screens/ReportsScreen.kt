package com.example.ui.screens

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DocumentType
import com.example.ocr.ExtractionMethod
import com.example.ui.components.SectionDetailDialog
import com.example.ui.components.StructuredRecordDetailDialog
import com.example.ui.components.StructuredLegalRecordCard
import com.example.ui.navigation.AppScreen
import com.example.ui.theme.LegalWarningAmber
import com.example.ui.theme.LegalWarningContainer
import com.example.viewmodel.AdvocateUiState
import com.example.viewmodel.AdvocateViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ReportsScreen(
    uiState: AdvocateUiState,
    viewModel: AdvocateViewModel,
    onNavigate: (AppScreen) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    // SAF File Creator Launcher for saving genuine PDF report
    val savePdfLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/pdf")
    ) { uri ->
        if (uri != null) {
            viewModel.exportPdfToUri(uri)
        } else {
            viewModel.onPdfExportCancelled()
        }
    }

    var showConfirmDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("reports_screen")
    ) {
        // Top Toolbar: State Switcher for testing empty/populated reports
        Surface(
            tonalElevation = 2.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (uiState.isShowingEmptyReports) "खाली स्थिति (Empty State)" else "दस्तावेज़ समीक्षा रिपोर्ट (Active)",
                    style = MaterialTheme.typography.labelLarge.copy(
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                )

                OutlinedButton(
                    onClick = { viewModel.toggleEmptyReports() },
                    modifier = Modifier.testTag("btn_toggle_empty_report"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (uiState.isShowingEmptyReports) "समीक्षा रिपोर्ट दिखाएँ" else "खाली स्थिति दिखाएँ",
                        style = MaterialTheme.typography.labelSmall
                    )
                }
            }
        }

        if (uiState.isShowingEmptyReports) {
            // Empty State View
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .testTag("reports_empty_container"),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Description,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline,
                            modifier = Modifier.size(36.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Text(
                        text = "अभी कोई समीक्षा रिपोर्ट तैयार नहीं है",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "अपनी प्राथमिकी (FIR) का विधिक विश्लेषण और PDF रिपोर्ट तैयार करने के लिए दस्तावेज़ आयात करें या टेक्स्ट दर्ज करें।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        ),
                        modifier = Modifier.padding(horizontal = 16.dp)
                    )

                    Spacer(modifier = Modifier.height(20.dp))

                    Button(
                        onClick = { onNavigate(AppScreen.ImportFir) },
                        modifier = Modifier.testTag("btn_start_new_fir"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("दस्तावेज़ आयात करें")
                    }
                }
            }
        } else {
            // Active Document Review Report View
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
                    .testTag("reports_demo_container"),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Success Banner
                if (uiState.pdfExportSuccessMessage != null) {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pdf_export_success_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.CheckCircle,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = uiState.pdfExportSuccessMessage,
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.clearPdfMessages() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "संदेश हटाएँ",
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Error Banner
                if (uiState.pdfExportError != null) {
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("pdf_export_error_banner")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.ErrorOutline,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.error,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = uiState.pdfExportError,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontWeight = FontWeight.Medium
                                ),
                                modifier = Modifier.weight(1f)
                            )
                            IconButton(
                                onClick = { viewModel.clearPdfMessages() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Close,
                                    contentDescription = "संदेश हटाएँ",
                                    tint = MaterialTheme.colorScheme.onErrorContainer,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Mandatory Legal Notice Banner
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(LegalWarningContainer)
                        .border(1.dp, LegalWarningAmber.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                        .padding(14.dp)
                        .testTag("card_legal_disclaimer")
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Icon(
                            imageVector = Icons.Filled.Info,
                            contentDescription = null,
                            tint = LegalWarningAmber,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "महत्वपूर्ण विधिक एवं गोपनीयता सूचना",
                                style = MaterialTheme.typography.labelLarge.copy(
                                    color = LegalWarningAmber,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "• यह रिपोर्ट केवल सामान्य विधिक जागरूकता एवं संदर्भ हेतु ऑन-डिवाइस तैयार की जाती है।\n• यह किसी न्यायालय का फैसला, विधिक सलाह या दोषसिद्धि का प्रमाण नहीं है और न ही ज़मानत (Bail) की कोई गारंटी देता है।\n• आपकी फ़ाइल या डेटा कभी भी इंटरनेट पर अपलोड नहीं किया जाता है।",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurface,
                                    lineHeight = 17.sp
                                )
                            )
                        }
                    }
                }

                // Report Summary Header Card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("card_report_metadata")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "दस्तावेज़ समीक्षा रिपोर्ट",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                            val currentDate = SimpleDateFormat("dd MMM yyyy", Locale("hi", "IN")).format(Date())
                            Text(
                                text = currentDate,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }

                        HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp))

                        val docName = uiState.selectedDocument?.fileName ?: if (uiState.firText.isNotBlank()) "सीधे दर्ज प्राथमिकी पाठ" else "नमूना प्राथमिकी"
                        val docType = when (uiState.selectedDocument?.fileType) {
                            DocumentType.PDF -> "पीडीएफ दस्तावेज़ (PDF)"
                            DocumentType.IMAGE -> "तस्वीर / स्कैन प्रति (Image)"
                            null -> "टेक्स्ट प्रविष्टि"
                        }
                        val extraction = when (uiState.extractionMethod) {
                            ExtractionMethod.IMAGE_OCR -> "इमेज ऑन-डिवाइस OCR (ML Kit)"
                            ExtractionMethod.PDF_EMBEDDED -> "डिजिटल पीडीएफ पाठ निष्कर्षण"
                            ExtractionMethod.PDF_RENDERED_OCR -> "पीडीएफ पृष्ठ OCR (PdfRenderer + ML Kit)"
                            ExtractionMethod.HYBRID_PDF -> "मिश्रित निष्कर्षण (डिजिटल + OCR)"
                            ExtractionMethod.MANUAL_ENTRY -> "मैन्युअल / परीक्षण प्रविष्टि"
                            null -> "सीधा पाठ"
                        }

                        MetadataRow(label = "दस्तावेज़", value = docName)
                        MetadataRow(label = "फ़ाइल प्रकार", value = docType)
                        MetadataRow(label = "विश्लेषण विधि", value = extraction)
                        MetadataRow(label = "विश्लेषित पृष्ठ", value = "${uiState.pagesProcessedCount.coerceAtLeast(1)} पृष्ठ")
                    }
                }

                // Extracted FIR Text Preview Card with Include Toggle
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().testTag("card_fir_text_preview")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Assignment,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "प्राथमिकी (FIR) का पाठ",
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    )
                                    Text(
                                        text = "पीडीएफ रिपोर्ट में शामिल करें",
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    )
                                }
                            }

                            Switch(
                                checked = uiState.includeFirTextInReport,
                                onCheckedChange = { viewModel.setIncludeFirTextInReport(it) },
                                modifier = Modifier.testTag("switch_include_fir_text")
                            )
                        }

                        if (uiState.firText.isNotBlank()) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(12.dp)
                            ) {
                                val previewText = if (uiState.firText.length > 280) {
                                    uiState.firText.take(280) + "... [पूर्ण पाठ PDF रिपोर्ट में उपलब्ध होगा]"
                                } else {
                                    uiState.firText
                                }
                                Text(
                                    text = previewText,
                                    style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp)
                                )
                            }
                        } else {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "वर्तमान में कोई प्राथमिकी पाठ लोड नहीं है। आप नमूना पाठ लोड कर सकते हैं।",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedButton(
                                onClick = { viewModel.insertSampleFirText() },
                                modifier = Modifier.testTag("btn_load_sample_fir_in_report"),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("नमूना प्राथमिकी पाठ लोड करें")
                            }
                        }
                    }
                }

                // Linked Legal Provisions Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "समीक्षित विधिक धाराएँ एवं प्रावधान",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                        Text(
                            text = "आधिकारिक भारत का राजपत्र एवं इंडिया कोड से सत्यापित",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }

                // List of structured verified legal sections
                if (uiState.linkedReportSections.isEmpty()) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "कोई विशिष्ट धारा संबद्ध नहीं है। धारा खोज मेनू से धाराएँ जोड़ सकते हैं।",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(14.dp)
                        )
                    }
                } else {
                    uiState.linkedReportSections.forEach { record ->
                        StructuredLegalRecordCard(
                            record = record,
                            onCardClick = { viewModel.selectStructuredRecord(record) }
                        )
                    }
                }

                // Citizen Legal Rights & Guidance Card
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("card_citizen_rights_guidance")
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "नागरिक के प्रमुख वैधानिक अधिकार",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            )
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        listOf(
                            "प्राथमिकी की प्रमाणित प्रति तुरंत और निःशुल्क प्राप्त करने का अधिकार (BNSS धारा 173(2) / CrPC 154(2))।",
                            "गिरफ्तारी की स्थिति में गिरफ्तारी के आधार जानने तथा अपने चुने हुए अधिवक्ता से परामर्श का अधिकार (BNSS धारा 37, 38)।",
                            "ज़िला विधिक सेवा प्राधिकरण (DLSA) से पात्र नागरिकों हेतु निःशुल्क विधिक सहायता का अधिकार।"
                        ).forEach { item ->
                            Row(modifier = Modifier.padding(vertical = 3.dp)) {
                                Text(text = "• ", fontWeight = FontWeight.Bold)
                                Text(
                                    text = item,
                                    style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp)
                                )
                            }
                        }
                    }
                }

                // PDF Generation Status Bar
                if (uiState.isGeneratingPdf) {
                    Card(
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.5.dp)
                            Spacer(modifier = Modifier.width(14.dp))
                            Column {
                                Text(
                                    text = "ऑन-डिवाइस PDF रिपोर्ट तैयार हो रही है...",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "देवनागरी टाइपोग्राफी, पृष्ठ विभाजन एवं विधिक संदर्भ जोड़े जा रहे हैं।",
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                )
                            }
                        }
                    }
                }

                // Primary Action Buttons: Save PDF (SAF) & Share
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Save PDF Button (Storage Access Framework)
                    Button(
                        onClick = {
                            val defaultFileName = "AdhivaktaSathi_Report_${System.currentTimeMillis()}.pdf"
                            savePdfLauncher.launch(defaultFileName)
                        },
                        modifier = Modifier
                            .weight(1.3f)
                            .height(52.dp)
                            .testTag("btn_export_pdf_saf"),
                        enabled = !uiState.isGeneratingPdf,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PictureAsPdf,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "पीडीएफ सेव करें",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }

                    // Share Button (FileProvider)
                    OutlinedButton(
                        onClick = {
                            val shareUri = viewModel.generatePdfForShare()
                            if (shareUri != null) {
                                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "application/pdf"
                                    putExtra(Intent.EXTRA_STREAM, shareUri)
                                    putExtra(Intent.EXTRA_SUBJECT, "एडवोकेट साथी - दस्तावेज़ समीक्षा रिपोर्ट")
                                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                }
                                context.startActivity(
                                    Intent.createChooser(sendIntent, "दस्तावेज़ समीक्षा रिपोर्ट शेयर करें")
                                )
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(52.dp)
                            .testTag("btn_share_pdf_report"),
                        enabled = !uiState.isGeneratingPdf,
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Share,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "शेयर करें",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }

    // Structured Record Detail Dialog
    if (uiState.selectedStructuredRecord != null) {
        StructuredRecordDetailDialog(
            record = uiState.selectedStructuredRecord,
            onDismiss = { viewModel.selectStructuredRecord(null) }
        )
    }

    // Fallback legacy section dialog if needed
    if (uiState.selectedSectionForDetail != null) {
        SectionDetailDialog(
            section = uiState.selectedSectionForDetail,
            onDismiss = { viewModel.selectSectionForDetail(null) }
        )
    }
}

@Composable
private fun MetadataRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = FontWeight.SemiBold
            )
        )
    }
}
