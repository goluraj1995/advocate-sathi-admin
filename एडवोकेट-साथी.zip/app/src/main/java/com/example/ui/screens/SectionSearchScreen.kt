package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.OfficialLegalRepository
import com.example.model.LegalAct
import com.example.model.VerificationStatus
import com.example.ui.components.SectionDetailDialog
import com.example.ui.components.StructuredLegalRecordCard
import com.example.ui.components.StructuredRecordDetailDialog
import com.example.ui.theme.DemoBadgeBg
import com.example.ui.theme.DemoBadgeText
import com.example.viewmodel.AdvocateUiState
import com.example.viewmodel.AdvocateViewModel

@Composable
fun SectionSearchScreen(
    uiState: AdvocateUiState,
    viewModel: AdvocateViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    val filteredRecords = remember(
        uiState.searchQuery,
        uiState.selectedActFilter,
        uiState.selectedVerificationFilter
    ) {
        OfficialLegalRepository.searchRecords(
            query = uiState.searchQuery,
            actFilter = uiState.selectedActFilter,
            verificationFilter = uiState.selectedVerificationFilter
        )
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .testTag("section_search_screen")
    ) {
        // 1. Search Box & Filter Chips
        Surface(
            tonalElevation = 2.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = { viewModel.setSearchQuery(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_input_field"),
                    placeholder = {
                        Text("धारा सं. या विषय खोजें (उदा. 1, 358, 303, चोरी, हत्या, 173)...")
                    },
                    leadingIcon = {
                        Icon(imageVector = Icons.Filled.Search, contentDescription = null)
                    },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(
                                onClick = { viewModel.setSearchQuery("") },
                                modifier = Modifier.testTag("btn_clear_search")
                            ) {
                                Icon(imageVector = Icons.Filled.Clear, contentDescription = "हटाएँ")
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Act Filter Chips (Horizontal Scroll)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = uiState.selectedActFilter == null,
                        onClick = { viewModel.setActFilter(null) },
                        label = { Text("सभी कानून") },
                        modifier = Modifier.testTag("filter_chip_all"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )

                    LegalAct.entries.forEach { act ->
                        FilterChip(
                            selected = uiState.selectedActFilter == act,
                            onClick = {
                                if (uiState.selectedActFilter == act) {
                                    viewModel.setActFilter(null)
                                } else {
                                    viewModel.setActFilter(act)
                                }
                            },
                            label = { Text(act.code) },
                            modifier = Modifier.testTag("filter_chip_${act.code.lowercase()}"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = MaterialTheme.colorScheme.primary,
                                selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Verification Status Filter Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = uiState.selectedVerificationFilter == null,
                        onClick = { viewModel.setVerificationFilter(null) },
                        label = { Text("सभी स्थितियाँ") },
                        modifier = Modifier.testTag("filter_chip_status_all"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.secondary,
                            selectedLabelColor = MaterialTheme.colorScheme.onSecondary
                        )
                    )

                    FilterChip(
                        selected = uiState.selectedVerificationFilter == VerificationStatus.VERIFIED,
                        onClick = {
                            if (uiState.selectedVerificationFilter == VerificationStatus.VERIFIED) {
                                viewModel.setVerificationFilter(null)
                            } else {
                                viewModel.setVerificationFilter(VerificationStatus.VERIFIED)
                            }
                        },
                        label = { Text("✓ केवल सत्यापित") },
                        modifier = Modifier.testTag("filter_chip_status_verified"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.primary,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimary
                        )
                    )

                    FilterChip(
                        selected = uiState.selectedVerificationFilter == VerificationStatus.NEEDS_REVIEW,
                        onClick = {
                            if (uiState.selectedVerificationFilter == VerificationStatus.NEEDS_REVIEW) {
                                viewModel.setVerificationFilter(null)
                            } else {
                                viewModel.setVerificationFilter(VerificationStatus.NEEDS_REVIEW)
                            }
                        },
                        label = { Text("⚠ समीक्षाधीन") },
                        modifier = Modifier.testTag("filter_chip_status_needs_review"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.tertiary,
                            selectedLabelColor = MaterialTheme.colorScheme.onTertiary
                        )
                    )

                    FilterChip(
                        selected = uiState.selectedVerificationFilter == VerificationStatus.DEMO,
                        onClick = {
                            if (uiState.selectedVerificationFilter == VerificationStatus.DEMO) {
                                viewModel.setVerificationFilter(null)
                            } else {
                                viewModel.setVerificationFilter(VerificationStatus.DEMO)
                            }
                        },
                        label = { Text("नमूना / ऐतिहासिक") },
                        modifier = Modifier.testTag("filter_chip_status_demo"),
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                            selectedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        }

        // 2. Repository Traceability Disclaimer Bar
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(DemoBadgeBg)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "स्रोत सत्यापन",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = DemoBadgeText,
                            fontSize = 10.sp
                        )
                    )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "आधिकारिक भारत का राजपत्र व इंडिया कोड से सत्यापित धाराएं हरी रंग में चिन्हित हैं।",
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }
        }

        // 3. Section List or Empty State
        if (filteredRecords.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp)
                    .testTag("search_empty_state"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Filled.SearchOff,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.outline,
                        modifier = Modifier.size(56.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "कोई धारा नहीं मिली",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "खोज शब्द बदलें या 'सभी कानून' / 'सभी स्थितियाँ' चुनें।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("section_search_list"),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    // Transition Notice Box
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(12.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "संक्रमणकालीन नियम (Transitional Rule): घटना यदि 1 जुलाई 2024 या उसके बाद की है तो BNS/BNSS/BSA लागू होगी; 30 जून 2024 तक की घटनाओं में IPC/CrPC/IEA मान्य रहेगी (BNS धारा 358 व BNSS धारा 531 व्यावृत्ति)।",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    fontSize = 11.5.sp,
                                    lineHeight = 16.sp
                                )
                            )
                        }
                    }
                }

                items(filteredRecords, key = { it.recordId }) { record ->
                    StructuredLegalRecordCard(
                        record = record,
                        onCardClick = { viewModel.selectStructuredRecord(record) }
                    )
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                }
            }
        }
    }

    // Structured Record Detail Dialog
    if (uiState.selectedStructuredRecord != null) {
        StructuredRecordDetailDialog(
            record = uiState.selectedStructuredRecord,
            onDismiss = { viewModel.selectStructuredRecord(null) }
        )
    }

    // Fallback for legacy demo section detail if opened
    if (uiState.selectedSectionForDetail != null) {
        SectionDetailDialog(
            section = uiState.selectedSectionForDetail,
            onDismiss = { viewModel.selectSectionForDetail(null) }
        )
    }
}
