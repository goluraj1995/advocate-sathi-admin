package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Color Palette (Refined Dark Green, Warm Cream, Restrained Gold)
val ForestGreenPrimary = Color(0xFF144D37)
val ForestGreenOnPrimary = Color(0xFFFFFFFF)
val ForestGreenContainer = Color(0xFFE2F4EA)
val ForestGreenOnContainer = Color(0xFF093122)

val OliveSlateSecondary = Color(0xFF385346)
val OliveSlateOnSecondary = Color(0xFFFFFFFF)
val OliveSlateContainer = Color(0xFFD7E5DB)
val OliveSlateOnContainer = Color(0xFF162820)

val RestrainedGoldTertiary = Color(0xFFB5851C)
val RestrainedGoldOnTertiary = Color(0xFFFFFFFF)
val RestrainedGoldContainer = Color(0xFFFBEBC7)
val RestrainedGoldOnContainer = Color(0xFF3D2A00)

val WarmCreamBackground = Color(0xFFFAF7F2)
val WarmCreamOnBackground = Color(0xFF1D211E)
val WarmCreamSurface = Color(0xFFFFFFFF)
val WarmCreamOnSurface = Color(0xFF1D211E)
val WarmCreamSurfaceVariant = Color(0xFFEDE9E0)
val WarmCreamOnSurfaceVariant = Color(0xFF4B4F4A)

val WarmOutline = Color(0xFF81867F)
val WarmOutlineVariant = Color(0xFFC7C2B6)

// Dark Color Palette
val ForestGreenDarkPrimary = Color(0xFF85D8B0)
val ForestGreenDarkOnPrimary = Color(0xFF003822)
val ForestGreenDarkContainer = Color(0xFF0C543B)
val ForestGreenDarkOnContainer = Color(0xFFA5F4CD)

val OliveSlateDarkSecondary = Color(0xFFB7CCC0)
val OliveSlateDarkOnSecondary = Color(0xFF22352B)
val OliveSlateDarkContainer = Color(0xFF374B40)
val OliveSlateDarkOnContainer = Color(0xFFD3E7DC)

val RestrainedGoldDarkTertiary = Color(0xFFE8C26C)
val RestrainedGoldDarkOnTertiary = Color(0xFF3F2E00)
val RestrainedGoldDarkContainer = Color(0xFF5B4300)
val RestrainedGoldDarkOnContainer = Color(0xFFFFDEA1)

val WarmDarkBackground = Color(0xFF111613)
val WarmDarkOnBackground = Color(0xFFE1E4DF)
val WarmDarkSurface = Color(0xFF181F1B)
val WarmDarkOnSurface = Color(0xFFE1E4DF)
val WarmDarkSurfaceVariant = Color(0xFF2B332E)
val WarmDarkOnSurfaceVariant = Color(0xFFC2C9C2)

val WarmDarkOutline = Color(0xFF8B938D)
val WarmDarkOutlineVariant = Color(0xFF434A45)

// Status colors
val LegalWarningAmber = Color(0xFFB06000)
val LegalWarningContainer = Color(0xFFFFF0DC)
val LegalInfoNavy = Color(0xFF1A446C)
val LegalInfoContainer = Color(0xFFE1EDF8)
val DemoBadgeBg = Color(0xFFE6D29D)
val DemoBadgeText = Color(0xFF4C3806)
