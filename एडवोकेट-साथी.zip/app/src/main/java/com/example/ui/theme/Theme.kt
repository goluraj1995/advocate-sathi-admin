package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = ForestGreenDarkPrimary,
    onPrimary = ForestGreenDarkOnPrimary,
    primaryContainer = ForestGreenDarkContainer,
    onPrimaryContainer = ForestGreenDarkOnContainer,
    secondary = OliveSlateDarkSecondary,
    onSecondary = OliveSlateDarkOnSecondary,
    secondaryContainer = OliveSlateDarkContainer,
    onSecondaryContainer = OliveSlateDarkOnContainer,
    tertiary = RestrainedGoldDarkTertiary,
    onTertiary = RestrainedGoldDarkOnTertiary,
    tertiaryContainer = RestrainedGoldDarkContainer,
    onTertiaryContainer = RestrainedGoldDarkOnContainer,
    background = WarmDarkBackground,
    onBackground = WarmDarkOnBackground,
    surface = WarmDarkSurface,
    onSurface = WarmDarkOnSurface,
    surfaceVariant = WarmDarkSurfaceVariant,
    onSurfaceVariant = WarmDarkOnSurfaceVariant,
    outline = WarmDarkOutline,
    outlineVariant = WarmDarkOutlineVariant
)

private val LightColorScheme = lightColorScheme(
    primary = ForestGreenPrimary,
    onPrimary = ForestGreenOnPrimary,
    primaryContainer = ForestGreenContainer,
    onPrimaryContainer = ForestGreenOnContainer,
    secondary = OliveSlateSecondary,
    onSecondary = OliveSlateOnSecondary,
    secondaryContainer = OliveSlateContainer,
    onSecondaryContainer = OliveSlateOnContainer,
    tertiary = RestrainedGoldTertiary,
    onTertiary = RestrainedGoldOnTertiary,
    tertiaryContainer = RestrainedGoldContainer,
    onTertiaryContainer = RestrainedGoldOnContainer,
    background = WarmCreamBackground,
    onBackground = WarmCreamOnBackground,
    surface = WarmCreamSurface,
    onSurface = WarmCreamOnSurface,
    surfaceVariant = WarmCreamSurfaceVariant,
    onSurfaceVariant = WarmCreamOnSurfaceVariant,
    outline = WarmOutline,
    outlineVariant = WarmOutlineVariant
)

@Composable
fun AdvocateSathiTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
