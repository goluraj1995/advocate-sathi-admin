package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ocr.ExtractionMethod
import com.example.ui.navigation.AppScreen
import com.example.ui.theme.ForestGreenContainer
import com.example.ui.theme.ForestGreenOnContainer
import com.example.ui.theme.LegalWarningAmber
import com.example.ui.theme.LegalWarningContainer
import com.example.viewmodel.AdvocateUiState
import com.example.viewmodel.AdvocateViewModel

@Composable
fun ExtractedTextScreen(
    uiState: AdvocateUiState,
    viewModel: AdvocateViewModel,
    onNavigate: (AppScreen) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
            .testTag("extracted_text_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Mandatory OCR Warning Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(LegalWarningContainer)
                .border(1.dp, LegalWarningAmber.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(14.dp)
                .testTag("ocr_warning_banner")
        ) {
            Row(verticalAlignment = Alignment.Top) {
                Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = null,
                    tint = LegalWarningAmber,
                    modifier = Modifier
                        .size(22.dp)
                        .padding(top = 2.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "महत्वपूर्ण चेतावनी: OCR त्रुटियाँ संभव हैं",
                        style = MaterialTheme.typography.labelLarge.copy(
                            color = LegalWarningAmber,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "स्कैन किए गए दस्तावेज़ों या हस्तलिखित एफआईआर में अक्षरों की पहचान में गलतियाँ हो सकती हैं। कृपया घटना की तारीख, समय, आरोपी का नाम एवं धाराएँ नीचे दिए गए बॉक्स में स्वयं जाँचें और सुधारें।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 18.sp
                        ),
                        modifier = Modifier.padding(top = 2.dp)
                    )
                }
            }
        }

        // 2. OCR Method & Source Badge if extracted via OCR
        if (uiState.extractionMethod != null) {
            Surface(
                shape = RoundedCornerShape(10.dp),
                color = if (uiState.extractionMethod == ExtractionMethod.MANUAL_ENTRY) {
                    MaterialTheme.colorScheme.surfaceVariant
                } else {
                    ForestGreenContainer
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ocr_method_badge")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (uiState.extractionMethod == ExtractionMethod.MANUAL_ENTRY) Icons.Filled.Info else Icons.Filled.Verified,
                        contentDescription = null,
                        tint = if (uiState.extractionMethod == ExtractionMethod.MANUAL_ENTRY) MaterialTheme.colorScheme.primary else ForestGreenOnContainer,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "स्रोत: ${uiState.extractionMethod.labelHindi}",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (uiState.extractionMethod == ExtractionMethod.MANUAL_ENTRY) MaterialTheme.colorScheme.onSurface else ForestGreenOnContainer
                            )
                        )
                        if (uiState.ocrResultNotice != null) {
                            Text(
                                text = uiState.ocrResultNotice,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = if (uiState.extractionMethod == ExtractionMethod.MANUAL_ENTRY) MaterialTheme.colorScheme.onSurfaceVariant else ForestGreenOnContainer,
                                    fontSize = 11.5.sp
                                )
                            )
                        }
                    }
                }
            }
        }

        // 3. Action buttons for quick test or clear
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.insertSampleFirText() },
                modifier = Modifier
                    .weight(1f)
                    .testTag("btn_insert_sample_text"),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.ContentPaste,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "नमूना पाठ लोड करें",
                    style = MaterialTheme.typography.labelMedium
                )
            }

            if (uiState.firText.isNotEmpty()) {
                OutlinedButton(
                    onClick = { viewModel.clearFirText() },
                    modifier = Modifier
                        .weight(0.7f)
                        .testTag("btn_clear_fir_text"),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Clear,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "साफ़ करें",
                        style = MaterialTheme.typography.labelMedium
                    )
                }
            }
        }

        // 4. Editable Text Area
        Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "प्राथमिकी (FIR) का विवरण:",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "${uiState.firText.length} वर्ण | ${uiState.firText.split("\\s+".toRegex()).filter { it.isNotBlank() }.size} शब्द",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = uiState.firText,
                    onValueChange = { viewModel.updateFirText(it) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(240.dp)
                        .testTag("input_fir_text"),
                    placeholder = {
                        Text(
                            text = "एफआईआर का पाठ यहाँ दिखाई देगा या आप स्वयं टाइप कर सकते हैं।\n\nउदाहरण:\nथाना: सिविल लाइन्स\nघटना दिनांक: 15/08/2024\nविवरण: शिकायतकर्ता का मोबाइल छीना गया (BNS 303)...",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.outline
                            )
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }

        // 5. Checklist: What to verify
        Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Info,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "एफआईआर में क्या सत्यापित करें?",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "1. अपराध की तारीख व समय (यह तय करता है कि BNS या IPC लागू होगी)",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
                Text(
                    text = "2. घटना का सटीक स्थान व संबंधित थाना",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
                Text(
                    text = "3. अभिलिखित धाराएँ (जैसे BNS 303, 318, 351 अथवा IPC 379, 420)",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
                Text(
                    text = "4. चोट, नुकसान या लूटी गई संपत्ति का सही विवरण",
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(vertical = 2.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // 6. Navigation Button: Proceed to Section Search
        Button(
            onClick = { onNavigate(AppScreen.SectionSearch) },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("btn_proceed_to_sections"),
            shape = RoundedCornerShape(10.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.primary
            )
        ) {
            Text(
                text = "कानून की धारा खोजें व मिलान करें →",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
        }
    }
}
