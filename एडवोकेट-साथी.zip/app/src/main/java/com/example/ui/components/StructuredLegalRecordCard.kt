package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CommencementStatus
import com.example.model.StructuredLegalRecord
import com.example.model.VerificationStatus
import com.example.ui.theme.LegalWarningAmber
import com.example.ui.theme.LegalWarningContainer

/**
 * Modern M3 Card representing a structured, source-traceable statutory record.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun StructuredLegalRecordCard(
    record: StructuredLegalRecord,
    onCardClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onCardClick)
            .testTag("structured_record_card_${record.recordId}"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Act Badge & Verification Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                ActBadge(act = record.act)
                VerificationBadge(status = record.verificationStatus)
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Section Number & Headings
            Text(
                text = "${record.act.code} धारा ${record.sectionNumber}",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )

            Text(
                text = record.officialHeadingHindi,
                style = MaterialTheme.typography.bodyLarge.copy(
                    fontWeight = FontWeight.Medium,
                    color = MaterialTheme.colorScheme.onSurface
                ),
                modifier = Modifier.padding(top = 2.dp)
            )

            Text(
                text = record.officialHeading,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Approved text or summary snippet
            Text(
                text = record.officialTextOrApprovedSummary,
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 20.sp
                ),
                maxLines = 3
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Attribute FlowRow
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Commencement Pill
                CommencementPill(status = record.commencementStatus)

                // Bailable / Non-Bailable
                if (!record.bailableStatus.isNullOrEmpty() && record.bailableStatus != "लागू नहीं") {
                    val isPositive = record.bailableStatus.contains("जमानती") && !record.bailableStatus.contains("गैर")
                    StatusPill(label = record.bailableStatus, isPositive = isPositive)
                }

                // Cross Reference count
                if (record.crossReferences.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.7f))
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        val firstRef = record.crossReferences.first()
                        Text(
                            text = "पूर्ववर्ती: ${firstRef.targetAct.code} ${firstRef.targetSectionNumber}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSecondaryContainer,
                                fontWeight = FontWeight.Medium
                            )
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Source Attribution Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "स्रोत: ${record.sourceTitle}",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.outline,
                        fontSize = 10.sp
                    ),
                    maxLines = 1,
                    modifier = Modifier.weight(1f)
                )
                Text(
                    text = "विस्तृत स्रोत देखें ›",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 10.sp
                    )
                )
            }
        }
    }
}

/**
 * Verification badge with strict visual color gating:
 * - VERIFIED / PUBLISHED: Green with Check
 * - NEEDS_REVIEW: Amber with Warning
 * - DEMO / DRAFT: Gold with Info
 */
@Composable
fun VerificationBadge(status: VerificationStatus) {
    val (bgColor, textColor, icon) = when (status) {
        VerificationStatus.PUBLISHED, VerificationStatus.VERIFIED -> Triple(
            Color(0xFFE8F5E9),
            Color(0xFF1B5E20),
            Icons.Filled.Verified
        )
        VerificationStatus.NEEDS_REVIEW -> Triple(
            Color(0xFFFFF8E1),
            Color(0xFFE65100),
            Icons.Filled.Warning
        )
        VerificationStatus.DEMO, VerificationStatus.DRAFT -> Triple(
            Color(0xFFFFF9C4),
            Color(0xFF7F6000),
            Icons.Filled.Info
        )
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 3.dp)
            .testTag("verification_badge_${status.name}")
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(13.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = status.labelHindi,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = textColor,
                    fontSize = 10.sp
                )
            )
        }
    }
}

@Composable
fun CommencementPill(status: CommencementStatus) {
    val (bgColor, textColor) = when (status) {
        CommencementStatus.IN_FORCE -> Color(0xFFE3F2FD) to Color(0xFF0D47A1)
        CommencementStatus.REPEALED_WITH_SAVINGS -> Color(0xFFECEFF1) to Color(0xFF37474F)
        CommencementStatus.HELD_IN_ABEYANCE -> Color(0xFFFBE9E7) to Color(0xFFD84315)
        CommencementStatus.PENDING_NOTIFICATION -> Color(0xFFFFF3E0) to Color(0xFFE65100)
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = status.labelHindi,
            style = MaterialTheme.typography.labelSmall.copy(
                color = textColor,
                fontWeight = FontWeight.Medium
            )
        )
    }
}

/**
 * Comprehensive In-App Statutory Source Details Dialog.
 * Transparently exposes primary source citations, Gazette dates, applicability caveats,
 * and procedural disclaimers.
 */
@Composable
fun StructuredRecordDetailDialog(
    record: StructuredLegalRecord,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${record.act.code} धारा ${record.sectionNumber}",
                        style = MaterialTheme.typography.titleLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Text(
                        text = record.officialActTitle,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Filled.Close, contentDescription = "बंद करें")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // 1. Status Badges Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    VerificationBadge(status = record.verificationStatus)
                    CommencementPill(status = record.commencementStatus)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 2. Hindi & English Heading
                Text(
                    text = record.officialHeadingHindi,
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                )
                Text(
                    text = record.officialHeading,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    modifier = Modifier.padding(bottom = 8.dp)
                )

                HorizontalDivider()

                Spacer(modifier = Modifier.height(10.dp))

                // 3. Statutory Text / Summary
                Text(
                    text = if (record.verificationStatus == VerificationStatus.VERIFIED)
                        "सत्यापित वैधानिक पाठ / आधिकारिक सारांश:"
                    else
                        "वैधानिक सारांश (समीक्षाधीन):",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
                Text(
                    text = record.officialTextOrApprovedSummary,
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                    modifier = Modifier.padding(vertical = 4.dp)
                )

                // 4. Key Elements
                if (record.keyElements.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "मुख्य कानूनी तत्व:",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    record.keyElements.forEach { element ->
                        Row(modifier = Modifier.padding(vertical = 2.dp)) {
                            Text(text = "• ", fontWeight = FontWeight.Bold)
                            Text(
                                text = element,
                                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 5. Procedural Classification
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "प्रक्रियात्मक वर्गीकरण:",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        if (!record.bailableStatus.isNullOrEmpty()) {
                            Text(text = "• जमानत स्थिति: ${record.bailableStatus}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (!record.cognizableStatus.isNullOrEmpty()) {
                            Text(text = "• संज्ञेयता: ${record.cognizableStatus}", style = MaterialTheme.typography.bodySmall)
                        }
                        if (!record.trialCourt.isNullOrEmpty()) {
                            Text(text = "• विचारणीय न्यायालय: ${record.trialCourt}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }

                // 6. Cross-References & Transitional Caveats
                if (record.crossReferences.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "संबद्ध कानूनी प्रावधान (Cross-References):",
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    record.crossReferences.forEach { crossRef ->
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = "${crossRef.targetAct.code} धारा ${crossRef.targetSectionNumber}: ${crossRef.targetHeading}",
                                    style = MaterialTheme.typography.labelMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSecondaryContainer
                                    )
                                )
                                Text(
                                    text = "संबंध का प्रकार: ${crossRef.relationshipType.labelHindi}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )
                                Text(
                                    text = "वैधानिक आधार: ${crossRef.statutoryAuthorityNote}",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp)
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                // Mandatory date-dependent caveat
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(LegalWarningContainer)
                                        .border(1.dp, LegalWarningAmber.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                        .padding(6.dp)
                                ) {
                                    Text(
                                        text = "⚠️ लागू होने की शर्त: ${crossRef.applicabilityCaveat}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontSize = 11.sp,
                                            lineHeight = 15.sp,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 7. Official Source Details Section (India Code, Gazette)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Verified,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "प्राथमिक आधिकारिक स्रोत विवरण (Source Traceability):",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = "• स्रोत शीर्षक: ${record.sourceTitle}",
                            style = MaterialTheme.typography.bodySmall.copy(lineHeight = 16.sp)
                        )

                        if (!record.sourcePublicationOrGazetteDate.isNullOrEmpty()) {
                            Text(
                                text = "• राजपत्र प्रकाशन तिथि: ${record.sourcePublicationOrGazetteDate}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        if (!record.lastVerifiedAt.isNullOrEmpty()) {
                            Text(
                                text = "• अंतिम सत्यापन तिथि: ${record.lastVerifiedAt}",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        // Official Source Link or explicit unavailable label
                        val url = record.officialSourceUrl
                        if (!url.isNullOrEmpty()) {
                            Text(
                                text = "• आधिकारिक इंडिया कोड लिंक: $url",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.primary,
                                    fontWeight = FontWeight.Medium
                                )
                            )
                        } else {
                            Text(
                                text = "• आधिकारिक स्रोत लिंक: अभी ऑनलाइन सत्यापित नहीं (समीक्षाधीन)",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.outline
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // 8. Citizen Procedural Warning Disclaimer
                Text(
                    text = "सूचना: ${record.proceduralCaveat}",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    )
                )
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                modifier = Modifier.testTag("btn_close_structured_detail")
            ) {
                Text("समझ गया / बंद करें")
            }
        }
    )
}
