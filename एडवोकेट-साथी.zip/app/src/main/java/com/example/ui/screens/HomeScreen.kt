package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.LegalDisclaimerNotice
import com.example.ui.components.ProgressFlowCard
import com.example.ui.navigation.AppScreen
import com.example.viewmodel.AdvocateUiState

@Composable
fun HomeScreen(
    uiState: AdvocateUiState,
    onNavigate: (AppScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("home_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Mandatory Legal Disclaimer Notice
        item {
            LegalDisclaimerNotice()
        }

        // 2. 4-Step Progress Flow
        item {
            ProgressFlowCard(
                hasDocument = uiState.selectedDocument != null,
                hasText = uiState.firText.isNotBlank(),
                onStepClick = onNavigate
            )
        }

        // 3. Section Title
        item {
            Text(
                text = "मुख्य कानूनी सेवाएँ",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            )
        }

        // 4. Prominent Cards
        // Card 1: FIR PDF / फोटो चुनें
        item {
            DashboardActionCard(
                title = "FIR PDF / फोटो चुनें",
                subtitle = if (uiState.selectedDocument != null) {
                    "चयनित फ़ाइल: ${uiState.selectedDocument.fileName} (${uiState.selectedDocument.fileSizeFormatted})"
                } else {
                    "अपनी एफआईआर की पीडीएफ या फोटो सुरक्षित रूप से चुनें (कोई अपलोड नहीं)"
                },
                icon = Icons.Filled.UploadFile,
                badge = if (uiState.selectedDocument != null) "फ़ाइल चयनित" else null,
                testTag = "home_card_import",
                onClick = { onNavigate(AppScreen.ImportFir) }
            )
        }

        // Card 2: FIR का टेक्स्ट देखें
        item {
            DashboardActionCard(
                title = "FIR का टेक्स्ट देखें",
                subtitle = if (uiState.firText.isNotBlank()) {
                    "पाठ तैयार (${uiState.firText.length} वर्ण) - समीक्षा व सुधार करें"
                } else {
                    "एफआईआर पाठ की समीक्षा करें या नया विवरण मैन्युअल दर्ज करें"
                },
                icon = Icons.Filled.Description,
                badge = if (uiState.firText.isNotBlank()) "समीक्षा हेतु तैयार" else null,
                testTag = "home_card_text_review",
                onClick = { onNavigate(AppScreen.ExtractedText) }
            )
        }

        // Card 3: कानून की धारा खोजें
        item {
            DashboardActionCard(
                title = "कानून की धारा खोजें",
                subtitle = "BNS, BNSS, BSA, IPC, CrPC की धाराओं की सरल हिंदी व्याख्या खोजें",
                icon = Icons.Filled.Search,
                badge = "डेमो डेटाबेस",
                testTag = "home_card_search",
                onClick = { onNavigate(AppScreen.SectionSearch) }
            )
        }

        // Card 4: मेरी रिपोर्ट
        item {
            DashboardActionCard(
                title = "मेरी रिपोर्ट",
                subtitle = "कानूनी अधिकारों और प्रक्रियात्मक चरणों की विस्तृत रिपोर्ट देखें",
                icon = Icons.Filled.Assignment,
                badge = "नमूना रिपोर्ट",
                testTag = "home_card_reports",
                onClick = { onNavigate(AppScreen.Reports) }
            )
        }

        // Card 5: कानून पुस्तकालय
        item {
            DashboardActionCard(
                title = "कानून पुस्तकालय",
                subtitle = "नए आपराधिक कानून (BNS, BNSS, BSA) एवं पुराने कानूनों की सम्पूर्ण मार्गदर्शिका",
                icon = Icons.Filled.MenuBook,
                badge = "6 संहिताएँ",
                testTag = "home_card_library",
                onClick = { onNavigate(AppScreen.LegalLibrary) }
            )
        }

        // 5. Citizen Quick Advice Card
        item {
            CitizenTipsCard()
        }

        item {
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun DashboardActionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    badge: String? = null,
    testTag: String,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primaryContainer),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    )
                    if (badge != null) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer
                        ) {
                            Text(
                                text = badge,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 10.sp
                                ),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 17.sp
                    )
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.outline,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
fun CitizenTipsCard() {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Lightbulb,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "नागरिक कानूनी मार्गदर्शिका",
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "• घटना की तारीख महत्वपूर्ण है: 1 जुलाई 2024 से पूर्व के मामलों में IPC/CrPC और उसके पश्चात् BNS/BNSS लागू होते हैं।",
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                modifier = Modifier.padding(vertical = 2.dp)
            )
            Text(
                text = "• जीरो एफआईआर (Zero FIR): किसी भी थाने में अपराध की प्राथमिक सूचना दर्ज कराई जा सकती है, भले ही अधिकार क्षेत्र अन्य थाने का हो।",
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                modifier = Modifier.padding(vertical = 2.dp)
            )
            Text(
                text = "• एफआईआर की निःशुल्क प्रति प्राप्त करना प्रत्येक नागरिक का वैधानिक अधिकार है।",
                style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp),
                modifier = Modifier.padding(vertical = 2.dp)
            )
        }
    }
}
