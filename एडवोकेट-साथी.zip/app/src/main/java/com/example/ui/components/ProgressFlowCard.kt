package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.AppScreen

data class FlowStep(
    val stepNumber: Int,
    val title: String,
    val targetScreen: AppScreen,
    val isCompleted: Boolean = false,
    val isCurrent: Boolean = false
)

@Composable
fun ProgressFlowCard(
    hasDocument: Boolean,
    hasText: Boolean,
    onStepClick: (AppScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("progress_flow_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "एफआईआर सहायता प्रक्रिया (4 चरण)",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )
                Text(
                    text = "माइलस्टोन 2: ऑन-डिवाइस OCR",
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            val steps = listOf(
                FlowStep(
                    stepNumber = 1,
                    title = "दस्तावेज़ चुनें",
                    targetScreen = AppScreen.ImportFir,
                    isCompleted = hasDocument,
                    isCurrent = !hasDocument
                ),
                FlowStep(
                    stepNumber = 2,
                    title = "टेक्स्ट जाँचें",
                    targetScreen = AppScreen.ExtractedText,
                    isCompleted = hasText,
                    isCurrent = hasDocument && !hasText
                ),
                FlowStep(
                    stepNumber = 3,
                    title = "धाराएँ सत्यापित",
                    targetScreen = AppScreen.SectionSearch,
                    isCompleted = false,
                    isCurrent = hasText
                ),
                FlowStep(
                    stepNumber = 4,
                    title = "रिपोर्ट देखें",
                    targetScreen = AppScreen.Reports,
                    isCompleted = false,
                    isCurrent = false
                )
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                steps.forEachIndexed { index, step ->
                    StepItem(
                        step = step,
                        onClick = { onStepClick(step.targetScreen) },
                        modifier = Modifier.weight(1f)
                    )
                    if (index < steps.size - 1) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                            modifier = Modifier
                                .size(14.dp)
                                .padding(horizontal = 1.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StepItem(
    step: FlowStep,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp, horizontal = 2.dp)
            .testTag("flow_step_${step.stepNumber}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val circleBg = when {
            step.isCompleted -> MaterialTheme.colorScheme.primary
            step.isCurrent -> MaterialTheme.colorScheme.tertiary
            else -> MaterialTheme.colorScheme.surface
        }
        val textColor = when {
            step.isCompleted || step.isCurrent -> MaterialTheme.colorScheme.onSurface
            else -> MaterialTheme.colorScheme.onSurfaceVariant
        }

        Box(
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(circleBg),
            contentAlignment = Alignment.Center
        ) {
            if (step.isCompleted) {
                Icon(
                    imageVector = Icons.Filled.Check,
                    contentDescription = "पूर्ण",
                    tint = MaterialTheme.colorScheme.onPrimary,
                    modifier = Modifier.size(16.dp)
                )
            } else {
                Text(
                    text = "${step.stepNumber}",
                    style = MaterialTheme.typography.labelMedium.copy(
                        color = if (step.isCurrent) MaterialTheme.colorScheme.onTertiary else MaterialTheme.colorScheme.onSurface,
                        fontWeight = FontWeight.Bold
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = step.title,
            style = MaterialTheme.typography.labelSmall.copy(
                fontSize = 11.sp,
                lineHeight = 14.sp,
                fontWeight = if (step.isCurrent) FontWeight.Bold else FontWeight.Normal,
                color = textColor
            ),
            textAlign = TextAlign.Center
        )
    }
}
