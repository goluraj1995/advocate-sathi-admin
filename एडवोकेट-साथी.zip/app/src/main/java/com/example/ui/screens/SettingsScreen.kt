package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PrivacyTip
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.OfficialLegalRepository
import com.example.ui.theme.ForestGreenContainer
import com.example.ui.theme.ForestGreenOnContainer
import com.example.ui.theme.LegalWarningAmber
import com.example.ui.theme.LegalWarningContainer
import com.example.viewmodel.AdvocateUiState
import com.example.viewmodel.AdvocateViewModel
import com.example.viewmodel.ImportPreviewData

@Composable
fun SettingsScreen(
    uiState: AdvocateUiState,
    viewModel: AdvocateViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    // SAF OpenDocument launcher for selecting JSON export from Admin Panel
    val jsonPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        viewModel.processImportFile(uri)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. App Header Info
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Gavel,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "एडवोकेट साथी",
                        style = MaterialTheme.typography.headlineSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    )

                    Text(
                        text = "FIR और कानून को सरल हिंदी में समझें",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Text(
                            text = "संस्करण 2.5.0 (माइलस्तर 5C - सुरक्षित JSON आयात)",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            ),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // 2. Safe Local Data Management & JSON Import Section
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.FileDownload,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "कानूनी डेटा प्रबंधन व आयात",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )
                            Text(
                                text = "वेब एडमिन पैनल से निर्यातित JSON",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "वेब एडमिन पैनल से निर्यात की गई अधिनियम (Acts) व धाराओं की JSON फ़ाइल चुनें और उसे ऑन-डिवाइस सुरक्षित स्टोरेज में जोड़ें।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.5f),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "ऑन-डिवाइस रिपॉजिटरी में वर्तमान में कुल ${OfficialLegalRepository.records.size} कानूनी धाराएं उपलब्ध हैं।",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSecondaryContainer
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            if (!uiState.isImportProcessing) {
                                jsonPickerLauncher.launch(
                                    arrayOf("application/json", "application/octet-stream", "*/*")
                                )
                            }
                        },
                        enabled = !uiState.isImportProcessing,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_import_json_data"),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        if (uiState.isImportProcessing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = MaterialTheme.colorScheme.onPrimary,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("फ़ाइल जाँची जा रही है...")
                        } else {
                            Icon(
                                imageVector = Icons.Filled.FileDownload,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("JSON डेटा आयात करें")
                        }
                    }
                }
            }
        }

        // 3. Strict Privacy Principles
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = ForestGreenContainer),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.PrivacyTip,
                            contentDescription = null,
                            tint = ForestGreenOnContainer,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "गोपनीयता के मूल सिद्धांत",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = ForestGreenOnContainer
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    PrivacyBullet(
                        title = "100% ऑन-डिवाइस कार्यप्रणाली",
                        description = "आपकी चुनी हुई एफआईआर या आयातित डेटा कभी भी किसी रिमोट सर्वर, क्लाउड या तीसरे पक्ष को नहीं भेजा जाता।"
                    )
                    PrivacyBullet(
                        title = "सुरक्षित एटॉमिक लोकल स्टोरेज",
                        description = "आयातित कानूनी धाराएं आपके फ़ोन के इंटरनल प्राइवेट स्टोरेज में एटॉमिक विधि से सुरक्षित रहती हैं।"
                    )
                    PrivacyBullet(
                        title = "कोई विज्ञापन या सशुल्क सेवा नहीं",
                        description = "यह ऐप भारतीय नागरिकों की निःशुल्क विधिक जागरूकता हेतु निर्मित है।"
                    )
                }
            }
        }

        // 4. Comprehensive Legal Disclaimer
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(LegalWarningContainer)
                    .border(1.dp, LegalWarningAmber.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
                    .padding(16.dp)
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = null,
                            tint = LegalWarningAmber,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "विस्तृत कानूनी अस्वीकरण (Disclaimer)",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = LegalWarningAmber
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "1. 'एडवोकेट साथी' ऐप केवल आम जनता की कानूनी साक्षरता, जागरूकता और शैक्षणिक संदर्भ के उद्देश्य से विकसित किया गया है।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 18.sp
                        ),
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                    Text(
                        text = "2. यह एप्लिकेशन विधिक फर्म, बार काउंसिल अथवा किसी न्यायालय का प्रतिनिधित्व नहीं करता है। यहाँ दी गई जानकारी किसी योग्य अधिवक्ता (Lawyer) की व्यक्तिगत सलाह का स्थान नहीं ले सकती।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 18.sp
                        ),
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                    Text(
                        text = "3. कानून निरंतर संशोधनशील हैं। अपराध की तारीख, राज्य-स्तरीय संशोधन और विशेष परिस्थितियों के आधार पर कानूनी प्रभाव भिन्न हो सकते हैं।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 18.sp
                        ),
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }

        // 5. Project Architecture Note
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.AdminPanelSettings,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "परियोजना संरचना व सुरक्षा",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "प्रशासनिक प्रबंधन हेतु 'वेब एडमिन पैनल' एक पृथक व समर्पित पोर्टल है। इस मोबाइल ऐप में केवल सुरक्षित लोकल JSON इंपोर्ट सुविधा दी गई है जो एडमिन द्वारा एक्सपोर्ट किए गए डेटा को वैलिडेट करके ऐप में जोड़ती है।",
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }

    // --- DIALOGS FOR IMPORT FLOW ---

    // A. Preview Confirmation Dialog
    if (uiState.importPreviewData != null) {
        LegalImportPreviewDialog(
            preview = uiState.importPreviewData,
            isProcessing = uiState.isImportProcessing,
            onCancel = { viewModel.cancelImportPreview() },
            onConfirm = { viewModel.confirmImport() }
        )
    }

    // B. Error Alert Dialog
    if (uiState.importErrorMessage != null && uiState.importPreviewData == null) {
        AlertDialog(
            onDismissRequest = { viewModel.clearImportMessages() },
            icon = {
                Icon(
                    imageVector = Icons.Filled.Warning,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = "आयात त्रुटि या विफलता",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(
                    text = uiState.importErrorMessage ?: "अज्ञात त्रुटि",
                    style = MaterialTheme.typography.bodySmall.copy(lineHeight = 18.sp)
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.clearImportMessages() },
                    modifier = Modifier.testTag("btn_close_import_error")
                ) {
                    Text("ठीक है")
                }
            }
        )
    }

    // C. Success Alert Dialog
    if (uiState.importSuccessMessage != null) {
        AlertDialog(
            onDismissRequest = { viewModel.clearImportMessages() },
            icon = {
                Icon(
                    imageVector = Icons.Filled.CheckCircle,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = "आयात सफलतापूर्वक संपन्न",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            },
            text = {
                Text(
                    text = uiState.importSuccessMessage ?: "डेटा सफलतापूर्वक आयात हुआ।",
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp)
                )
            },
            confirmButton = {
                Button(
                    onClick = { viewModel.clearImportMessages() },
                    modifier = Modifier.testTag("btn_close_import_success")
                ) {
                    Text("ठीक है")
                }
            }
        )
    }
}

@Composable
fun LegalImportPreviewDialog(
    preview: ImportPreviewData,
    isProcessing: Boolean,
    onCancel: () -> Unit,
    onConfirm: () -> Unit
) {
    AlertDialog(
        onDismissRequest = { if (!isProcessing) onCancel() },
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.FileDownload,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "आयात पूर्वावलोकन (Preview)",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "फ़ाइल का नाम: ${preview.fileName}",
                    style = MaterialTheme.typography.labelLarge.copy(
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                )

                HorizontalDivider()

                Text(
                    text = "• कुल रिकॉर्ड प्रविष्टियाँ: ${preview.totalRecords}",
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                )

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "सत्यापन स्थिति ब्रेकडाउन (Verification Status):",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "• प्रकाशित (PUBLISHED): ${preview.publishedCount}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "• सत्यापित (VERIFIED): ${preview.verifiedCount}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "• समीक्षाधीन (NEEDS_REVIEW): ${preview.needsReviewCount}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "• प्रारूप (DRAFT): ${preview.draftCount}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "• नमूना / डेमो (DEMO): ${preview.demoCount}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "• नई प्रविष्टियाँ जो जोड़ी जाएंगी: ${preview.newRecordCount}",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "• पुरानी प्रविष्टियाँ जो अपडेट होंगी: ${preview.existingUpdateCount}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        if (preview.builtInConflictCount > 0) {
                            Text(
                                text = "• built-in संरक्षित प्रविष्टियाँ (सुरक्षित): ${preview.builtInConflictCount}",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.error)
                            )
                        }
                    }
                }

                // Safety Policy Disclaimer
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = LegalWarningContainer,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Shield,
                            contentDescription = null,
                            tint = LegalWarningAmber,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "सुरक्षा नियम: इस फ़ाइल को आयात करने से असत्यापित या समीक्षाधीन (NEEDS_REVIEW/DRAFT) रिकॉर्ड्स स्वतः प्रमोट होकर VERIFIED नहीं बनेंगे।",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontSize = 11.sp,
                                lineHeight = 15.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                enabled = !isProcessing,
                modifier = Modifier.testTag("btn_confirm_import")
            ) {
                if (isProcessing) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("सहेजा जा रहा है...")
                } else {
                    Text("आयात की पुष्टि करें")
                }
            }
        },
        dismissButton = {
            OutlinedButton(
                onClick = onCancel,
                enabled = !isProcessing,
                modifier = Modifier.testTag("btn_cancel_import")
            ) {
                Text("रद्द करें")
            }
        }
    )
}

@Composable
private fun PrivacyBullet(
    title: String,
    description: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Icon(
            imageVector = Icons.Filled.CheckCircle,
            contentDescription = null,
            tint = ForestGreenOnContainer,
            modifier = Modifier
                .size(16.dp)
                .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.labelMedium.copy(
                    fontWeight = FontWeight.Bold,
                    color = ForestGreenOnContainer
                )
            )
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall.copy(
                    color = ForestGreenOnContainer,
                    fontSize = 11.5.sp,
                    lineHeight = 16.sp
                )
            )
        }
    }
}
