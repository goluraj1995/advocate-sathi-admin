package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.DemoLegalRepository
import com.example.model.DocumentType
import com.example.model.ImportedDocument
import com.example.model.LegalAct
import com.example.model.LegalReport
import com.example.model.LegalSection
import com.example.ocr.ExtractionMethod
import com.example.ocr.FirOcrEngine
import com.example.ocr.OcrProgress
import com.example.ocr.OcrResult
import com.example.pdf.LocalPdfReportGenerator
import com.example.pdf.PdfGenerationResult
import com.example.pdf.PdfReportData
import com.example.ui.navigation.AppScreen
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.OutputStream

data class AdvocateUiState(
    val currentScreen: AppScreen = AppScreen.Home,
    val backStack: List<AppScreen> = listOf(AppScreen.Home),
    val selectedDocument: ImportedDocument? = null,
    val documentPickerMessage: String? = null,
    val firText: String = "",
    val searchQuery: String = "",
    val selectedActFilter: LegalAct? = null,
    val selectedSectionForDetail: LegalSection? = null,
    val selectedStructuredRecord: com.example.model.StructuredLegalRecord? = null,
    val selectedVerificationFilter: com.example.model.VerificationStatus? = null,
    val isShowingEmptyReports: Boolean = false,
    val demoReport: LegalReport = DemoLegalRepository.sampleDemoReport,
    val selectedLibraryAct: LegalAct? = null,
    // Milestone 2 Real OCR States
    val isOcrRunning: Boolean = false,
    val ocrProgress: OcrProgress? = null,
    val ocrResultNotice: String? = null,
    val ocrErrorNotice: String? = null,
    val ocrRecoveryHelp: String? = null,
    val extractionMethod: ExtractionMethod? = null,
    val pagesProcessedCount: Int = 0,
    // Milestone 4 Real On-Device PDF Report States
    val isGeneratingPdf: Boolean = false,
    val includeFirTextInReport: Boolean = true,
    val showPdfPreviewDialog: Boolean = false,
    val pdfExportSuccessMessage: String? = null,
    val pdfExportError: String? = null,
    val pdfLastPageCount: Int = 0,
    val pdfLastBytesWritten: Long = 0L,
    val sharePdfUri: Uri? = null,
    val linkedReportSections: List<com.example.model.StructuredLegalRecord> = emptyList(),
    // Milestone 5C Safe JSON Import States
    val isImportProcessing: Boolean = false,
    val importPreviewData: ImportPreviewData? = null,
    val importErrorMessage: String? = null,
    val importSuccessMessage: String? = null
)

data class ImportPreviewData(
    val fileName: String,
    val totalRecords: Int,
    val verifiedCount: Int,
    val publishedCount: Int,
    val needsReviewCount: Int,
    val draftCount: Int,
    val demoCount: Int,
    val builtInConflictCount: Int,
    val existingUpdateCount: Int,
    val newRecordCount: Int,
    val rawJsonString: String,
    val envelopeFilter: String
)

class AdvocateViewModel(application: Application) : AndroidViewModel(application) {

    private val ocrEngine = FirOcrEngine(application)
    private val pdfGenerator = LocalPdfReportGenerator(application)
    private var activeOcrJob: Job? = null
    private var currentOcrJobId: Long = 0L

    private val _uiState = MutableStateFlow(
        AdvocateUiState(
            linkedReportSections = listOfNotNull(
                com.example.data.OfficialLegalRepository.getRecordById("bns_sec_303"),
                com.example.data.OfficialLegalRepository.getRecordById("bns_sec_351"),
                com.example.data.OfficialLegalRepository.getRecordById("bnss_sec_173")
            )
        )
    )
    val uiState: StateFlow<AdvocateUiState> = _uiState.asStateFlow()

    fun navigateTo(screen: AppScreen) {
        _uiState.update { current ->
            if (current.currentScreen == screen) {
                current
            } else {
                val newStack = current.backStack.toMutableList()
                if (screen == AppScreen.Home) {
                    newStack.clear()
                    newStack.add(AppScreen.Home)
                } else {
                    newStack.add(screen)
                }
                current.copy(
                    currentScreen = screen,
                    backStack = newStack
                )
            }
        }
    }

    fun navigateBack(): Boolean {
        var handled = false
        _uiState.update { current ->
            if (current.isOcrRunning) {
                cancelOcr()
                handled = true
                current
            } else if (current.selectedStructuredRecord != null) {
                handled = true
                current.copy(selectedStructuredRecord = null)
            } else if (current.selectedSectionForDetail != null) {
                handled = true
                current.copy(selectedSectionForDetail = null)
            } else if (current.selectedLibraryAct != null) {
                handled = true
                current.copy(selectedLibraryAct = null)
            } else if (current.backStack.size > 1) {
                handled = true
                val newStack = current.backStack.dropLast(1)
                val previousScreen = newStack.lastOrNull() ?: AppScreen.Home
                current.copy(
                    currentScreen = previousScreen,
                    backStack = newStack
                )
            } else if (current.currentScreen != AppScreen.Home) {
                handled = true
                current.copy(
                    currentScreen = AppScreen.Home,
                    backStack = listOf(AppScreen.Home)
                )
            } else {
                handled = false
                current
            }
        }
        return handled
    }

    fun onDocumentSelected(fileName: String, sizeFormatted: String, type: DocumentType, uriString: String?) {
        _uiState.update {
            it.copy(
                selectedDocument = ImportedDocument(
                    uriString = uriString,
                    fileName = fileName,
                    fileSizeFormatted = sizeFormatted,
                    fileType = type
                ),
                documentPickerMessage = null,
                ocrErrorNotice = null,
                ocrRecoveryHelp = null,
                ocrResultNotice = null
            )
        }
    }

    fun setDocumentPickerMessage(message: String) {
        _uiState.update {
            it.copy(documentPickerMessage = message)
        }
    }

    fun clearSelectedDocument() {
        cancelOcr()
        _uiState.update {
            it.copy(
                selectedDocument = null,
                documentPickerMessage = null,
                ocrErrorNotice = null,
                ocrRecoveryHelp = null,
                ocrResultNotice = null,
                ocrProgress = null
            )
        }
    }

    /**
     * Executes real on-device OCR or PDF extraction asynchronously using FirOcrEngine.
     */
    fun startOcrProcessing() {
        val doc = _uiState.value.selectedDocument
        val uriStr = doc?.uriString
        if (uriStr == null) {
            _uiState.update {
                it.copy(
                    ocrErrorNotice = "कोई वैध फ़ाइल चयनित नहीं है।",
                    ocrRecoveryHelp = "कृपया पहले कोई पीडीएफ या फोटो फ़ाइल चुनें।"
                )
            }
            return
        }

        activeOcrJob?.cancel()
        val jobId = ++currentOcrJobId

        _uiState.update {
            it.copy(
                isOcrRunning = true,
                ocrProgress = OcrProgress(stageMessage = "फ़ाइल जाँची जा रही है...", progressFraction = 0.05f),
                ocrErrorNotice = null,
                ocrRecoveryHelp = null,
                ocrResultNotice = null
            )
        }

        activeOcrJob = viewModelScope.launch {
            val uri = Uri.parse(uriStr)
            val result = when (doc.fileType) {
                DocumentType.IMAGE -> ocrEngine.processImage(uri) { progress ->
                    if (jobId == currentOcrJobId) {
                        _uiState.update { it.copy(ocrProgress = progress) }
                    }
                }
                DocumentType.PDF -> ocrEngine.processPdf(uri) { progress ->
                    if (jobId == currentOcrJobId) {
                        _uiState.update { it.copy(ocrProgress = progress) }
                    }
                }
            }

            if (jobId == currentOcrJobId) {
                when (result) {
                    is OcrResult.Success -> {
                        _uiState.update {
                            it.copy(
                                isOcrRunning = false,
                                ocrProgress = null,
                                firText = result.text,
                                extractionMethod = result.method,
                                pagesProcessedCount = result.pageCount,
                                ocrResultNotice = result.warningNotice ?: "ऑन-डिवाइस OCR सफलतापूर्वक पूर्ण हुआ (${result.pageCount} पृष्ठ विश्लेषित)।",
                                ocrErrorNotice = null,
                                ocrRecoveryHelp = null
                            )
                        }
                        // Automatically navigate to review screen so user can verify/edit
                        navigateTo(AppScreen.ExtractedText)
                    }

                    is OcrResult.Empty -> {
                        _uiState.update {
                            it.copy(
                                isOcrRunning = false,
                                ocrProgress = null,
                                extractionMethod = result.method,
                                ocrResultNotice = result.reasonMessage,
                                ocrErrorNotice = null,
                                ocrRecoveryHelp = null
                            )
                        }
                        navigateTo(AppScreen.ExtractedText)
                    }

                    is OcrResult.Error -> {
                        _uiState.update {
                            it.copy(
                                isOcrRunning = false,
                                ocrProgress = null,
                                ocrErrorNotice = result.userMessage,
                                ocrRecoveryHelp = result.recoveryHelp
                            )
                        }
                    }
                }
            }
        }
    }

    fun cancelOcr() {
        currentOcrJobId++
        activeOcrJob?.cancel()
        activeOcrJob = null
        _uiState.update {
            it.copy(
                isOcrRunning = false,
                ocrProgress = null
            )
        }
    }

    fun clearOcrError() {
        _uiState.update {
            it.copy(
                ocrErrorNotice = null,
                ocrRecoveryHelp = null
            )
        }
    }

    fun updateFirText(newText: String) {
        _uiState.update {
            it.copy(
                firText = newText,
                extractionMethod = if (it.extractionMethod == null) ExtractionMethod.MANUAL_ENTRY else it.extractionMethod
            )
        }
    }

    fun clearFirText() {
        _uiState.update {
            it.copy(
                firText = "",
                extractionMethod = null,
                ocrResultNotice = null
            )
        }
    }

    fun insertSampleFirText() {
        val sample = """
            प्राथमिकी सूचना रिपोर्ट (नमूना पाठ - केवल परीक्षण हेतु)
            थाना: सिविल लाइन्स | जिला: मध्य
            शिकायतकर्ता का कथन:
            दिनांक 15 अगस्त 2024 को शाम लगभग 07:30 बजे जब मैं बाजार से लौट रहा था, तभी दो अज्ञात व्यक्तियों ने मुझे रोककर मेरा मोबाइल फोन छीन लिया (बीएनएस धारा 303)। विरोध करने पर उन्होंने मुझे जान से मारने की धमकी दी (बीएनएस धारा 351)।
            कृपया आवश्यक कानूनी कार्यवाही करने की कृपा करें।
        """.trimIndent()
        _uiState.update {
            it.copy(
                firText = sample,
                extractionMethod = ExtractionMethod.MANUAL_ENTRY,
                ocrResultNotice = "परीक्षण हेतु नमूना एफआईआर पाठ लोड किया गया।"
            )
        }
    }

    fun setSearchQuery(query: String) {
        _uiState.update {
            it.copy(searchQuery = query)
        }
    }

    fun setActFilter(act: LegalAct?) {
        _uiState.update {
            it.copy(selectedActFilter = act)
        }
    }

    fun selectSectionForDetail(section: LegalSection?) {
        _uiState.update {
            it.copy(selectedSectionForDetail = section)
        }
    }

    fun selectStructuredRecord(record: com.example.model.StructuredLegalRecord?) {
        _uiState.update {
            it.copy(selectedStructuredRecord = record)
        }
    }

    fun setVerificationFilter(filter: com.example.model.VerificationStatus?) {
        _uiState.update {
            it.copy(selectedVerificationFilter = filter)
        }
    }

    fun selectLibraryAct(act: LegalAct?) {
        _uiState.update {
            it.copy(selectedLibraryAct = act)
        }
    }

    fun toggleEmptyReports() {
        _uiState.update {
            it.copy(isShowingEmptyReports = !it.isShowingEmptyReports)
        }
    }

    fun setIncludeFirTextInReport(include: Boolean) {
        _uiState.update { it.copy(includeFirTextInReport = include) }
    }

    fun setShowPdfPreviewDialog(show: Boolean) {
        _uiState.update { it.copy(showPdfPreviewDialog = show) }
    }

    fun clearPdfMessages() {
        _uiState.update {
            it.copy(
                pdfExportSuccessMessage = null,
                pdfExportError = null
            )
        }
    }

    fun onPdfExportCancelled() {
        _uiState.update {
            it.copy(
                isGeneratingPdf = false,
                pdfExportSuccessMessage = null,
                pdfExportError = null
            )
        }
    }

    fun createPdfReportData(): PdfReportData {
        val state = _uiState.value
        val doc = state.selectedDocument
        return PdfReportData(
            reportTitle = "दस्तावेज़ समीक्षा रिपोर्ट",
            appName = "एडवोकेट साथी",
            documentName = doc?.fileName,
            documentTypeLabel = when (doc?.fileType) {
                DocumentType.PDF -> "पीडीएफ दस्तावेज़ (PDF)"
                DocumentType.IMAGE -> "तस्वीर / स्कैन प्रति (Image)"
                null -> if (state.firText.isNotBlank()) "सीधे दर्ज प्राथमिकी पाठ" else null
            },
            extractionMethodLabel = when (state.extractionMethod) {
                ExtractionMethod.IMAGE_OCR -> "इमेज ऑन-डिवाइस OCR (ML Kit Devanagari)"
                ExtractionMethod.PDF_EMBEDDED -> "डिजिटल पीडीएफ पाठ निष्कर्षण (Embedded Text)"
                ExtractionMethod.PDF_RENDERED_OCR -> "पीडीएफ पृष्ठ OCR (PdfRenderer + ML Kit)"
                ExtractionMethod.HYBRID_PDF -> "मिश्रित निष्कर्षण (डिजिटल + OCR)"
                ExtractionMethod.MANUAL_ENTRY -> "उपयोगकर्ता द्वारा मैन्युअल प्रविष्टि"
                null -> null
            },
            pagesProcessed = state.pagesProcessedCount,
            firText = state.firText.ifBlank { null },
            includeFirText = state.includeFirTextInReport,
            linkedSections = if (state.linkedReportSections.isNotEmpty()) {
                state.linkedReportSections
            } else {
                listOfNotNull(
                    com.example.data.OfficialLegalRepository.getRecordById("bns_sec_303"),
                    com.example.data.OfficialLegalRepository.getRecordById("bns_sec_351"),
                    com.example.data.OfficialLegalRepository.getRecordById("bnss_sec_173")
                )
            },
            isDemoData = state.isShowingEmptyReports || (doc == null && state.firText.contains("नमूना"))
        )
    }

    fun exportPdfToUri(uri: Uri): Boolean {
        val context = getApplication<Application>()
        _uiState.update { it.copy(isGeneratingPdf = true, pdfExportError = null, pdfExportSuccessMessage = null) }
        val reportData = createPdfReportData()

        return try {
            val outputStream = context.contentResolver.openOutputStream(uri)
            if (outputStream == null) {
                _uiState.update {
                    it.copy(
                        isGeneratingPdf = false,
                        pdfExportError = "फ़ाइल सहेजने हेतु स्टोरेज आउटपुट स्ट्रीम प्राप्त नहीं हो सकी।"
                    )
                }
                return false
            }

            val result: PdfGenerationResult = outputStream.use { os ->
                pdfGenerator.generateToStream(reportData, os)
            }

            if (result.success) {
                val sizeKb = (result.totalBytes / 1024L).coerceAtLeast(1L)
                _uiState.update {
                    it.copy(
                        isGeneratingPdf = false,
                        pdfExportSuccessMessage = "दस्तावेज़ समीक्षा रिपोर्ट सफलतापूर्वक सहेजी गई (${result.pageCount} पृष्ठ, $sizeKb KB)।",
                        pdfLastPageCount = result.pageCount,
                        pdfLastBytesWritten = result.totalBytes,
                        showPdfPreviewDialog = false
                    )
                }
                true
            } else {
                _uiState.update {
                    it.copy(
                        isGeneratingPdf = false,
                        pdfExportError = result.errorMessage ?: "PDF सहेजने में अज्ञात विफलता।"
                    )
                }
                false
            }
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    isGeneratingPdf = false,
                    pdfExportError = "PDF सहेजने में त्रुटि: ${e.localizedMessage ?: "अज्ञात त्रुटि"}"
                )
            }
            false
        }
    }

    fun generatePdfForShare(): Uri? {
        _uiState.update { it.copy(isGeneratingPdf = true, pdfExportError = null, pdfExportSuccessMessage = null) }
        val reportData = createPdfReportData()
        val result = pdfGenerator.generateForShare(reportData)

        _uiState.update {
            it.copy(
                isGeneratingPdf = false,
                sharePdfUri = result.shareUri,
                pdfLastPageCount = result.pageCount,
                pdfLastBytesWritten = result.totalBytes,
                pdfExportError = if (result.success) null else (result.errorMessage ?: "शेयर हेतु PDF तैयार नहीं हो सका")
            )
        }
        return result.shareUri
    }

    fun linkSectionToReport(record: com.example.model.StructuredLegalRecord) {
        _uiState.update { current ->
            if (current.linkedReportSections.any { it.recordId == record.recordId }) {
                current
            } else {
                current.copy(linkedReportSections = current.linkedReportSections + record)
            }
        }
    }

    fun removeSectionFromReport(recordId: String) {
        _uiState.update { current ->
            current.copy(linkedReportSections = current.linkedReportSections.filterNot { it.recordId == recordId })
        }
    }

    // --- Milestone 5C: Safe JSON Import Handlers ---

    fun processImportFile(uri: Uri?) {
        if (uri == null) {
            _uiState.update {
                it.copy(
                    isImportProcessing = false,
                    importErrorMessage = null
                )
            }
            return
        }

        if (_uiState.value.isImportProcessing) return

        _uiState.update {
            it.copy(
                isImportProcessing = true,
                importErrorMessage = null,
                importSuccessMessage = null,
                importPreviewData = null
            )
        }

        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val context = getApplication<Application>()
            try {
                val fileName = getFileNameFromUri(context, uri)
                val jsonString = readJsonFromUri(context, uri)

                if (jsonString.isNullOrBlank()) {
                    _uiState.update {
                        it.copy(
                            isImportProcessing = false,
                            importErrorMessage = "चयनित JSON फ़ाइल रिक्त (empty) या अपठनीय है।"
                        )
                    }
                    return@launch
                }

                val existingIds = com.example.data.OfficialLegalRepository.records.map { it.recordId }.toSet()
                val parseResult = com.example.data.importer.LegalRecordImportAdapter.parseAndValidate(
                    jsonString = jsonString,
                    existingRecordIds = existingIds,
                    allowOverwrite = true
                )

                when (parseResult) {
                    is com.example.data.importer.ImportResult.Failure -> {
                        _uiState.update {
                            it.copy(
                                isImportProcessing = false,
                                importErrorMessage = parseResult.summaryHindi
                            )
                        }
                    }

                    is com.example.data.importer.ImportResult.Success -> {
                        val records = parseResult.importedRecords
                        val builtInCount = records.count { rec ->
                            com.example.data.OfficialLegalRepository.builtInRecords.any { it.recordId == rec.recordId }
                        }
                        val existingImported = com.example.data.OfficialLegalRepository.records.filterNot { rec ->
                            com.example.data.OfficialLegalRepository.builtInRecords.any { it.recordId == rec.recordId }
                        }
                        val updateCount = records.count { rec ->
                            existingImported.any { it.recordId == rec.recordId }
                        }
                        val newCount = records.size - updateCount - builtInCount

                        val publishedCount = records.count { it.verificationStatus == com.example.model.VerificationStatus.PUBLISHED }
                        val verifiedCount = parseResult.verifiedCount - publishedCount
                        val demoCount = records.count { it.verificationStatus == com.example.model.VerificationStatus.DEMO }

                        val previewData = ImportPreviewData(
                            fileName = fileName,
                            totalRecords = parseResult.envelope.totalRecords,
                            verifiedCount = verifiedCount,
                            publishedCount = publishedCount,
                            needsReviewCount = parseResult.needsReviewCount,
                            draftCount = parseResult.draftCount,
                            demoCount = demoCount,
                            builtInConflictCount = builtInCount,
                            existingUpdateCount = updateCount,
                            newRecordCount = newCount,
                            rawJsonString = jsonString,
                            envelopeFilter = parseResult.envelope.filterApplied
                        )

                        _uiState.update {
                            it.copy(
                                isImportProcessing = false,
                                importPreviewData = previewData,
                                importErrorMessage = if (builtInCount > 0) {
                                    "चेतावनी: $builtInCount रिकॉर्ड्स आधिकारिक built-in संग्रह का हिस्सा हैं और वे ओवरराइट नहीं होंगे।"
                                } else null
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isImportProcessing = false,
                        importErrorMessage = "फ़ाइल पढ़ने में त्रुटि: ${e.localizedMessage ?: "अज्ञात त्रुटि"}"
                    )
                }
            }
        }
    }

    fun cancelImportPreview() {
        _uiState.update {
            it.copy(
                isImportProcessing = false,
                importPreviewData = null,
                importErrorMessage = null
            )
        }
    }

    fun confirmImport() {
        val preview = _uiState.value.importPreviewData ?: return
        if (_uiState.value.isImportProcessing) return

        _uiState.update { it.copy(isImportProcessing = true) }

        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val result = com.example.data.OfficialLegalRepository.importJsonPayload(
                jsonString = preview.rawJsonString,
                allowOverwrite = true
            )

            when (result) {
                is com.example.data.importer.ImportResult.Success -> {
                    val count = result.importedRecords.size
                    _uiState.update {
                        it.copy(
                            isImportProcessing = false,
                            importPreviewData = null,
                            importSuccessMessage = "आयात सफल! $count विधिक प्रविष्टियां रिपॉजिटरी में जोड़ी गई और स्थानीय रूप से सहेजी गईं।"
                        )
                    }
                }

                is com.example.data.importer.ImportResult.Failure -> {
                    _uiState.update {
                        it.copy(
                            isImportProcessing = false,
                            importErrorMessage = "आयात विफल: ${result.summaryHindi}"
                        )
                    }
                }
            }
        }
    }

    fun clearImportMessages() {
        _uiState.update {
            it.copy(
                importErrorMessage = null,
                importSuccessMessage = null
            )
        }
    }

    private fun readJsonFromUri(context: android.content.Context, uri: Uri): String? {
        val contentResolver = context.contentResolver
        contentResolver.openInputStream(uri)?.use { stream ->
            val byteArray = stream.readBytes()
            if (byteArray.size > 10 * 1024 * 1024) {
                throw IllegalArgumentException("चयनित फ़ाइल 10 MB की अधिकतम सीमा से अधिक बड़ी है।")
            }
            return String(byteArray, Charsets.UTF_8)
        }
        return null
    }

    private fun getFileNameFromUri(context: android.content.Context, uri: Uri): String {
        var name = "legal_import.json"
        try {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val nameIndex = it.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
                    if (nameIndex != -1) {
                        name = it.getString(nameIndex) ?: name
                    }
                }
            }
        } catch (e: Exception) {
            name = uri.lastPathSegment ?: name
        }
        return name
    }

    override fun onCleared() {
        super.onCleared()
        activeOcrJob?.cancel()
        ocrEngine.close()
    }
}
