package com.example.data.store

import android.content.Context
import com.example.model.CommencementStatus
import com.example.model.CrossReferenceType
import com.example.model.LegalAct
import com.example.model.SectionCrossReference
import com.example.model.StructuredLegalRecord
import com.example.model.VerificationStatus
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Custom exception thrown when local stored JSON file is corrupted or unparseable.
 * Ensures the original file is preserved on disk for recovery rather than silently erased.
 */
class LocalStoreCorruptedException(
    message: String,
    val file: File,
    cause: Throwable? = null
) : Exception(message, cause)

/**
 * On-device local file storage for imported legal records.
 * Uses private application storage (context.filesDir / imported_legal_records.json).
 *
 * SAFETY RULES:
 * 1. 100% Local: No cloud, external network APIs, or paid services.
 * 2. Atomic Writes: Writes to a temporary file, flushes/syncs, and replaces destination atomically.
 * 3. Corruption Protection: Never silently deletes or overwrites corrupted data.
 */
class LocalLegalRecordStore(val storageFile: File) {

    constructor(context: Context) : this(File(context.filesDir, DEFAULT_FILE_NAME))

    companion object {
        const val DEFAULT_FILE_NAME = "imported_legal_records.json"
    }

    /**
     * Loads saved records from internal storage.
     * @return List of saved records, or empty list if file does not exist.
     * @throws LocalStoreCorruptedException if the existing file is corrupted.
     */
    fun loadImportedRecords(): List<StructuredLegalRecord> {
        if (!storageFile.exists()) {
            return emptyList()
        }

        val content = storageFile.readText(Charsets.UTF_8).trim()
        if (content.isEmpty()) {
            return emptyList()
        }

        val rootObj: JSONObject
        try {
            rootObj = JSONObject(content)
        } catch (e: JSONException) {
            throw LocalStoreCorruptedException(
                "स्थानीय विधिक डेटा फ़ाइल की सामग्री अमान्य JSON है: ${e.localizedMessage}",
                storageFile,
                e
            )
        }

        val recordsArray = rootObj.optJSONArray("records")
            ?: throw LocalStoreCorruptedException(
                "स्थानीय विधिक डेटा फ़ाइल में 'records' ऐरे अनुपस्थित है।",
                storageFile
            )

        val list = mutableListOf<StructuredLegalRecord>()
        for (i in 0 until recordsArray.length()) {
            val recordObj = recordsArray.optJSONObject(i)
                ?: throw LocalStoreCorruptedException(
                    "स्थानीय विधिक डेटा फ़ाइल में रिकॉर्ड #$i अमान्य ऑब्जेक्ट है।",
                    storageFile
                )
            try {
                list.add(deserializeRecord(recordObj))
            } catch (e: Exception) {
                throw LocalStoreCorruptedException(
                    "स्थानीय विधिक रिकॉर्ड #$i को पढ़ना विफल: ${e.localizedMessage}",
                    storageFile,
                    e
                )
            }
        }
        return list
    }

    /**
     * Saves a list of imported records atomically to internal storage.
     * Performs atomic file replacement using a temporary file.
     *
     * @param records List of records to persist.
     * @return true if write succeeded.
     */
    fun saveImportedRecords(records: List<StructuredLegalRecord>): Boolean {
        val parentDir = storageFile.absoluteFile.parentFile
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs()
        }

        val tempFile = File(parentDir ?: File("."), "${storageFile.name}.tmp_${System.currentTimeMillis()}")

        try {
            val rootObj = JSONObject()
            rootObj.put("version", 1)
            rootObj.put("savedAt", System.currentTimeMillis())

            val recordsArray = JSONArray()
            records.forEach { record ->
                recordsArray.put(serializeRecord(record))
            }
            rootObj.put("records", recordsArray)

            val jsonString = rootObj.toString(2)

            FileOutputStream(tempFile).use { fos ->
                fos.write(jsonString.toByteArray(Charsets.UTF_8))
                fos.flush()
                fos.fd.sync()
            }

            if (tempFile.renameTo(storageFile)) {
                return true
            } else {
                java.nio.file.Files.move(
                    tempFile.toPath(),
                    storageFile.toPath(),
                    java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                    java.nio.file.StandardCopyOption.ATOMIC_MOVE
                )
                return true
            }
        } catch (e: Exception) {
            if (tempFile.exists()) {
                tempFile.delete()
            }
            throw e
        }
    }

    /**
     * Deletes the stored local file (used for clearing local cache in tests or reset).
     */
    fun clearStorage(): Boolean {
        return if (storageFile.exists()) storageFile.delete() else true
    }

    private fun serializeRecord(record: StructuredLegalRecord): JSONObject {
        val obj = JSONObject()
        obj.put("recordId", record.recordId)
        obj.put("act", record.act.code)
        obj.put("officialActTitle", record.officialActTitle)
        obj.put("shortName", record.shortName)
        obj.put("actYear", record.actYear)
        obj.put("sectionNumber", record.sectionNumber)
        obj.put("officialHeading", record.officialHeading)
        obj.put("officialHeadingHindi", record.officialHeadingHindi)
        obj.put("officialTextOrApprovedSummary", record.officialTextOrApprovedSummary)

        val keyElementsArray = JSONArray()
        record.keyElements.forEach { keyElementsArray.put(it) }
        obj.put("keyElements", keyElementsArray)

        obj.put("bailableStatus", record.bailableStatus ?: JSONObject.NULL)
        obj.put("cognizableStatus", record.cognizableStatus ?: JSONObject.NULL)
        obj.put("trialCourt", record.trialCourt ?: JSONObject.NULL)
        obj.put("commencementStatus", record.commencementStatus.name)
        obj.put("effectiveFrom", record.effectiveFrom ?: JSONObject.NULL)
        obj.put("effectiveTo", record.effectiveTo ?: JSONObject.NULL)
        obj.put("sourceTitle", record.sourceTitle)
        obj.put("officialSourceUrl", record.officialSourceUrl ?: JSONObject.NULL)
        obj.put("sourcePublicationOrGazetteDate", record.sourcePublicationOrGazetteDate ?: JSONObject.NULL)
        obj.put("lastVerifiedAt", record.lastVerifiedAt ?: JSONObject.NULL)
        obj.put("verificationStatus", record.verificationStatus.code)

        val crossRefArray = JSONArray()
        record.crossReferences.forEach { cr ->
            val crObj = JSONObject()
            crObj.put("targetAct", cr.targetAct.code)
            crObj.put("targetSectionNumber", cr.targetSectionNumber)
            crObj.put("targetHeading", cr.targetHeading)
            crObj.put("relationshipType", cr.relationshipType.name)
            crObj.put("applicabilityCaveat", cr.applicabilityCaveat)
            crObj.put("statutoryAuthorityNote", cr.statutoryAuthorityNote)
            crossRefArray.put(crObj)
        }
        obj.put("crossReferences", crossRefArray)

        obj.put("applicabilityNotes", record.applicabilityNotes)
        obj.put("proceduralCaveat", record.proceduralCaveat)

        return obj
    }

    private fun deserializeRecord(obj: JSONObject): StructuredLegalRecord {
        val recordId = obj.getString("recordId")
        val actCode = obj.getString("act")
        val act = LegalAct.fromCode(actCode)
            ?: throw IllegalArgumentException("अमान्य LegalAct कोड: '$actCode'")

        val officialActTitle = obj.getString("officialActTitle")
        val shortName = obj.getString("shortName")
        val actYear = obj.getInt("actYear")
        val sectionNumber = obj.getString("sectionNumber")
        val officialHeading = obj.getString("officialHeading")
        val officialHeadingHindi = obj.getString("officialHeadingHindi")
        val officialText = obj.getString("officialTextOrApprovedSummary")

        val keyElements = mutableListOf<String>()
        val keArray = obj.optJSONArray("keyElements")
        if (keArray != null) {
            for (i in 0 until keArray.length()) {
                val elem = keArray.optString(i, "").trim()
                if (elem.isNotBlank()) keyElements.add(elem)
            }
        }

        val bailableStatus = obj.optNullableString("bailableStatus")
        val cognizableStatus = obj.optNullableString("cognizableStatus")
        val trialCourt = obj.optNullableString("trialCourt")

        val commencementRaw = obj.getString("commencementStatus")
        val commencementStatus = CommencementStatus.entries.firstOrNull { it.name.equals(commencementRaw, ignoreCase = true) }
            ?: throw IllegalArgumentException("अमान्य CommencementStatus: '$commencementRaw'")

        val effectiveFrom = obj.optNullableString("effectiveFrom")
        val effectiveTo = obj.optNullableString("effectiveTo")
        val sourceTitle = obj.getString("sourceTitle")
        val officialSourceUrl = obj.optNullableString("officialSourceUrl")
        val sourcePublicationOrGazetteDate = obj.optNullableString("sourcePublicationOrGazetteDate")
        val lastVerifiedAt = obj.optNullableString("lastVerifiedAt")

        val verificationRaw = obj.getString("verificationStatus")
        val verificationStatus = VerificationStatus.entries.firstOrNull {
            it.code.equals(verificationRaw, ignoreCase = true) || it.name.equals(verificationRaw, ignoreCase = true)
        } ?: throw IllegalArgumentException("अमान्य VerificationStatus: '$verificationRaw'")

        val crossReferences = mutableListOf<SectionCrossReference>()
        val crArray = obj.optJSONArray("crossReferences")
        if (crArray != null) {
            for (i in 0 until crArray.length()) {
                val crObj = crArray.getJSONObject(i)
                val tActCode = crObj.getString("targetAct")
                val targetAct = LegalAct.fromCode(tActCode)
                    ?: throw IllegalArgumentException("crossReference में अमान्य targetAct: '$tActCode'")
                val targetSecNum = crObj.getString("targetSectionNumber")
                val targetHeading = crObj.getString("targetHeading")
                val relTypeRaw = crObj.getString("relationshipType")
                val relationshipType = CrossReferenceType.entries.firstOrNull { it.name.equals(relTypeRaw, ignoreCase = true) }
                    ?: throw IllegalArgumentException("crossReference में अमान्य relationshipType: '$relTypeRaw'")
                val caveat = crObj.optString(
                    "applicabilityCaveat",
                    "धारा का लागू होना अपराध की घटना तिथि पर निर्भर करता है।"
                )
                val authorityNote = crObj.optString("statutoryAuthorityNote", "")

                crossReferences.add(
                    SectionCrossReference(
                        targetAct = targetAct,
                        targetSectionNumber = targetSecNum,
                        targetHeading = targetHeading,
                        relationshipType = relationshipType,
                        applicabilityCaveat = caveat,
                        statutoryAuthorityNote = authorityNote
                    )
                )
            }
        }

        val applicabilityNotes = obj.getString("applicabilityNotes")
        val proceduralCaveat = obj.optString(
            "proceduralCaveat",
            "यह प्रविष्टि सामान्य विधिक जानकारी हेतु है; यह अदालत का निर्णय या अधिवक्ता की राय नहीं है।"
        )

        return StructuredLegalRecord(
            recordId = recordId,
            act = act,
            officialActTitle = officialActTitle,
            shortName = shortName,
            actYear = actYear,
            sectionNumber = sectionNumber,
            officialHeading = officialHeading,
            officialHeadingHindi = officialHeadingHindi,
            officialTextOrApprovedSummary = officialText,
            keyElements = keyElements,
            bailableStatus = bailableStatus,
            cognizableStatus = cognizableStatus,
            trialCourt = trialCourt,
            commencementStatus = commencementStatus,
            effectiveFrom = effectiveFrom,
            effectiveTo = effectiveTo,
            sourceTitle = sourceTitle,
            officialSourceUrl = officialSourceUrl,
            sourcePublicationOrGazetteDate = sourcePublicationOrGazetteDate,
            lastVerifiedAt = lastVerifiedAt,
            verificationStatus = verificationStatus,
            crossReferences = crossReferences,
            applicabilityNotes = applicabilityNotes,
            proceduralCaveat = proceduralCaveat
        )
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val v = optString(key).trim()
        return if (v.isEmpty() || v.equals("null", ignoreCase = true)) null else v
    }
}
