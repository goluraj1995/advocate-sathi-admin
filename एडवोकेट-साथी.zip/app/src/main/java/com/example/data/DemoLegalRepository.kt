package com.example.data

import com.example.model.LegalAct
import com.example.model.LegalReport
import com.example.model.LegalSection

/**
 * Repository providing clearly marked demo legal sections and sample reports for Milestone 1.
 * Does not communicate with external servers or fabricate verified legal advice.
 */
object DemoLegalRepository {

    const val DEMO_NOTICE = "यह केवल उदाहरणात्मक/डेमो डेटाबेस है। पूर्ण आधिकारिक कानूनी डेटाबेस आगामी संस्करण में उपलब्ध कराया जाएगा।"

    val sampleSections: List<LegalSection> = listOf(
        // BNS Sections
        LegalSection(
            id = "bns_303",
            act = LegalAct.BNS,
            sectionNumber = "धारा 303 (चोरी)",
            titleHindi = "चोरी और उसके लिए दंड",
            titleEnglish = "Theft and punishment for theft",
            simpleExplanationHindi = "जो कोई किसी व्यक्ति के कब्जे से उसकी सहमति के बिना कोई जंगम (चल) संपत्ति बेईमानी से ले लेने के आशय से हटाता है, वह चोरी करता है।",
            keyProvisionsHindi = listOf(
                "बेईमानी से संपत्ति लेने का आशय आवश्यक है",
                "संपत्ति को मालिक की सहमति के बिना हटाया जाना चाहिए",
                "शारीरिक चल संपत्ति पर लागू होता है"
            ),
            samplePunishmentText = "कारावास (अधिकतम 3 वर्ष तक) या जुर्माना, या दोनों (न्यायालय के निर्णय पर निर्भर)। पहली बार चोरी और संपत्ति ₹5,000 से कम होने पर सामुदायिक सेवा का भी विकल्प।",
            isBailable = false,
            isCognizable = true,
            compoundableStatusHindi = "न्यायालय की अनुमति से शमनीय (Compoundable with permission)",
            correspondingSectionInfo = "पूर्ववर्ती IPC की धारा 379 के समतुल्य",
            transitionalNoticeHindi = "यदि घटना 1 जुलाई 2024 के बाद की है, तो BNS 303 लागू होगी। पूर्व की घटना में IPC 379 लागू होगी।"
        ),
        LegalSection(
            id = "bns_103",
            act = LegalAct.BNS,
            sectionNumber = "धारा 103 (हत्या)",
            titleHindi = "हत्या के लिए दंड",
            titleEnglish = "Punishment for murder",
            simpleExplanationHindi = "जो कोई हत्या करता है, उसे मृत्युदंड या आजीवन कारावास से दंडित किया जाएगा और जुर्माने से भी दंडनीय होगा। इसमें मॉब लिंचिंग पर विशिष्ट प्रावधान जोड़े गए हैं।",
            keyProvisionsHindi = listOf(
                "मृत्यु कारित करने के आशय से किया गया कृत्य",
                "पाँच या अधिक व्यक्तियों के समूह द्वारा नस्ल, जाति, समुदाय आदि के आधार पर हत्या (मॉब लिंचिंग) उपधारा 2 में शामिल"
            ),
            samplePunishmentText = "मृत्युदंड या आजीवन कारावास, और जुर्माना।",
            isBailable = false,
            isCognizable = true,
            compoundableStatusHindi = "अशमनीय (Non-compoundable - समझौता संभव नहीं)",
            correspondingSectionInfo = "पूर्ववर्ती IPC की धारा 302 के समतुल्य",
            transitionalNoticeHindi = "1 जुलाई 2024 के बाद घटित अपराधों पर लागू। न्यायिक प्रक्रिया सत्र न्यायालय द्वारा विचारणीय है।"
        ),
        LegalSection(
            id = "bns_115",
            act = LegalAct.BNS,
            sectionNumber = "धारा 115 (स्वेच्छा से चोट)",
            titleHindi = "स्वेच्छा से साधारण उपहति (चोट) पहुंचाना",
            titleEnglish = "Voluntarily causing hurt",
            simpleExplanationHindi = "जो कोई ऐसा कृत्य करता है जिससे किसी व्यक्ति को शारीरिक पीड़ा, रोग या दुर्बलता कारित होती है, वह स्वेच्छा से उपहति पहुंचाना कहलाता है।",
            keyProvisionsHindi = listOf(
                "साधारण मारपीट अथवा खरोंच/चोट शामिल",
                "गंभीर चोट (Grievous Hurt) के लिए धारा 117 लागू होती है"
            ),
            samplePunishmentText = "कारावास (अधिकतम 1 वर्ष तक) या जुर्माना (₹10,000 तक) या दोनों।",
            isBailable = true,
            isCognizable = false,
            compoundableStatusHindi = "पीड़ित की सहमति से शमनीय (Compoundable)",
            correspondingSectionInfo = "पूर्ववर्ती IPC की धारा 323 के समतुल्य",
            transitionalNoticeHindi = "यह जमानती और गैर-संज्ञेय धारा है; मजिस्ट्रेट के आदेश के बिना पुलिस सीधे जांच शुरू नहीं करती।"
        ),
        LegalSection(
            id = "bns_318",
            act = LegalAct.BNS,
            sectionNumber = "धारा 318 (छल / धोखाधड़ी)",
            titleHindi = "छल करना (धोखाधड़ी) और संपत्ति परिदान",
            titleEnglish = "Cheating and dishonestly inducing delivery of property",
            simpleExplanationHindi = "जो कोई किसी व्यक्ति से कपटपूर्वक या बेईमानी से धोखा देकर कोई संपत्ति प्राप्त करता है या सहमति लेता है।",
            keyProvisionsHindi = listOf(
                "प्रारंभिक आशय में बेईमानी होना आवश्यक है",
                "आर्थिक या संपत्ति का नुकसान पहुंचाना शामिल है"
            ),
            samplePunishmentText = "साधारण छल पर 3 वर्ष तक कारावास; संपत्ति परिदान पर अधिकतम 7 वर्ष तक कारावास एवं जुर्माना।",
            isBailable = false,
            isCognizable = true,
            compoundableStatusHindi = "न्यायालय की अनुमति से शमनीय",
            correspondingSectionInfo = "पूर्ववर्ती IPC की धारा 415 एवं 420 के समतुल्य",
            transitionalNoticeHindi = "साइबर वित्तीय धोखाधड़ी के मामलों में अक्सर BNS 318 के साथ आईटी एक्ट 2000 की धाराएं भी लगाई जाती हैं।"
        ),
        LegalSection(
            id = "bns_351",
            act = LegalAct.BNS,
            sectionNumber = "धारा 351 (आपराधिक धमकी)",
            titleHindi = "आपराधिक अभित्रास (जान से मारने या नुकसान की धमकी)",
            titleEnglish = "Criminal intimidation",
            simpleExplanationHindi = "जो कोई किसी अन्य व्यक्ति को उसके शरीर, प्रतिष्ठा या संपत्ति को क्षति पहुंचाने की धमकी देता है।",
            keyProvisionsHindi = listOf(
                "धमकी का उद्देश्य भय पैदा करना या कोई कार्य करने को विवश करना होना चाहिए",
                "मौखिक, लिखित या इलेक्ट्रॉनिक माध्यम से धमकी शामिल"
            ),
            samplePunishmentText = "साधारण धमकी पर 2 वर्ष तक कारावास; मृत्यु या गंभीर चोट की धमकी पर 7 वर्ष तक कारावास।",
            isBailable = true,
            isCognizable = false,
            compoundableStatusHindi = "शमनीय (Compoundable)",
            correspondingSectionInfo = "पूर्ववर्ती IPC की धारा 506 के समतुल्य",
            transitionalNoticeHindi = "अधिकांश राज्यों में यह जमानती है, किंतु कुछ राज्य संशोधनों में गैर-जमानती घोषित है।"
        ),

        // BNSS Sections
        LegalSection(
            id = "bnss_173",
            act = LegalAct.BNSS,
            sectionNumber = "धारा 173 (एफआईआर प्रक्रिया)",
            titleHindi = "संज्ञेय मामलों में सूचना और ई-एफआईआर",
            titleEnglish = "Information in cognizable cases and e-FIR",
            simpleExplanationHindi = "थाने में एफआईआर दर्ज कराने की कानूनी प्रक्रिया। इसमें इलेक्ट्रॉनिक संचार (ई-एफआईआर) और किसी भी थाने में जीरो एफआईआर (Zero FIR) दर्ज करने का स्पष्ट वैधानिक अधिकार है।",
            keyProvisionsHindi = listOf(
                "नागरिक को एफआईआर की निःशुल्क प्रति तुरंत प्राप्त करने का अधिकार",
                "ई-एफआईआर की स्थिति में 3 दिन के भीतर हस्ताक्षर अनिवार्य",
                "3 से 7 वर्ष के दंड वाले अपराधों में प्रारंभिक जांच (Preliminary Enquiry) का विकल्प"
            ),
            samplePunishmentText = "यह प्रक्रियात्मक धारा है (दंड का प्रावधान नहीं, बल्कि पुलिस का विधिक कर्तव्य है)।",
            isBailable = true,
            isCognizable = true,
            compoundableStatusHindi = "लागू नहीं (प्रक्रिया संहिता)",
            correspondingSectionInfo = "पूर्ववर्ती CrPC की धारा 154 के समतुल्य",
            transitionalNoticeHindi = "1 जुलाई 2024 के बाद दर्ज होने वाली सभी एफआईआर पर BNSS 173 के नियम लागू होते हैं।"
        ),
        LegalSection(
            id = "bnss_35",
            act = LegalAct.BNSS,
            sectionNumber = "धारा 35 (गिरफ्तारी के नियम)",
            titleHindi = "पुलिस द्वारा बिना वारंट गिरफ्तारी की शर्तें",
            titleEnglish = "When police may arrest without warrant",
            simpleExplanationHindi = "पुलिस किन परिस्थितियों में बिना मजिस्ट्रेट के वारंट के किसी नागरिक को गिरफ्तार कर सकती है अथवा कब नोटिस देना अनिवार्य है।",
            keyProvisionsHindi = listOf(
                "7 वर्ष से कम सजा वाले अपराधों में गिरफ्तारी अनिवार्य नहीं (धारा 35(3) नोटिस देना होगा)",
                "वरिष्ठ नागरिकों या अस्वस्थ व्यक्तियों की गिरफ्तारी पर पुलिस उपाधीक्षक (DSP) स्तर की अनुमति आवश्यक",
                "गिरफ्तारी की सूचना परिवार या मित्र को देने का विधिक अधिकार"
            ),
            samplePunishmentText = "नागरिक संरक्षण एवं प्रक्रियात्मक सुरक्षा नियम।",
            isBailable = true,
            isCognizable = true,
            compoundableStatusHindi = "लागू नहीं (प्रक्रियात्मक धारा)",
            correspondingSectionInfo = "पूर्ववर्ती CrPC की धारा 41 एवं 41A के समतुल्य",
            transitionalNoticeHindi = "अनावश्यक गिरफ्तारी रोकने के लिए सर्वोच्च न्यायालय के अर्नेश कुमार दिशानिर्देशों को संहिताबद्ध किया गया है।"
        ),

        // BSA Sections
        LegalSection(
            id = "bsa_61",
            act = LegalAct.BSA,
            sectionNumber = "धारा 61 (डिजिटल साक्ष्य)",
            titleHindi = "इलेक्ट्रॉनिक या डिजिटल अभिलेखों की ग्राह्यता",
            titleEnglish = "Admissibility of electronic or digital records",
            simpleExplanationHindi = "मोबाइल कॉल रिकॉर्ड, व्हाट्सएप चैट, ईमेल, सीसीटीवी फुटेज और सर्वर लॉग्स को अदालत में प्रमाण के रूप में प्रस्तुत करने के नियम।",
            keyProvisionsHindi = listOf(
                "इलेक्ट्रॉनिक साक्ष्य को दस्तावेजी साक्ष्य के समकक्ष मान्यता",
                "प्रमाण पत्र (Certificate) के प्रारूप में नए सरलीकृत नियम",
                "डिजिटल फॉरेंसिक और हैश वैल्यू की प्रामाणिकता"
            ),
            samplePunishmentText = "साक्ष्य ग्राह्यता नियम।",
            isBailable = true,
            isCognizable = true,
            compoundableStatusHindi = "लागू नहीं (साक्ष्य कानून)",
            correspondingSectionInfo = "पूर्ववर्ती भारतीय साक्ष्य अधिनियम 1872 की धारा 65B के समतुल्य",
            transitionalNoticeHindi = "डिजिटल साक्ष्य पेश करते समय उचित प्रमाण पत्र संलग्न करना अनिवार्य है।"
        ),

        // IPC Sections
        LegalSection(
            id = "ipc_379",
            act = LegalAct.IPC,
            sectionNumber = "धारा 379 (चोरी - पुरानी)",
            titleHindi = "आईपीसी के तहत चोरी के लिए दंड",
            titleEnglish = "Punishment for theft under IPC",
            simpleExplanationHindi = "1 जुलाई 2024 से पहले घटित चोरी के मामलों में लागू दांडिक धारा।",
            keyProvisionsHindi = listOf(
                "3 वर्ष तक का कारावास अथवा जुर्माना या दोनों",
                "चल संपत्ति को गैर-कानूनी ढंग से कब्जाने पर लागू"
            ),
            samplePunishmentText = "3 वर्ष तक का कारावास, या जुर्माना, या दोनों।",
            isBailable = false,
            isCognizable = true,
            compoundableStatusHindi = "न्यायालय की अनुमति से शमनीय",
            correspondingSectionInfo = "अब नए कानून BNS की धारा 303 के अंतर्गत शामिल",
            transitionalNoticeHindi = "यदि एफआईआर में घटना की तारीख 30 जून 2024 या उससे पूर्व की है, तो यही धारा लागू रहेगी।"
        ),
        LegalSection(
            id = "ipc_420",
            act = LegalAct.IPC,
            sectionNumber = "धारा 420 (धोखाधड़ी - पुरानी)",
            titleHindi = "छल करना और संपत्ति परिदत्त करने के लिए उत्प्रेरित करना",
            titleEnglish = "Cheating and dishonestly inducing delivery of property",
            simpleExplanationHindi = "पुराने मामलों में धोखाधड़ी की बहुप्रचलित धारा, जिसमें संपत्ति हड़पने का कृत्य शामिल था।",
            keyProvisionsHindi = listOf(
                "धोखे से संपत्ति का हस्तांतरण कराना",
                "मूल्यवान प्रतिभूति का नुकसान कारित करना"
            ),
            samplePunishmentText = "7 वर्ष तक का कारावास और जुर्माना।",
            isBailable = false,
            isCognizable = true,
            compoundableStatusHindi = "न्यायालय की अनुमति से शमनीय",
            correspondingSectionInfo = "अब नए कानून BNS की धारा 318(4) के अंतर्गत शामिल",
            transitionalNoticeHindi = "पुरानी एफआईआर में इस धारा की जांच पुराने नियमों के तहत ही जारी रहेगी।"
        ),

        // CrPC Sections
        LegalSection(
            id = "crpc_154",
            act = LegalAct.CRPC,
            sectionNumber = "धारा 154 (CrPC एफआईआर)",
            titleHindi = "संज्ञेय अपराधों में पुलिस को सूचना (पुरानी प्रक्रिया)",
            titleEnglish = "Information in cognizable cases under CrPC",
            simpleExplanationHindi = "1 जुलाई 2024 से पहले दर्ज एफआईआर पर लागू मूल प्रक्रिया।",
            keyProvisionsHindi = listOf(
                "लिखित या मौखिक सूचना को दर्ज करने का पुलिस का कर्तव्य",
                "निःशुल्क प्रति प्राप्त करने का अधिकार"
            ),
            samplePunishmentText = "प्रक्रियात्मक नियम।",
            isBailable = true,
            isCognizable = true,
            compoundableStatusHindi = "लागू नहीं",
            correspondingSectionInfo = "अब BNSS की धारा 173 द्वारा प्रतिस्थापित",
            transitionalNoticeHindi = "पुराने मुकदमों के रिकॉर्ड और अपीलों में इस धारा का संदर्भ मान्य रहता है।"
        ),

        // IEA Section
        LegalSection(
            id = "iea_65b",
            act = LegalAct.IEA,
            sectionNumber = "धारा 65B (इलेक्ट्रॉनिक साक्ष्य - पुरानी)",
            titleHindi = "इलेक्ट्रॉनिक रिकॉर्ड की ग्राह्यता संबंधी विशेष प्रावधान",
            titleEnglish = "Admissibility of electronic records (IEA 1872)",
            simpleExplanationHindi = "पुराने मुकदमों में कंप्यूटर प्रिंटआउट, ऑडियो/वीडियो रिकॉर्डिंग के साथ धारा 65B का हलफनामा अनिवार्य था।",
            keyProvisionsHindi = listOf(
                "डिवाइस के प्रभारी द्वारा प्रमाण पत्र अनिवार्य",
                "अनवरत कार्यप्रणाली का विवरण"
            ),
            samplePunishmentText = "साक्ष्य नियम।",
            isBailable = true,
            isCognizable = true,
            compoundableStatusHindi = "लागू नहीं",
            correspondingSectionInfo = "अब BSA 2023 की धारा 61 व 63 द्वारा प्रतिस्थापित",
            transitionalNoticeHindi = "पुराने ट्रायल में अर्जुन पंडितराव बनाम कैलाश कुशनराव के फैसले के तहत 65B सर्टिफिकेट आवश्यक है।"
        )
    )

    val sampleDemoReport = LegalReport(
        id = "demo_report_01",
        title = "एफआईआर नमूना विश्लेषण (DEMO)",
        reportDate = "27 अक्टूबर 2024",
        firDetailsSample = "एफआईआर सं. 0142/2024, दिनांक 15 अगस्त 2024",
        policeStationSample = "थाना: सिविल लाइन्स (डेमो विवरण)",
        sections = listOf(
            sampleSections.first { it.id == "bns_303" },
            sampleSections.first { it.id == "bns_351" }
        ),
        plainSummaryHindi = "यह एक प्रदर्शनात्मक (DEMO) सारांश है। इस प्राथमिकी में शिकायतकर्ता द्वारा मोबाइल चोरी और विरोध करने पर मौखिक धमकी दिए जाने का आरोप लगाया गया है। चूंकि घटना 1 जुलाई 2024 के बाद की दर्शायी गई है, अतः नए कानून बीएनएस (BNS) की धाराएँ अंकित की गई हैं।",
        citizenRightsHindi = listOf(
            "एफआईआर की एक प्रमाणित प्रति निःशुल्क प्राप्त करने का विधिक अधिकार है (बीएनएसएस धारा 173)।",
            "यदि पुलिस द्वारा पूछताछ की जाती है, तो अपने अधिवक्ता (वकील) की उपस्थिति का अनुरोध करने का अधिकार है।",
            "गिरफ्तारी की स्थिति में 24 घंटे के भीतर निकटतम न्यायिक मजिस्ट्रेट के समक्ष पेश किया जाना अनिवार्य है।",
            "महिला अभियुक्त से पूछताछ केवल महिला पुलिस अधिकारी की उपस्थिति में ही की जा सकती है।"
        ),
        recommendedNextStepsHindi = listOf(
            "घटना की सही तिथि और समय की पुष्टि करें, ताकि यह तय हो सके कि BNS या IPC लागू होगी।",
            "घटना से जुड़े प्रत्यक्षदर्शी गवाहों और डिजिटल सबूतों (CCTV, कॉल डिटेल) को सुरक्षित रखें।",
            "अदालत में अग्रिम जमानत (Anticipatory Bail) अथवा नियमित जमानत हेतु किसी पंजीकृत अधिवक्ता से संपर्क करें।",
            "संबंधित पुलिस अधीक्षक (SP) या न्यायिक मजिस्ट्रेट को शिकायत की प्रमाणित प्रति प्रस्तुत की जा सकती है।"
        ),
        isDemo = true
    )

    fun searchSections(query: String, actFilter: LegalAct?): List<LegalSection> {
        val cleanQuery = query.trim().lowercase()
        return sampleSections.filter { section ->
            val matchesAct = (actFilter == null || section.act == actFilter)
            val matchesQuery = if (cleanQuery.isEmpty()) {
                true
            } else {
                section.sectionNumber.lowercase().contains(cleanQuery) ||
                section.titleHindi.lowercase().contains(cleanQuery) ||
                section.titleEnglish.lowercase().contains(cleanQuery) ||
                section.simpleExplanationHindi.lowercase().contains(cleanQuery) ||
                section.act.code.lowercase().contains(cleanQuery)
            }
            matchesAct && matchesQuery
        }
    }
}
