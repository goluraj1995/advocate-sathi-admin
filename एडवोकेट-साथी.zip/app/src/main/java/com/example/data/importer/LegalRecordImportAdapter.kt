package com.example.data.importer

import com.example.model.CommencementStatus
import com.example.model.CrossReferenceType
import com.example.model.LegalAct
import com.example.model.SectionCrossReference
import com.example.model.StructuredLegalRecord
import com.example.model.VerificationStatus
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject

/**
 * Metadata envelope representation matching the Admin Panel's export format.
 */
data class LegalRepositoryExportEnvelope(
    val formatVersion: String,
    val targetApplication: String,
    val exportTimestamp: String,
    val totalRecords: Int,
    val filterApplied: String,
    val records: List<StructuredLegalRecord>
)

/**
 * Sealed result type enforcing atomic, safe imports without partial failures.
 */
sealed class ImportResult {
    data class Success(
        val envelope: LegalRepositoryExportEnvelope,
        val importedRecords: List<StructuredLegalRecord>,
        val verifiedCount: Int,
        val needsReviewCount: Int,
        val draftCount: Int
    ) : ImportResult()

    data class Failure(
        val errors: List<String>,
        val exception: Throwable? = null
    ) : ImportResult() {
        val summaryHindi: String
            get() = "आयात विफल (${errors.size} त्रुटियां):\n" + errors.joinToString("\n• ", prefix = "• ")
    }
}

/**
 * Dedicated exception for legal import security violations.
 */
class LegalRecordImportException(
    val validationErrors: List<String>,
    cause: Throwable? = null
) : Exception("विधिक डेटा आयात में ${validationErrors.size} त्रुटियां पाई गईं: ${validationErrors.firstOrNull()}", cause)

/**
 * Secure, zero-cloud JSON Import Adapter for Advocate Sathi.
 *
 * STRICT SAFETY & INTEGRITY RULES:
 * 1. NEVER auto-promotes imported records to VERIFIED or PUBLISHED.
 * 2. NEVER assumes unknown/missing commencementStatus is IN_FORCE.
 * 3. Atomic Validation: Rejects malformed JSON, unknown enums, missing required fields, or unsupported versions.
 * 4. Duplicate policy: Flags duplicate recordIds to prevent silent data overwrite.
 * 5. Full fidelity: Accurately maps nullable fields, lists, and cross-references.
 */
object LegalRecordImportAdapter {

    const val SUPPORTED_FORMAT_VERSION = "1.0"

    /**
     * Parse and atomically validate an exported JSON payload.
     *
     * @param jsonString Raw JSON string from the Admin Panel.
     * @param existingRecordIds Set of recordIds already in the local repository (for duplicate detection).
     * @param allowOverwrite Whether existing records may be overwritten (default false for safety).
     * @return ImportResult.Success or ImportResult.Failure
     */
    fun parseAndValidate(
        jsonString: String,
        existingRecordIds: Set<String> = emptySet(),
        allowOverwrite: Boolean = false
    ): ImportResult {
        val errors = mutableListOf<String>()

        if (jsonString.isBlank()) {
            return ImportResult.Failure(listOf("JSON इनपुट रिक्त है।"))
        }

        val rootObj: JSONObject
        try {
            rootObj = JSONObject(jsonString)
        } catch (e: JSONException) {
            return ImportResult.Failure(listOf("अमान्य JSON प्रारूप (Malformed JSON): ${e.localizedMessage}"), e)
        }

        // --- 1. Envelope Validation ---
        val formatVersion = rootObj.optString("formatVersion", "").trim()
        if (formatVersion != SUPPORTED_FORMAT_VERSION) {
            errors.add("असमर्थित formatVersion: '$formatVersion'। केवल '$SUPPORTED_FORMAT_VERSION' समर्थित है।")
        }

        val targetApp = rootObj.optString("targetApplication", "").trim()
        if (!targetApp.contains("Advocate Sathi", ignoreCase = true) && !targetApp.contains("एडवोकेट साथी")) {
            errors.add("असंगत targetApplication: '$targetApp'। यह फ़ाइल एडवोकेट साथी हेतु नहीं है।")
        }

        val exportTimestamp = rootObj.optString("exportTimestamp", "").trim()
        if (exportTimestamp.isBlank()) {
            errors.add("exportTimestamp अनुपस्थित या रिक्त है।")
        }

        val declaredTotalRecords = rootObj.optInt("totalRecords", -1)
        val filterApplied = rootObj.optString("filterApplied", "UNKNOWN").trim()

        if (!rootObj.has("records")) {
            errors.add("'records' ऐरे अनुपस्थित है।")
            return ImportResult.Failure(errors)
        }

        val recordsArray: JSONArray
        try {
            recordsArray = rootObj.getJSONArray("records")
        } catch (e: JSONException) {
            errors.add("'records' एक मान्य JSON ऐरे नहीं है।")
            return ImportResult.Failure(errors)
        }

        if (declaredTotalRecords >= 0 && declaredTotalRecords != recordsArray.length()) {
            errors.add("घोषित totalRecords ($declaredTotalRecords) और वास्तविक रिकॉर्ड संख्या (${recordsArray.length()}) में अंतर है।")
        }

        // --- 2. Records Atomic Validation & Mapping ---
        val parsedRecords = mutableListOf<StructuredLegalRecord>()
        val seenRecordIdsInPayload = mutableSetOf<String>()

        for (i in 0 until recordsArray.length()) {
            val recordJson = recordsArray.optJSONObject(i)
            if (recordJson == null) {
                errors.add("रिकॉर्ड #$i: अमान्य ऑब्जेक्ट है।")
                continue
            }

            val recordId = recordJson.optString("recordId", "").trim()
            if (recordId.isBlank()) {
                errors.add("रिकॉर्ड #$i: 'recordId' अनिवार्य और रिक्त नहीं हो सकता।")
            } else {
                if (seenRecordIdsInPayload.contains(recordId)) {
                    errors.add("रिकॉर्ड #$i: डुप्लीकेट recordId '$recordId' पेलोड में दोहराया गया है।")
                } else {
                    seenRecordIdsInPayload.add(recordId)
                }

                if (!allowOverwrite && existingRecordIds.contains(recordId)) {
                    errors.add("रिकॉर्ड '$recordId': डेटाबेस में पहले से मौजूद है। अनपेक्षित ओवरराइटिंग रोकने हेतु अस्वीकृत।")
                }
            }

            // LegalAct enum
            val actRaw = recordJson.optString("act", "").trim()
            val act = LegalAct.fromCode(actRaw)
            if (act == null) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': अमान्य LegalAct कोड: '$actRaw' (BNS, BNSS, BSA, IPC, CRPC, IEA में से एक होना चाहिए)।")
            }

            // Official Act Title
            val officialActTitle = recordJson.optString("officialActTitle", "").trim()
            if (officialActTitle.isBlank()) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': 'officialActTitle' रिक्त नहीं हो सकता।")
            }

            // Short Name
            val shortName = recordJson.optString("shortName", "").trim()
            if (shortName.isBlank()) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': 'shortName' रिक्त नहीं हो सकता।")
            }

            // Act Year
            val actYear = recordJson.optInt("actYear", -1)
            if (actYear < 1800 || actYear > 2100) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': अमान्य 'actYear': $actYear")
            }

            // Section Number
            val sectionNumber = recordJson.optString("sectionNumber", "").trim()
            if (sectionNumber.isBlank()) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': 'sectionNumber' अनिवार्य है।")
            }

            // Headings
            val officialHeading = recordJson.optString("officialHeading", "").trim()
            if (officialHeading.isBlank()) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': 'officialHeading' अनिवार्य है।")
            }

            val officialHeadingHindi = recordJson.optString("officialHeadingHindi", "").trim()
            if (officialHeadingHindi.isBlank()) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': 'officialHeadingHindi' अनिवार्य है।")
            }

            // Statutory text
            val officialText = recordJson.optString("officialTextOrApprovedSummary", "").trim()
            if (officialText.isBlank()) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': 'officialTextOrApprovedSummary' (मूल वैधानिक पाठ) अनिवार्य है।")
            }

            // Commencement Status - CRITICAL: NEVER assume IN_FORCE on unknown
            val commencementRaw = recordJson.optString("commencementStatus", "").trim()
            val commencementStatus = CommencementStatus.entries.firstOrNull { it.name.equals(commencementRaw, ignoreCase = true) }
            if (commencementStatus == null) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': अमान्य या अज्ञात commencementStatus: '$commencementRaw' (सुरक्षा नियम: इसे कभी स्वतः IN_FORCE नहीं माना जाएगा)।")
            }

            // Source Title
            val sourceTitle = recordJson.optString("sourceTitle", "").trim()
            if (sourceTitle.isBlank()) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': 'sourceTitle' स्रोत उद्धरण अनिवार्य है।")
            }

            // Verification Status - CRITICAL: NEVER promote to VERIFIED/PUBLISHED automatically
            val verificationRaw = recordJson.optString("verificationStatus", "").trim()
            val verificationStatus = VerificationStatus.entries.firstOrNull {
                it.code.equals(verificationRaw, ignoreCase = true) || it.name.equals(verificationRaw, ignoreCase = true)
            }
            if (verificationStatus == null) {
                errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': अज्ञात verificationStatus: '$verificationRaw' (सुरक्षा नियम: असत्यापित स्थिति को कभी VERIFIED नहीं बनाया जाएगा)।")
            }

            // Key Elements list
            val keyElements = mutableListOf<String>()
            val keyElementsArray = recordJson.optJSONArray("keyElements")
            if (keyElementsArray != null) {
                for (k in 0 until keyElementsArray.length()) {
                    val elem = keyElementsArray.optString(k, "").trim()
                    if (elem.isNotBlank()) keyElements.add(elem)
                }
            }

            // Cross references
            val crossReferences = mutableListOf<SectionCrossReference>()
            val crossRefsArray = recordJson.optJSONArray("crossReferences")
            if (crossRefsArray != null) {
                for (c in 0 until crossRefsArray.length()) {
                    val crObj = crossRefsArray.optJSONObject(c)
                    if (crObj == null) {
                        errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': अमान्य crossReference ऑब्जेक्ट #$c")
                        continue
                    }
                    val targetActRaw = crObj.optString("targetAct", "").trim()
                    val targetAct = LegalAct.fromCode(targetActRaw)
                    if (targetAct == null) {
                        errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': crossReference में अमान्य targetAct: '$targetActRaw'")
                    }

                    val relTypeRaw = crObj.optString("relationshipType", "").trim()
                    val relType = CrossReferenceType.entries.firstOrNull { it.name.equals(relTypeRaw, ignoreCase = true) }
                    if (relType == null) {
                        errors.add("रिकॉर्ड '${recordId.ifBlank { "#$i" }}': crossReference में अमान्य relationshipType: '$relTypeRaw'")
                    }

                    val targetSecNum = crObj.optString("targetSectionNumber", "").trim()
                    val targetHeading = crObj.optString("targetHeading", "").trim()
                    val caveat = crObj.optString("applicabilityCaveat", "धारा का लागू होना अपराध की घटना तिथि और संक्रमणकालीन नियमों पर निर्भर करता है।")
                    val authorityNote = crObj.optString("statutoryAuthorityNote", "")

                    if (targetAct != null && relType != null) {
                        crossReferences.add(
                            SectionCrossReference(
                                targetAct = targetAct,
                                targetSectionNumber = targetSecNum,
                                targetHeading = targetHeading,
                                relationshipType = relType,
                                applicabilityCaveat = caveat,
                                statutoryAuthorityNote = authorityNote
                            )
                        )
                    }
                }
            }

            // Nullable string fields
            val bailableStatus = recordJson.optNullableString("bailableStatus")
            val cognizableStatus = recordJson.optNullableString("cognizableStatus")
            val trialCourt = recordJson.optNullableString("trialCourt")
            val effectiveFrom = recordJson.optNullableString("effectiveFrom")
            val effectiveTo = recordJson.optNullableString("effectiveTo")
            val officialSourceUrl = recordJson.optNullableString("officialSourceUrl")
            val sourcePublicationOrGazetteDate = recordJson.optNullableString("sourcePublicationOrGazetteDate")
            val lastVerifiedAt = recordJson.optNullableString("lastVerifiedAt")
            val applicabilityNotes = recordJson.optString("applicabilityNotes", "1 जुलाई 2024 के आपराधिक संक्रमण नियम लागू होंगे।")
            val proceduralCaveat = recordJson.optString(
                "proceduralCaveat",
                "यह प्रविष्टि सामान्य विधिक जानकारी हेतु है; यह अदालत का निर्णय या अधिवक्ता की राय नहीं है।"
            )

            // Construct record if all critical fields passed
            if (act != null && commencementStatus != null && verificationStatus != null &&
                recordId.isNotBlank() && officialActTitle.isNotBlank() && shortName.isNotBlank() &&
                sectionNumber.isNotBlank() && officialHeading.isNotBlank() && officialHeadingHindi.isNotBlank() &&
                officialText.isNotBlank() && sourceTitle.isNotBlank()
            ) {
                parsedRecords.add(
                    StructuredLegalRecord(
                        recordId = recordId,
                        act = act,
                        officialActTitle = officialActTitle,
                        shortName = shortName,
                        actYear = actYear,
                        sectionNumber = sectionNumber,
                        officialHeading = officialHeading,
                        officialHeadingHindi = officialHeadingHindi,
                        officialTextOrApprovedSummary = officialText,
                        keyElements = keyElements,
                        bailableStatus = bailableStatus,
                        cognizableStatus = cognizableStatus,
                        trialCourt = trialCourt,
                        commencementStatus = commencementStatus,
                        effectiveFrom = effectiveFrom,
                        effectiveTo = effectiveTo,
                        sourceTitle = sourceTitle,
                        officialSourceUrl = officialSourceUrl,
                        sourcePublicationOrGazetteDate = sourcePublicationOrGazetteDate,
                        lastVerifiedAt = lastVerifiedAt,
                        verificationStatus = verificationStatus,
                        crossReferences = crossReferences,
                        applicabilityNotes = applicabilityNotes,
                        proceduralCaveat = proceduralCaveat
                    )
                )
            }
        }

        // --- 3. Atomic Decision: All or Nothing ---
        if (errors.isNotEmpty()) {
            return ImportResult.Failure(errors)
        }

        val envelope = LegalRepositoryExportEnvelope(
            formatVersion = formatVersion,
            targetApplication = targetApp,
            exportTimestamp = exportTimestamp,
            totalRecords = declaredTotalRecords.takeIf { it >= 0 } ?: parsedRecords.size,
            filterApplied = filterApplied,
            records = parsedRecords
        )

        val verifiedCount = parsedRecords.count { it.verificationStatus == VerificationStatus.VERIFIED || it.verificationStatus == VerificationStatus.PUBLISHED }
        val needsReviewCount = parsedRecords.count { it.verificationStatus == VerificationStatus.NEEDS_REVIEW }
        val draftCount = parsedRecords.count { it.verificationStatus == VerificationStatus.DRAFT || it.verificationStatus == VerificationStatus.DEMO }

        return ImportResult.Success(
            envelope = envelope,
            importedRecords = parsedRecords,
            verifiedCount = verifiedCount,
            needsReviewCount = needsReviewCount,
            draftCount = draftCount
        )
    }

    /**
     * Helper to retrieve a nullable string from JSONObject, treating null, "null", or missing as null.
     */
    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        val v = optString(key).trim()
        return if (v.isEmpty() || v.equals("null", ignoreCase = true)) null else v
    }
}
