package com.example.data

import android.content.Context
import com.example.data.importer.ImportResult
import com.example.data.importer.LegalRecordImportAdapter
import com.example.data.store.LocalLegalRecordStore
import com.example.model.CommencementStatus
import com.example.model.CrossReferenceType
import com.example.model.LegalAct
import com.example.model.SectionCrossReference
import com.example.model.StructuredLegalRecord
import com.example.model.VerificationStatus
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Official Legal Information Repository for Indian Criminal Laws:
 * - Bharatiya Nyaya Sanhita, 2023 (BNS)
 * - Bharatiya Nagarik Suraksha Sanhita, 2023 (BNSS)
 * - Bharatiya Sakshya Adhiniyam, 2023 (BSA)
 * - Indian Penal Code, 1860 (IPC)
 * - Code of Criminal Procedure, 1973 (CrPC)
 * - Indian Evidence Act, 1872 (IEA)
 *
 * SAFETY & INTEGRITY RULES:
 * 1. Built-in records are hardcoded and verified from primary sources (Gazette of India, India Code, MHA Notifications).
 * 2. Built-in records can NEVER be overwritten or deleted by imports.
 * 3. Imported records are persisted locally in on-device storage via [LocalLegalRecordStore].
 * 4. Thread-safe dynamic state exposure via [recordsFlow] and [records].
 */
object OfficialLegalRepository {

    const val REPOSITORY_NOTICE_HINDI =
        "यह कानूनी सूचना रिपोजिटरी प्राथमिक आधिकारिक स्रोतों (भारत का राजपत्र, इंडिया कोड, गृह मंत्रालय अधिसूचना) पर आधारित है। असत्यापित प्रविष्टियाँ 'समीक्षाधीन' के रूप में चिन्हित हैं।"

    /**
     * Immutable built-in statutory records compiled into the app.
     */
    val builtInRecords: List<StructuredLegalRecord> = listOf(
        // =========================================================================
        // 1. VERIFIED PRIMARY RECORDS (Verified from Gazette / MHA Notifications)
        // =========================================================================

        // BNS Section 1 (VERIFIED)
        StructuredLegalRecord(
            recordId = "bns_sec_1",
            act = LegalAct.BNS,
            officialActTitle = "The Bharatiya Nyaya Sanhita, 2023",
            shortName = "BNS, 2023",
            actYear = 2023,
            sectionNumber = "1",
            officialHeading = "Short title, commencement and application",
            officialHeadingHindi = "संक्षिप्त नाम, प्रारंभ और लागू होना",
            officialTextOrApprovedSummary = "यह अधिनियम भारतीय न्याय संहिता, 2023 कहलाएगा। यह उस तारीख को प्रवृत्त होगा जो केंद्रीय सरकार, राजपत्र में अधिसूचना द्वारा नियत करे। (गृह मंत्रालय की अधिसूचना का.आ. 850(अ) दिनांक 23 फरवरी 2024 के अनुसार धारा 106 की उपधारा (2) को छोड़कर 1 जुलाई 2024 से प्रवृत्त)। यह भारत के भीतर एवं बाहर भारतीय नागरिकों द्वारा किए गए अपराधों पर लागू होता है।",
            keyElements = listOf(
                "संक्षिप्त नाम: भारतीय न्याय संहिता, 2023 (Act No. 45 of 2023)",
                "लागू होने की प्रभावी तिथि: 1 जुलाई 2024 (धारा 106(2) को छोड़कर)",
                "अधिसूचना: गृह मंत्रालय अधिसूचना S.O. 850(E) दिनांक 23.02.2024",
                "क्षेत्राधिकार: भारत का संपूर्ण भूभाग तथा राज्यक्षेत्रातीत लागू होना"
            ),
            bailableStatus = "लागू नहीं (परिचयात्मक धारा)",
            cognizableStatus = "लागू नहीं",
            trialCourt = "लागू नहीं",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "Gazette of India, Extraordinary, Part II-Sec. 1, No. 45 of 2023 & MHA Notification S.O. 850(E)",
            officialSourceUrl = "https://www.indiacode.nic.in/handle/123456789/21734",
            sourcePublicationOrGazetteDate = "2023-12-25 / 2024-02-23",
            lastVerifiedAt = "2024-10-27",
            verificationStatus = VerificationStatus.VERIFIED,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.IPC,
                    targetSectionNumber = "1, 2, 3, 4",
                    targetHeading = "Title, extent of operation, extraterritorial operation",
                    relationshipType = CrossReferenceType.CORRESPONDING_PROVISION,
                    statutoryAuthorityNote = "IPC 1860 की धारा 1 से 4 के परिचयात्मक एवं क्षेत्राधिकार प्रावधानों का समेकन।"
                )
            ),
            applicabilityNotes = "1 जुलाई 2024 को या उसके पश्चात घटित दांडिक घटनाओं पर BNS लागू होती है।"
        ),

        // BNS Section 358 (VERIFIED) - Repeal and Savings
        StructuredLegalRecord(
            recordId = "bns_sec_358",
            act = LegalAct.BNS,
            officialActTitle = "The Bharatiya Nyaya Sanhita, 2023",
            shortName = "BNS, 2023",
            actYear = 2023,
            sectionNumber = "358",
            officialHeading = "Repeal and savings",
            officialHeadingHindi = "निरसन और व्यावृत्तियां",
            officialTextOrApprovedSummary = "भारतीय दंड संहिता, 1860 (1860 का 45) इसके द्वारा निरसित की जाती है। परंतु ऐसा निरसन पूर्ववर्ती संप्रवर्तन, उपगत अधिकार, विशेषाधिकार, दायित्व या शास्ति पर प्रभाव नहीं डालेगा; और पूर्ववर्ती कानून के अधीन शुरू की गई किसी जांच, विधिक कार्यवाही या उपचार को ऐसे जारी रखा जा सकेगा मानो यह संहिता पारित ही न हुई हो।",
            keyElements = listOf(
                "भारतीय दंड संहिता (IPC 1860) को निरसित (Repealed) किया गया",
                "व्यावृत्ति (Savings Clause): 1 जुलाई 2024 से पूर्व के मामलों में IPC के तहत कार्रवाई जारी रहेगी",
                "संविधान के अनुच्छेद 20(1) (भूतलक्षी दांडिक विधि का प्रतिषेध) के अनुरूप संरक्षण"
            ),
            bailableStatus = "लागू नहीं (निरसन प्रावधान)",
            cognizableStatus = "लागू नहीं",
            trialCourt = "लागू नहीं",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "The Bharatiya Nyaya Sanhita, 2023 (Act No. 45 of 2023), Section 358",
            officialSourceUrl = "https://www.indiacode.nic.in/handle/123456789/21734",
            sourcePublicationOrGazetteDate = "2023-12-25",
            lastVerifiedAt = "2024-10-27",
            verificationStatus = VerificationStatus.VERIFIED,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.IPC,
                    targetSectionNumber = "संपूर्ण अधिनियम (1860 का 45)",
                    targetHeading = "Indian Penal Code, 1860",
                    relationshipType = CrossReferenceType.REPEALED_WITHOUT_REPLACEMENT,
                    statutoryAuthorityNote = "IPC 1860 को BNS धारा 358(1) द्वारा निरसित किया गया, किंतु पूर्ववर्ती मामलों के लिए धारा 358(2) में संरक्षण।"
                )
            ),
            applicabilityNotes = "क्रिमिनल केस में घटना की तिथि निर्णायक है: यदि अपराध 30 जून 2024 या उससे पहले का है, तो IPC ही लागू रहेगी।"
        ),

        // BNSS Section 1 (VERIFIED)
        StructuredLegalRecord(
            recordId = "bnss_sec_1",
            act = LegalAct.BNSS,
            officialActTitle = "The Bharatiya Nagarik Suraksha Sanhita, 2023",
            shortName = "BNSS, 2023",
            actYear = 2023,
            sectionNumber = "1",
            officialHeading = "Short title, extent and commencement",
            officialHeadingHindi = "संक्षिप्त नाम, विस्तार और प्रारंभ",
            officialTextOrApprovedSummary = "यह अधिनियम भारतीय नागरिक सुरक्षा संहिता, 2023 कहलाएगा। यह 1 जुलाई 2024 से प्रवृत्त हुआ (गृह मंत्रालय अधिसूचना का.आ. 848(अ) दिनांक 23 फरवरी 2024)। यह संपूर्ण भारत पर लागू होता है (नागालैंड तथा जनजाति क्षेत्रों पर अध्याय VIII, X और XI को छोड़कर अन्य प्रावधान केवल राज्य सरकार की अधिसूचना द्वारा लागू होंगे)।",
            keyElements = listOf(
                "संक्षिप्त नाम: भारतीय नागरिक सुरक्षा संहिता, 2023 (Act No. 46 of 2023)",
                "प्रभावी तिथि: 1 जुलाई 2024",
                "अधिसूचना: गृह मंत्रालय अधिसूचना S.O. 848(E) दिनांक 23.02.2024",
                "दंड प्रक्रिया संहिता (CrPC 1973) का नया आधुनिक प्रक्रियात्मक रूप"
            ),
            bailableStatus = "लागू नहीं (परिचयात्मक धारा)",
            cognizableStatus = "लागू नहीं",
            trialCourt = "लागू नहीं",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "Gazette of India, Extraordinary, Part II-Sec. 1, No. 46 of 2023 & MHA Notification S.O. 848(E)",
            officialSourceUrl = "https://www.indiacode.nic.in/handle/123456789/21735",
            sourcePublicationOrGazetteDate = "2023-12-25 / 2024-02-23",
            lastVerifiedAt = "2024-10-27",
            verificationStatus = VerificationStatus.VERIFIED,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.CRPC,
                    targetSectionNumber = "1",
                    targetHeading = "Short title, extent and commencement of CrPC 1973",
                    relationshipType = CrossReferenceType.CORRESPONDING_PROVISION,
                    statutoryAuthorityNote = "CrPC 1973 की धारा 1 का आधुनिक स्थान।"
                )
            ),
            applicabilityNotes = "1 जुलाई 2024 के बाद दर्ज होने वाली प्राथमिकी और शुरू होने वाली जांच प्रक्रिया पर BNSS लागू होती है।"
        ),

        // BNSS Section 531 (VERIFIED) - Repeal and Savings
        StructuredLegalRecord(
            recordId = "bnss_sec_531",
            act = LegalAct.BNSS,
            officialActTitle = "The Bharatiya Nagarik Suraksha Sanhita, 2023",
            shortName = "BNSS, 2023",
            actYear = 2023,
            sectionNumber = "531",
            officialHeading = "Repeal and savings",
            officialHeadingHindi = "निरसन और व्यावृत्तियां",
            officialTextOrApprovedSummary = "दंड प्रक्रिया संहिता, 1973 (1974 का 2) इसके द्वारा निरसित की जाती है। परंतु यदि इस संहिता के प्रवृत्त होने के ठीक पहले कोई अपील, आवेदन, विचारण, जांच या अन्वेषण लंबित है, तो उसका निपटारा ऐसे किया जाएगा मानो यह संहिता प्रवृत्त ही न हुई हो (CrPC 1973 के अनुसार)।",
            keyElements = listOf(
                "दंड प्रक्रिया संहिता (CrPC 1973) को निरसित (Repealed) किया गया",
                "व्यावृत्ति (Savings Clause): 1 जुलाई 2024 से पहले लंबित सभी जांच, ट्रायल, अपील और आवेदनों पर CrPC 1973 के तहत ही सुनवाई जारी रहेगी",
                "प्रक्रियात्मक निरंतरता का वैधानिक संरक्षण"
            ),
            bailableStatus = "लागू नहीं (प्रक्रियात्मक निरसन)",
            cognizableStatus = "लागू नहीं",
            trialCourt = "लागू नहीं",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "The Bharatiya Nagarik Suraksha Sanhita, 2023 (Act No. 46 of 2023), Section 531",
            officialSourceUrl = "https://www.indiacode.nic.in/handle/123456789/21735",
            sourcePublicationOrGazetteDate = "2023-12-25",
            lastVerifiedAt = "2024-10-27",
            verificationStatus = VerificationStatus.VERIFIED,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.CRPC,
                    targetSectionNumber = "484",
                    targetHeading = "Repeal and savings under CrPC 1973",
                    relationshipType = CrossReferenceType.CORRESPONDING_PROVISION,
                    statutoryAuthorityNote = "जैसे CrPC 1973 की धारा 484 ने 1898 की संहिता को निरसित किया था, वैसे BNSS 531 ने 1973 की संहिता को निरसित किया।"
                )
            ),
            applicabilityNotes = "यदि 1 जुलाई 2024 से पहले कोई मुकदमा अथवा पुलिस विवेचना चल रही थी, तो वह CrPC 1973 के तहत ही जारी रहेगी।"
        ),

        // BSA Section 1 (VERIFIED)
        StructuredLegalRecord(
            recordId = "bsa_sec_1",
            act = LegalAct.BSA,
            officialActTitle = "The Bharatiya Sakshya Adhiniyam, 2023",
            shortName = "BSA, 2023",
            actYear = 2023,
            sectionNumber = "1",
            officialHeading = "Short title, application and commencement",
            officialHeadingHindi = "संक्षिप्त नाम, लागू होना और प्रारंभ",
            officialTextOrApprovedSummary = "यह अधिनियम भारतीय साक्ष्य अधिनियम, 2023 कहलाएगा। यह 1 जुलाई 2024 से प्रवृत्त हुआ (गृह मंत्रालय अधिसूचना का.आ. 849(अ) दिनांक 23 फरवरी 2024)। यह सेना न्यायालयों (कुछ अपवादों सहित) सहित सभी न्यायालयों के समक्ष सभी न्यायिक कार्यवाहियों को लागू होता है।",
            keyElements = listOf(
                "संक्षिप्त नाम: भारतीय साक्ष्य अधिनियम, 2023 (Act No. 47 of 2023)",
                "प्रभावी तिथि: 1 जुलाई 2024",
                "अधिसूचना: गृह मंत्रालय अधिसूचना S.O. 849(E) दिनांक 23.02.2024",
                "इलेक्ट्रॉनिक एवं डिजिटल रिकॉर्ड को प्राथमिक साक्ष्य के रूप में व्यापक मान्यता"
            ),
            bailableStatus = "लागू नहीं (साक्ष्य विधि)",
            cognizableStatus = "लागू नहीं",
            trialCourt = "समस्त न्यायिक न्यायालय",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "Gazette of India, Extraordinary, Part II-Sec. 1, No. 47 of 2023 & MHA Notification S.O. 849(E)",
            officialSourceUrl = "https://www.indiacode.nic.in/handle/123456789/21736",
            sourcePublicationOrGazetteDate = "2023-12-25 / 2024-02-23",
            lastVerifiedAt = "2024-10-27",
            verificationStatus = VerificationStatus.VERIFIED,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.IEA,
                    targetSectionNumber = "1",
                    targetHeading = "Short title, extent and commencement of Indian Evidence Act, 1872",
                    relationshipType = CrossReferenceType.CORRESPONDING_PROVISION,
                    statutoryAuthorityNote = "भारतीय साक्ष्य अधिनियम, 1872 (1872 का 1) का नवीन प्रतिस्थापन।"
                )
            ),
            applicabilityNotes = "न्यायालयीन साक्ष्य प्रस्तुत करने के नए नियम 1 जुलाई 2024 से प्रभावी।"
        ),

        // =========================================================================
        // 2. OFFENCE SECTIONS MARKED AS "NEEDS_REVIEW"
        // =========================================================================

        // BNS Section 303 (Theft) - NEEDS_REVIEW
        StructuredLegalRecord(
            recordId = "bns_sec_303",
            act = LegalAct.BNS,
            officialActTitle = "The Bharatiya Nyaya Sanhita, 2023",
            shortName = "BNS, 2023",
            actYear = 2023,
            sectionNumber = "303",
            officialHeading = "Theft and punishment for theft",
            officialHeadingHindi = "चोरी और उसके लिए दंड",
            officialTextOrApprovedSummary = "समीक्षाधीन सारांश: जो कोई किसी व्यक्ति के कब्जे से उसकी सम्मति के बिना कोई जंगम संपत्ति बेईमानी से ले लेने का आशय रखते हुए वह संपत्ति हटाता है, वह चोरी करता है। उपधारा (2) में 3 वर्ष तक का कारावास, या जुर्माना, या दोनों का प्रावधान है। यदि चुराई गई संपत्ति का मूल्य 5,000 रुपये से कम है और व्यक्ति पहली बार दोषी पाया जाता है, तो सामुदायिक सेवा का प्रावधान है।",
            keyElements = listOf(
                "समीक्षाधीन विवरण: पूर्ण राजपत्रित मूल पाठ का मिलान अभी प्रक्रियाधीन है",
                "चल संपत्ति को बिना सहमति बेईमानी से हटाना",
                "सामुदायिक सेवा का नया विकल्प (उपधारा 2 के परंतुक में)"
            ),
            bailableStatus = "गैर-जमानती (Non-Bailable)",
            cognizableStatus = "संज्ञेय (Cognizable)",
            trialCourt = "कोई भी मजिस्ट्रेट (प्रथम अनुसूची BNSS के अधीन)",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "The Bharatiya Nyaya Sanhita, 2023 (Pending line-by-line Gazette collation)",
            officialSourceUrl = null,
            sourcePublicationOrGazetteDate = null,
            lastVerifiedAt = null,
            verificationStatus = VerificationStatus.NEEDS_REVIEW,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.IPC,
                    targetSectionNumber = "378, 379",
                    targetHeading = "Theft and Punishment for theft under IPC",
                    relationshipType = CrossReferenceType.PARTIAL_OVERLAP,
                    applicabilityCaveat = "यदि घटना 1 जुलाई 2024 से पूर्व की है तो IPC 379 लागू होगी; 1 जुलाई 2024 या उसके बाद की घटना पर BNS 303 लागू होगी।",
                    statutoryAuthorityNote = "IPC 378/379 की विषयवस्तु को BNS धारा 303 में समाहित किया गया है।"
                )
            ),
            applicabilityNotes = "प्रविष्टि अभी समीक्षाधीन है; न्यायालय में आधिकारिक इंडिया कोड या भारत के राजपत्र की प्रति का ही उपयोग करें।"
        ),

        // BNS Section 351 (Criminal Intimidation) - NEEDS_REVIEW
        StructuredLegalRecord(
            recordId = "bns_sec_351",
            act = LegalAct.BNS,
            officialActTitle = "The Bharatiya Nyaya Sanhita, 2023",
            shortName = "BNS, 2023",
            actYear = 2023,
            sectionNumber = "351",
            officialHeading = "Criminal intimidation",
            officialHeadingHindi = "आपराधिक अभित्रास (धमकी देना)",
            officialTextOrApprovedSummary = "समीक्षाधीन सारांश: जो कोई किसी अन्य व्यक्ति को उसके शरीर, प्रतिष्ठा या संपत्ति को क्षति पहुंचाने की धमकी इस आशय से देता है कि उस व्यक्ति को संत्रास कारित किया जाए... उपधारा (2) व (3) में साधारण धमकी और गंभीर धमकी (जैसे मृत्यु या घोर उपहति) के लिए पृथक दंड के उपबंध हैं।",
            keyElements = listOf(
                "समीक्षाधीन विवरण: पूर्ण राजपत्रित मूल पाठ और उपधाराओं का मिलान प्रक्रियाधीन है",
                "शरीर, ख्याति या संपत्ति को क्षति पहुंचाने की धमकी",
                "संत्रास या विवश करने का आशय"
            ),
            bailableStatus = "जमानती / राज्य संशोधन अनुसार (Bailable / Subject to State amendments)",
            cognizableStatus = "गैर-संज्ञेय (Non-Cognizable)",
            trialCourt = "कोई भी मजिस्ट्रेट",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "The Bharatiya Nyaya Sanhita, 2023 (Pending line-by-line Gazette collation)",
            officialSourceUrl = null,
            sourcePublicationOrGazetteDate = null,
            lastVerifiedAt = null,
            verificationStatus = VerificationStatus.NEEDS_REVIEW,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.IPC,
                    targetSectionNumber = "503, 506",
                    targetHeading = "Criminal intimidation under IPC",
                    relationshipType = CrossReferenceType.PARTIAL_OVERLAP,
                    applicabilityCaveat = "30 जून 2024 तक की घटनाओं में IPC 506; 1 जुलाई 2024 से BNS 351 लागू।",
                    statutoryAuthorityNote = "IPC 503/506 के प्रावधानों का BNS 351 में प्रतिस्थापन।"
                )
            ),
            applicabilityNotes = "प्रविष्टि अभी समीक्षाधीन है; न्यायालयीन कार्यों हेतु केवल भारत के राजपत्र की आधिकारिक प्रति का ही उपयोग करें।"
        ),

        // BNS Section 103 (Murder) - NEEDS_REVIEW
        StructuredLegalRecord(
            recordId = "bns_sec_103",
            act = LegalAct.BNS,
            officialActTitle = "The Bharatiya Nyaya Sanhita, 2023",
            shortName = "BNS, 2023",
            actYear = 2023,
            sectionNumber = "103",
            officialHeading = "Punishment for murder",
            officialHeadingHindi = "हत्या के लिए दंड",
            officialTextOrApprovedSummary = "समीक्षाधीन सारांश: जो कोई हत्या करेगा वह मृत्यु या आजीवन कारावास से दंडित किया जाएगा और जुर्माने से भी दंडनीय होगा। उपधारा (2) में पाँच या अधिक व्यक्तियों के समूह द्वारा नस्ल, जाति, लिंग आदि के आधार पर हत्या (मॉब लिंचिंग) पर विशिष्ट दंड का प्रावधान है।",
            keyElements = listOf(
                "समीक्षाधीन: पूर्ण उपधाराओं का पाठ राजपत्र से सत्यापित किया जाना शेष है",
                "मृत्युदंड या आजीवन कारावास तथा जुर्माना",
                "मॉब लिंचिंग हेतु विशिष्ट उपधारा (2)"
            ),
            bailableStatus = "गैर-जमानती (Non-Bailable)",
            cognizableStatus = "संज्ञेय (Cognizable)",
            trialCourt = "सत्र न्यायालय (Court of Session)",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "The Bharatiya Nyaya Sanhita, 2023 (Pending primary gazette check)",
            officialSourceUrl = null,
            sourcePublicationOrGazetteDate = null,
            lastVerifiedAt = null,
            verificationStatus = VerificationStatus.NEEDS_REVIEW,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.IPC,
                    targetSectionNumber = "302",
                    targetHeading = "Punishment for murder under IPC",
                    relationshipType = CrossReferenceType.PARTIAL_OVERLAP,
                    applicabilityCaveat = "घटना की तिथि के अनुसार BNS 103 या IPC 302 का निर्धारण होगा।",
                    statutoryAuthorityNote = "IPC 302 के स्थान पर BNS धारा 103 प्रतिस्थापित।"
                )
            ),
            applicabilityNotes = "सत्र न्यायालय द्वारा विचारणीय गंभीर संज्ञेय अपराध।"
        ),

        // BNSS Section 173 (FIR) - NEEDS_REVIEW
        StructuredLegalRecord(
            recordId = "bnss_sec_173",
            act = LegalAct.BNSS,
            officialActTitle = "The Bharatiya Nagarik Suraksha Sanhita, 2023",
            shortName = "BNSS, 2023",
            actYear = 2023,
            sectionNumber = "173",
            officialHeading = "Information in cognizable cases",
            officialHeadingHindi = "संज्ञेय मामलों में सूचना (एफआईआर प्रक्रिया)",
            officialTextOrApprovedSummary = "समीक्षाधीन सारांश: संज्ञेय अपराध की सूचना थाने के भारसाधक अधिकारी को मौखिक या इलेक्ट्रॉनिक संचार द्वारा दी जा सकती है। इलेक्ट्रॉनिक सूचना (ई-एफआईआर) पर 3 दिन के भीतर हस्ताक्षर अनिवार्य हैं। नागरिक को एफआईआर की निःशुल्क प्रति तुरंत प्राप्त करने का अधिकार है। 3 से 7 वर्ष तक के दंड वाले अपराधों में 14 दिन की प्रारंभिक जांच (Preliminary Enquiry) का विकल्प भी उपलब्ध है।",
            keyElements = listOf(
                "ई-एफआईआर और ज़ीरो एफआईआर का वैधानिक समावेश",
                "निःशुल्क प्रति तुरंत देने का पुलिस का वैधानिक कर्तव्य",
                "प्रारंभिक जांच का नया प्रावधान"
            ),
            bailableStatus = "लागू नहीं (प्रक्रिया संहिता)",
            cognizableStatus = "संज्ञेय मामलों की प्रक्रिया",
            trialCourt = "क्षेत्राधिकार मजिस्ट्रेट",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "The Bharatiya Nagarik Suraksha Sanhita, 2023",
            officialSourceUrl = null,
            sourcePublicationOrGazetteDate = null,
            lastVerifiedAt = null,
            verificationStatus = VerificationStatus.NEEDS_REVIEW,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.CRPC,
                    targetSectionNumber = "154",
                    targetHeading = "Information in cognizable cases (FIR under CrPC 1973)",
                    relationshipType = CrossReferenceType.CORRESPONDING_PROVISION,
                    applicabilityCaveat = "1 जुलाई 2024 के बाद दर्ज होने वाली सभी एफआईआर पर BNSS 173 की प्रक्रिया लागू होती है।",
                    statutoryAuthorityNote = "CrPC धारा 154 का नया आधुनिक विस्तार।"
                )
            ),
            applicabilityNotes = "प्रक्रिया संहिता की धारा; पुलिस विवेचना और प्राथमिकी दर्ज करने का आधार।"
        ),

        // BSA Section 61 (Admissibility of electronic records) - NEEDS_REVIEW
        StructuredLegalRecord(
            recordId = "bsa_sec_61",
            act = LegalAct.BSA,
            officialActTitle = "The Bharatiya Sakshya Adhiniyam, 2023",
            shortName = "BSA, 2023",
            actYear = 2023,
            sectionNumber = "61",
            officialHeading = "Admissibility of electronic or digital records",
            officialHeadingHindi = "इलेक्ट्रॉनिक या डिजिटल अभिलेखों की ग्राह्यता",
            officialTextOrApprovedSummary = "समीक्षाधीन सारांश: इलेक्ट्रॉनिक या डिजिटल अभिलेखों को दस्तावेजी साक्ष्य के समकक्ष मान्यता दी गई है। किसी उपकरण में संग्रहीत या प्रेषित सूचना को मूल साक्ष्य के रूप में अदालत में प्रस्तुत किया जा सकता है, जो धारा 63 के प्रमाणपत्र नियमों के अधीन होगी।",
            keyElements = listOf(
                "डिजिटल साक्ष्य को दस्तावेजी साक्ष्य का समतुल्य दर्जा",
                "कॉल डिटेल, व्हाट्सएप चैट, ईमेल, सर्वर लॉग्स की ग्राह्यता",
                "प्रमाण पत्र संबंधी प्रक्रिया धारा 63 में विहित"
            ),
            bailableStatus = "लागू नहीं (साक्ष्य विधि)",
            cognizableStatus = "लागू नहीं",
            trialCourt = "समस्त न्यायालय",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            sourceTitle = "The Bharatiya Sakshya Adhiniyam, 2023",
            officialSourceUrl = null,
            sourcePublicationOrGazetteDate = null,
            lastVerifiedAt = null,
            verificationStatus = VerificationStatus.NEEDS_REVIEW,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.IEA,
                    targetSectionNumber = "65B",
                    targetHeading = "Admissibility of electronic records under IEA 1872",
                    relationshipType = CrossReferenceType.CORRESPONDING_PROVISION,
                    applicabilityCaveat = "पुराने मुकदमों में 65B प्रमाण पत्र; नई कार्यवाहियों में BSA धारा 61 व 63 लागू।",
                    statutoryAuthorityNote = "IEA 1872 की धारा 65B का नवीन सरलीकृत स्वरूप।"
                )
            ),
            applicabilityNotes = "न्यायालय में डिजिटल साक्ष्य प्रस्तुत करते समय तकनीकी प्रमाण पत्र आवश्यक है।"
        ),

        // =========================================================================
        // 3. HISTORIC LAWS (IPC, CrPC, IEA) - MARKED AS DEMO / HISTORIC
        // =========================================================================

        // IPC Section 379 - DEMO
        StructuredLegalRecord(
            recordId = "ipc_sec_379",
            act = LegalAct.IPC,
            officialActTitle = "The Indian Penal Code, 1860",
            shortName = "IPC, 1860",
            actYear = 1860,
            sectionNumber = "379",
            officialHeading = "Punishment for theft",
            officialHeadingHindi = "चोरी के लिए दंड (आईपीसी)",
            officialTextOrApprovedSummary = "नमूना/डेमो पाठ: जो कोई चोरी करेगा, वह दोनों में से किसी भांति के कारावास से, जिसकी अवधि तीन वर्ष तक की हो सकेगी, या जुर्माने से, या दोनों से, दंडित किया जाएगा।",
            keyElements = listOf(
                "3 वर्ष तक का कारावास अथवा जुर्माना या दोनों",
                "1 जुलाई 2024 से पूर्व घटित अपराधों के मामलों में लागू"
            ),
            bailableStatus = "गैर-जमानती (Non-Bailable)",
            cognizableStatus = "संज्ञेय (Cognizable)",
            trialCourt = "कोई भी मजिस्ट्रेट",
            commencementStatus = CommencementStatus.REPEALED_WITH_SAVINGS,
            effectiveFrom = "1862-01-01",
            effectiveTo = "2024-06-30",
            sourceTitle = "The Indian Penal Code, 1860 (Historical Record / Demo)",
            officialSourceUrl = null,
            sourcePublicationOrGazetteDate = "1860",
            lastVerifiedAt = null,
            verificationStatus = VerificationStatus.DEMO,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.BNS,
                    targetSectionNumber = "303",
                    targetHeading = "Theft under Bharatiya Nyaya Sanhita, 2023",
                    relationshipType = CrossReferenceType.PARTIAL_OVERLAP,
                    applicabilityCaveat = "30 जून 2024 तक की घटना में IPC 379; 1 जुलाई 2024 से BNS 303 लागू।",
                    statutoryAuthorityNote = "BNS 358(1) द्वारा निरसित किंतु धारा 358(2) व्यावृत्ति के तहत लंबित मामलों में प्रभावी।"
                )
            ),
            applicabilityNotes = "निरसित कानून; केवल 1 जुलाई 2024 से पूर्व के मामलों में लागू।"
        ),

        // IPC Section 420 - DEMO
        StructuredLegalRecord(
            recordId = "ipc_sec_420",
            act = LegalAct.IPC,
            officialActTitle = "The Indian Penal Code, 1860",
            shortName = "IPC, 1860",
            actYear = 1860,
            sectionNumber = "420",
            officialHeading = "Cheating and dishonestly inducing delivery of property",
            officialHeadingHindi = "छल करना और संपत्ति परिदत्त करने के लिए उत्प्रेरित करना (आईपीसी 420)",
            officialTextOrApprovedSummary = "नमूना/डेमो पाठ: जो कोई छल करेगा और तद्द्वारा उस व्यक्ति को जिसे धोखा दिया गया है, बेईमानी से उत्प्रेरित करेगा कि वह कोई संपत्ति किसी व्यक्ति को परिदत्त कर दे... वह सात वर्ष तक के कारावास और जुर्माने से दंडित किया जाएगा।",
            keyElements = listOf(
                "अधिकतम 7 वर्ष तक कारावास और जुर्माना",
                "धोखे से संपत्ति हस्तांतरित कराना"
            ),
            bailableStatus = "गैर-जमानती (Non-Bailable)",
            cognizableStatus = "संज्ञेय (Cognizable)",
            trialCourt = "मजिस्ट्रेट प्रथम वर्ग",
            commencementStatus = CommencementStatus.REPEALED_WITH_SAVINGS,
            effectiveFrom = "1862-01-01",
            effectiveTo = "2024-06-30",
            sourceTitle = "The Indian Penal Code, 1860 (Historical Record / Demo)",
            officialSourceUrl = null,
            sourcePublicationOrGazetteDate = "1860",
            lastVerifiedAt = null,
            verificationStatus = VerificationStatus.DEMO,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.BNS,
                    targetSectionNumber = "318(4)",
                    targetHeading = "Cheating and dishonestly inducing delivery of property under BNS",
                    relationshipType = CrossReferenceType.CORRESPONDING_PROVISION,
                    applicabilityCaveat = "1 जुलाई 2024 के बाद की घटना में BNS 318 लागू होगी।",
                    statutoryAuthorityNote = "BNS 358 के तहत निरसित।"
                )
            ),
            applicabilityNotes = "निरसित कानून; पूर्ववर्ती मामलों में प्रभावी।"
        )
    )

    private var activeStore: LocalLegalRecordStore? = null
    private val _importedRecordsState = MutableStateFlow<List<StructuredLegalRecord>>(emptyList())
    private val _allRecordsState = MutableStateFlow<List<StructuredLegalRecord>>(builtInRecords)

    /**
     * Observable StateFlow of all available legal records (built-in + locally imported).
     */
    val recordsFlow: StateFlow<List<StructuredLegalRecord>> = _allRecordsState.asStateFlow()

    /**
     * Dynamically computed combined list of legal records (built-in + locally imported).
     * Maintains 100% backward compatibility with existing callers of `OfficialLegalRepository.records`.
     */
    val records: List<StructuredLegalRecord>
        get() = _allRecordsState.value

    /**
     * Initializes the repository with an Android Context.
     */
    fun initialize(context: Context) {
        initialize(LocalLegalRecordStore(context))
    }

    /**
     * Initializes the repository with a specific [LocalLegalRecordStore].
     */
    fun initialize(store: LocalLegalRecordStore) {
        this.activeStore = store
        reloadFromStorage()
    }

    /**
     * Reloads locally stored imported records and merges them safely with built-in records.
     */
    fun reloadFromStorage() {
        val store = activeStore ?: return
        try {
            val loadedImported = store.loadImportedRecords()
            val filteredImported = loadedImported.filterNot { imp ->
                builtInRecords.any { builtIn -> builtIn.recordId == imp.recordId }
            }.distinctBy { it.recordId }

            _importedRecordsState.value = filteredImported
            _allRecordsState.value = builtInRecords + filteredImported
        } catch (e: Exception) {
            // Preservation Rule: If loading local storage fails or is corrupt, keep built-in records intact
            _importedRecordsState.value = emptyList()
            _allRecordsState.value = builtInRecords
            throw e
        }
    }

    /**
     * Safely validates and imports a JSON payload into the repository and local storage.
     *
     * CONFLICT & DUPLICATE POLICY:
     * 1. Built-in records can NEVER be overwritten by an import. If a record in the payload collides
     *    with a built-in record ID, the import fails (when allowOverwrite=false) or the built-in record
     *    is protected by default.
     * 2. Re-importing an identical imported record updates the local record without creating duplicates.
     * 3. Atomic Validation: Rejects malformed JSON, unknown enums, missing required fields, or unsupported versions.
     *
     * @param jsonString Raw JSON payload string.
     * @param allowOverwrite Whether existing imported records may be updated (default false).
     * @param storeOverride Optional LocalLegalRecordStore instance (used in tests or custom storage paths).
     */
    fun importJsonPayload(
        jsonString: String,
        allowOverwrite: Boolean = false,
        storeOverride: LocalLegalRecordStore? = null
    ): ImportResult {
        val targetStore = storeOverride ?: activeStore

        // 1. Existing record IDs across both built-in and imported records
        val existingIds = records.map { it.recordId }.toSet()

        // 2. Atomic Validation & Parsing
        val parseResult = LegalRecordImportAdapter.parseAndValidate(
            jsonString = jsonString,
            existingRecordIds = existingIds,
            allowOverwrite = allowOverwrite
        )

        if (parseResult is ImportResult.Failure) {
            return parseResult
        }

        val success = parseResult as ImportResult.Success
        val newRecords = success.importedRecords

        // 3. Built-in Protection Check
        val builtInCollision = newRecords.find { newRec ->
            builtInRecords.any { builtIn -> builtIn.recordId == newRec.recordId }
        }
        if (builtInCollision != null) {
            return ImportResult.Failure(
                listOf("रिकॉर्ड '${builtInCollision.recordId}' आधिकारिक built-in संग्रह का हिस्सा है और इसे ओवरराइट नहीं किया जा सकता।")
            )
        }

        // 4. Merge with existing imported records
        val currentImportedMap = _importedRecordsState.value.associateBy { it.recordId }.toMutableMap()
        for (record in newRecords) {
            currentImportedMap[record.recordId] = record
        }
        val updatedImportedList = currentImportedMap.values.toList()

        // 5. Atomic Storage Write
        if (targetStore != null) {
            try {
                targetStore.saveImportedRecords(updatedImportedList)
            } catch (e: Exception) {
                return ImportResult.Failure(
                    listOf("स्थानीय ऑन-डिवाइस फ़ाइल में सहेजने में विफलता: ${e.localizedMessage}"),
                    e
                )
            }
        }

        // 6. Update Observable Repository State
        _importedRecordsState.value = updatedImportedList
        _allRecordsState.value = builtInRecords + updatedImportedList

        return success
    }

    /**
     * Clears imported records from memory and local storage (resets to built-in records).
     */
    fun clearImportedRecords(storeOverride: LocalLegalRecordStore? = null): Boolean {
        val targetStore = storeOverride ?: activeStore
        val cleared = targetStore?.clearStorage() ?: true
        _importedRecordsState.value = emptyList()
        _allRecordsState.value = builtInRecords
        return cleared
    }

    /**
     * Returns the full list of all active legal records (built-in + imported).
     */
    fun getAllRecords(): List<StructuredLegalRecord> = records

    /**
     * Filters structured records safely by query, act, and verification status across all records.
     */
    fun searchRecords(
        query: String,
        actFilter: LegalAct? = null,
        verificationFilter: VerificationStatus? = null
    ): List<StructuredLegalRecord> {
        val cleanQuery = query.trim().lowercase()
        return records.filter { record ->
            val matchesAct = (actFilter == null || record.act == actFilter)
            val matchesVerification = (verificationFilter == null || record.verificationStatus == verificationFilter)
            val matchesQuery = if (cleanQuery.isEmpty()) {
                true
            } else {
                record.sectionNumber.lowercase().contains(cleanQuery) ||
                record.officialHeading.lowercase().contains(cleanQuery) ||
                record.officialHeadingHindi.lowercase().contains(cleanQuery) ||
                record.act.code.lowercase().contains(cleanQuery) ||
                record.officialTextOrApprovedSummary.lowercase().contains(cleanQuery) ||
                record.crossReferences.any { cross ->
                    cross.targetSectionNumber.lowercase().contains(cleanQuery) ||
                    cross.targetHeading.lowercase().contains(cleanQuery)
                }
            }
            matchesAct && matchesVerification && matchesQuery
        }
    }

    /**
     * Finds a record by ID across both built-in and imported records.
     */
    fun getRecordById(id: String): StructuredLegalRecord? {
        return records.firstOrNull { it.recordId == id }
    }
}
