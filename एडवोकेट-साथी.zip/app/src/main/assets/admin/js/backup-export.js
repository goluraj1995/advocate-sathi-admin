// Advocate Sathi - Backup, Restore & Android Compatibility Export
// 100% on-device file generation and restoration. Zero cloud involvement.

class AdvocateBackupExport {
  constructor(store) {
    this.store = store;
  }

  /**
   * Download full JSON backup containing all Acts, Sections, and Audit logs.
   */
  downloadFullBackup() {
    const backupData = this.store.exportFullBackup();
    const dateStr = new Date().toISOString().split('T')[0];
    const filename = `advocate_sathi_backup_${dateStr}.json`;
    this._downloadFile(JSON.stringify(backupData, null, 2), filename, 'application/json;charset=utf-8;');
    this.store.logAction('BACKUP_DOWNLOAD', `पूर्ण बैकअप डाउनलोड किया गया: ${filename}`);
  }

  /**
   * Restore backup from JSON file.
   * @param {File} file 
   * @returns {Promise<{ actsCount: number, sectionsCount: number }>}
   */
  async restoreBackupFromFile(file) {
    const text = await file.text();
    let parsed;
    try {
      parsed = JSON.parse(text);
    } catch (e) {
      throw new Error("चयनित फाइल वैध JSON नहीं है। कृपया सही बैकअप फाइल चुनें।");
    }

    return this.store.restoreBackup(parsed);
  }

  /**
   * Export records strictly matching Android's StructuredLegalRecord schema.
   * @param {boolean} onlyPublishedAndVerified 
   */
  exportForAndroid(onlyPublishedAndVerified = true) {
    let sections = this.store.getSections();

    if (onlyPublishedAndVerified) {
      sections = sections.filter(s => s.verificationStatus === 'VERIFIED' || s.verificationStatus === 'PUBLISHED');
    }

    // Map to exact Android Kotlin StructuredLegalRecord schema
    const exportRecords = sections.map(s => {
      // Build cross-references list
      const crossRefs = [];
      if (s.correspondingSection) {
        crossRefs.push({
          targetAct: s.correspondingSection.includes("IPC") ? "IPC" : (s.correspondingSection.includes("BNS") ? "BNS" : "CRPC"),
          targetSectionNumber: s.correspondingSection.replace(/[^0-9,\s\(\)]/g, '').trim(),
          targetHeading: s.correspondingSection,
          relationshipType: s.crossReferenceType || "CORRESPONDING_PROVISION",
          applicabilityCaveat: "धारा का लागू होना अपराध की घटना तिथि (1 जुलाई 2024 से पूर्व या पश्चात्), संक्रमणकालीन नियमों और विशिष्ट तथ्यों पर निर्भर करता है।",
          statutoryAuthorityNote: s.reviewNotes || "पूर्ववर्ती / परवर्ती दांडिक विधि संदर्भ।"
        });
      }

      return {
        recordId: s.recordId,
        act: s.actCode,
        officialActTitle: s.officialActTitle,
        shortName: s.shortName,
        actYear: s.actYear,
        sectionNumber: s.sectionNumber,
        officialHeading: s.officialHeading,
        officialHeadingHindi: s.officialHeadingHindi,
        officialTextOrApprovedSummary: s.officialTextOrApprovedSummary,
        keyElements: s.keyElements || [],
        bailableStatus: s.bailableStatus,
        cognizableStatus: s.cognizableStatus,
        trialCourt: s.trialCourt,
        commencementStatus: s.commencementStatus || "IN_FORCE",
        effectiveFrom: s.effectiveFrom,
        effectiveTo: s.effectiveTo,
        sourceTitle: s.sourceTitle,
        officialSourceUrl: s.officialSourceUrl,
        sourcePublicationOrGazetteDate: s.sourcePublicationOrGazetteDate,
        lastVerifiedAt: s.lastVerifiedAt,
        verificationStatus: s.verificationStatus,
        crossReferences: crossRefs,
        applicabilityNotes: s.applicabilityNotes || "1 जुलाई 2024 के आपराधिक संक्रमण नियम लागू होंगे।",
        proceduralCaveat: s.proceduralCaveat || "यह प्रविष्टि सामान्य विधिक जानकारी हेतु है; यह अदालत का निर्णय या अधिवक्ता की राय नहीं है।"
      };
    });

    const outputObj = {
      formatVersion: "1.0",
      targetApplication: "Advocate Sathi Android (एडवोकेट साथी)",
      exportTimestamp: new Date().toISOString(),
      totalRecords: exportRecords.length,
      filterApplied: onlyPublishedAndVerified ? "ONLY_VERIFIED_AND_PUBLISHED" : "ALL_RECORDS",
      records: exportRecords
    };

    const jsonStr = JSON.stringify(outputObj, null, 2);
    const filename = `official_legal_repository_export_${onlyPublishedAndVerified ? 'verified' : 'all'}.json`;
    this._downloadFile(jsonStr, filename, 'application/json;charset=utf-8;');
    
    this.store.logAction('ANDROID_EXPORT', `एंड्रॉइड निर्यात संपन्न: ${exportRecords.length} रिकॉर्ड (${filename})`);
    return outputObj;
  }

  /**
   * Export all sections in CSV format for spreadsheet inspection.
   */
  exportSectionsCsv() {
    const sections = this.store.getSections();
    const headers = [
      "recordId",
      "actCode",
      "sectionNumber",
      "officialHeadingHindi",
      "officialHeading",
      "verificationStatus",
      "bailableStatus",
      "cognizableStatus",
      "punishmentText",
      "simpleExplanationHindi",
      "officialTextOrApprovedSummary",
      "correspondingSection",
      "sourceTitle",
      "officialSourceUrl",
      "lastVerifiedAt"
    ];

    const escapeCsv = (val) => {
      if (val === null || val === undefined) return '""';
      const str = String(val).replace(/"/g, '""');
      return `"${str}"`;
    };

    let csv = headers.join(",") + "\n";
    sections.forEach(s => {
      const row = headers.map(h => escapeCsv(s[h] || ""));
      csv += row.join(",") + "\n";
    });

    const filename = `advocate_sathi_sections_${new Date().toISOString().split('T')[0]}.csv`;
    this._downloadFile(csv, filename, 'text/csv;charset=utf-8;');
    this.store.logAction('CSV_EXPORT', `धाराएं CSV में निर्यात की गईं: ${sections.length} पंक्तियां`);
  }

  _downloadFile(content, filename, mimeType) {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }
}

window.advocateBackupExport = new AdvocateBackupExport(window.advocateStore);
