package com.example

import android.app.Application
import android.net.Uri
import com.example.data.OfficialLegalRepository
import com.example.data.store.LocalLegalRecordStore
import com.example.model.CommencementStatus
import com.example.model.VerificationStatus
import com.example.viewmodel.AdvocateViewModel
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SafeJsonImportUiTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private lateinit var app: Application
    private lateinit var viewModel: AdvocateViewModel
    private lateinit var testStorageFile: File
    private lateinit var testStore: LocalLegalRecordStore

    private val validImportJson = """
    {
      "formatVersion": "1.0",
      "targetApplication": "Advocate Sathi Android (एडवोकेट साथी)",
      "exportTimestamp": "2026-10-27T19:00:00.000Z",
      "totalRecords": 2,
      "filterApplied": "ALL",
      "records": [
        {
          "recordId": "bns_sec_316",
          "act": "BNS",
          "officialActTitle": "The Bharatiya Nyaya Sanhita, 2023",
          "shortName": "BNS, 2023",
          "actYear": 2023,
          "sectionNumber": "316",
          "officialHeading": "Criminal breach of trust",
          "officialHeadingHindi": "आपराधिक न्यासभंग (Criminal breach of trust)",
          "officialTextOrApprovedSummary": "जो कोई संपत्ति के न्यास का उल्लंघन करता है...",
          "keyElements": ["न्यासभंग की नई धारा"],
          "bailableStatus": "गैर-जमानती",
          "cognizableStatus": "संज्ञेय",
          "trialCourt": "मजिस्ट्रेट प्रथम वर्ग",
          "commencementStatus": "IN_FORCE",
          "effectiveFrom": "2024-07-01",
          "effectiveTo": null,
          "sourceTitle": "Gazette of India Act No. 45 of 2023",
          "officialSourceUrl": "https://www.indiacode.nic.in",
          "sourcePublicationOrGazetteDate": "2023-12-25",
          "lastVerifiedAt": "2024-10-27",
          "verificationStatus": "NEEDS_REVIEW",
          "crossReferences": [],
          "applicabilityNotes": "IPC 406 का नया स्थान",
          "proceduralCaveat": "विधिक जानकारी"
        },
        {
          "recordId": "bns_sec_319",
          "act": "BNS",
          "officialActTitle": "The Bharatiya Nyaya Sanhita, 2023",
          "shortName": "BNS, 2023",
          "actYear": 2023,
          "sectionNumber": "319",
          "officialHeading": "Cheating by personation",
          "officialHeadingHindi": "प्रतिरूपण द्वारा छल",
          "officialTextOrApprovedSummary": "जो कोई किसी अन्य का रूप धारण कर छल करता है...",
          "keyElements": ["छल प्रतिरूपण"],
          "bailableStatus": "जमानती",
          "cognizableStatus": "संज्ञेय",
          "trialCourt": "कोई भी मजिस्ट्रेट",
          "commencementStatus": "PENDING_NOTIFICATION",
          "effectiveFrom": null,
          "effectiveTo": null,
          "sourceTitle": "Gazette of India Act No. 45 of 2023",
          "officialSourceUrl": null,
          "sourcePublicationOrGazetteDate": "2023-12-25",
          "lastVerifiedAt": null,
          "verificationStatus": "DRAFT",
          "crossReferences": [],
          "applicabilityNotes": "IPC 419 का नया स्थान",
          "proceduralCaveat": "विधिक जानकारी"
        }
      ]
    }
    """.trimIndent()

    @Before
    fun setUp() {
        app = RuntimeEnvironment.getApplication()
        testStorageFile = File(tempFolder.root, "ui_test_imported_records.json")
        testStore = LocalLegalRecordStore(testStorageFile)

        OfficialLegalRepository.clearImportedRecords(testStore)
        OfficialLegalRepository.initialize(testStore)

        viewModel = AdvocateViewModel(app)
    }

    @After
    fun tearDown() {
        OfficialLegalRepository.clearImportedRecords(testStore)
    }

    private fun createJsonFileUri(jsonContent: String, fileName: String = "test_import.json"): Uri {
        val file = File(tempFolder.root, fileName)
        file.writeText(jsonContent, Charsets.UTF_8)
        return Uri.fromFile(file)
    }

    @Test
    fun `test 1 - file picker cancellation leaves UI state unchanged`() {
        viewModel.processImportFile(null)
        val state = viewModel.uiState.value
        assertEquals(false, state.isImportProcessing)
        assertNull(state.importPreviewData)
        assertNull(state.importErrorMessage)
    }

    @Test
    fun `test 2 - valid JSON preview parses counts and shows preview data`() {
        val uri = createJsonFileUri(validImportJson)
        viewModel.processImportFile(uri)

        // Allow async coroutine to execute
        Thread.sleep(300)

        val state = viewModel.uiState.value
        val preview = state.importPreviewData
        assertNotNull(preview)
        assertEquals(2, preview?.totalRecords)
        assertEquals(1, preview?.needsReviewCount)
        assertEquals(1, preview?.draftCount)
        assertEquals(0, preview?.verifiedCount)
        assertEquals(2, preview?.newRecordCount)
    }

    @Test
    fun `test 3 - invalid and empty JSON shows failure without modifying repository`() {
        val countBefore = OfficialLegalRepository.records.size

        val emptyUri = createJsonFileUri("  ", "empty.json")
        viewModel.processImportFile(emptyUri)
        Thread.sleep(300)

        val state = viewModel.uiState.value
        assertNull(state.importPreviewData)
        assertNotNull(state.importErrorMessage)
        assertEquals(countBefore, OfficialLegalRepository.records.size)
    }

    @Test
    fun `test 4 - unsupported format version or target application fails validation`() {
        val wrongVersionJson = validImportJson.replace("\"formatVersion\": \"1.0\"", "\"formatVersion\": \"9.9\"")
        val uri = createJsonFileUri(wrongVersionJson)

        viewModel.processImportFile(uri)
        Thread.sleep(300)

        val state = viewModel.uiState.value
        assertNull(state.importPreviewData)
        assertNotNull(state.importErrorMessage)
        assertTrue(state.importErrorMessage?.contains("formatVersion") == true)
    }

    @Test
    fun `test 5 - built-in record ID conflict is reported in preview`() {
        val conflictJson = validImportJson.replace("\"recordId\": \"bns_sec_316\"", "\"recordId\": \"bns_sec_1\"")
        val uri = createJsonFileUri(conflictJson)

        viewModel.processImportFile(uri)
        Thread.sleep(300)

        val state = viewModel.uiState.value
        val preview = state.importPreviewData
        assertNotNull(preview)
        assertEquals(1, preview?.builtInConflictCount)
    }

    @Test
    fun `test 6 - duplicate records within payload trigger failure`() {
        val dupJson = validImportJson.replace("\"recordId\": \"bns_sec_319\"", "\"recordId\": \"bns_sec_316\"")
        val uri = createJsonFileUri(dupJson)

        viewModel.processImportFile(uri)
        Thread.sleep(300)

        val state = viewModel.uiState.value
        assertNull(state.importPreviewData)
        assertNotNull(state.importErrorMessage)
        assertTrue(state.importErrorMessage?.contains("डुप्लीकेट recordId") == true)
    }

    @Test
    fun `test 7 - existing imported record update behavior`() {
        // Initial import
        val uri1 = createJsonFileUri(validImportJson)
        viewModel.processImportFile(uri1)
        Thread.sleep(300)
        viewModel.confirmImport()
        Thread.sleep(300)

        // Process updated JSON with new heading for bns_sec_316
        val updatedJson = validImportJson.replace("Criminal breach of trust", "Criminal breach of trust (Updated)")
        val uri2 = createJsonFileUri(updatedJson, "updated_import.json")
        viewModel.processImportFile(uri2)
        Thread.sleep(300)

        val state = viewModel.uiState.value
        val preview = state.importPreviewData
        assertNotNull(preview)
        assertEquals(2, preview?.existingUpdateCount)

        viewModel.confirmImport()
        Thread.sleep(300)

        val updatedRecord = OfficialLegalRepository.getRecordById("bns_sec_316")
        assertEquals("Criminal breach of trust (Updated)", updatedRecord?.officialHeading)
    }

    @Test
    fun `test 8 - user cancellation at confirmation dialog leaves repository unchanged`() {
        val countBefore = OfficialLegalRepository.records.size

        val uri = createJsonFileUri(validImportJson)
        viewModel.processImportFile(uri)
        Thread.sleep(300)

        assertNotNull(viewModel.uiState.value.importPreviewData)
        viewModel.cancelImportPreview()

        val stateAfterCancel = viewModel.uiState.value
        assertNull(stateAfterCancel.importPreviewData)
        assertEquals(countBefore, OfficialLegalRepository.records.size)
        assertNull(OfficialLegalRepository.getRecordById("bns_sec_316"))
    }

    @Test
    fun `test 9 - successful import persists after repository reinitialization`() {
        val uri = createJsonFileUri(validImportJson)
        viewModel.processImportFile(uri)
        Thread.sleep(300)
        viewModel.confirmImport()
        Thread.sleep(300)

        assertNotNull(viewModel.uiState.value.importSuccessMessage)

        // Simulate app restart / reinitialization
        val newStore = LocalLegalRecordStore(testStorageFile)
        OfficialLegalRepository.initialize(newStore)

        assertNotNull(OfficialLegalRepository.getRecordById("bns_sec_316"))
    }

    @Test
    fun `test 10 - failed save does not partially update repository state`() {
        val countBefore = OfficialLegalRepository.records.size

        val corruptUri = createJsonFileUri("{ invalid json content ...")
        viewModel.processImportFile(corruptUri)
        Thread.sleep(300)

        assertEquals(countBefore, OfficialLegalRepository.records.size)
        assertNull(viewModel.uiState.value.importPreviewData)
    }

    @Test
    fun `test 11 - search can find a successfully imported record`() {
        val uri = createJsonFileUri(validImportJson)
        viewModel.processImportFile(uri)
        Thread.sleep(300)
        viewModel.confirmImport()
        Thread.sleep(300)

        val searchResult = OfficialLegalRepository.searchRecords("न्यासभंग")
        assertEquals(1, searchResult.size)
        assertEquals("bns_sec_316", searchResult[0].recordId)
    }

    @Test
    fun `test 12 - verification and commencement statuses are never silently promoted`() {
        val uri = createJsonFileUri(validImportJson)
        viewModel.processImportFile(uri)
        Thread.sleep(300)
        viewModel.confirmImport()
        Thread.sleep(300)

        val rec316 = OfficialLegalRepository.getRecordById("bns_sec_316")
        val rec319 = OfficialLegalRepository.getRecordById("bns_sec_319")

        assertNotNull(rec316)
        assertNotNull(rec319)

        // Statuses must match original JSON without silent promotion to VERIFIED or IN_FORCE
        assertEquals(VerificationStatus.NEEDS_REVIEW, rec316?.verificationStatus)
        assertEquals(VerificationStatus.DRAFT, rec319?.verificationStatus)
        assertEquals(CommencementStatus.PENDING_NOTIFICATION, rec319?.commencementStatus)
    }

    @Test
    fun `test 13 - repeated taps do not trigger duplicate concurrent imports`() {
        val uri = createJsonFileUri(validImportJson)

        // First call starts processing
        viewModel.processImportFile(uri)

        // Immediate second call should be guarded if processing
        val initialPreview = viewModel.uiState.value.importPreviewData
        viewModel.processImportFile(uri)

        // State remains guarded
        assertEquals(initialPreview, viewModel.uiState.value.importPreviewData)
    }
}
