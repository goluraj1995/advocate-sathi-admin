package com.example

import com.example.data.importer.ImportResult
import com.example.data.importer.LegalRecordImportAdapter
import com.example.model.CommencementStatus
import com.example.model.CrossReferenceType
import com.example.model.LegalAct
import com.example.model.VerificationStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config


@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LegalRecordImportAdapterTest {

    private val validTwoRecordsJson = """
    {
      "formatVersion": "1.0",
      "targetApplication": "Advocate Sathi Android (एडवोकेट साथी)",
      "exportTimestamp": "2026-10-27T17:00:00.000Z",
      "totalRecords": 2,
      "filterApplied": "ONLY_VERIFIED_AND_PUBLISHED",
      "records": [
        {
          "recordId": "bns_sec_1",
          "act": "BNS",
          "officialActTitle": "The Bharatiya Nyaya Sanhita, 2023",
          "shortName": "BNS, 2023",
          "actYear": 2023,
          "sectionNumber": "1",
          "officialHeading": "Short title, commencement and application",
          "officialHeadingHindi": "संक्षिप्त नाम, प्रारंभ और लागू होना",
          "officialTextOrApprovedSummary": "यह अधिनियम भारतीय न्याय संहिता, 2023 कहलाएगा।",
          "keyElements": ["लागू तिथि: 1 जुलाई 2024"],
          "bailableStatus": null,
          "cognizableStatus": null,
          "trialCourt": null,
          "commencementStatus": "IN_FORCE",
          "effectiveFrom": "2024-07-01",
          "effectiveTo": null,
          "sourceTitle": "Gazette of India Act No. 45 of 2023",
          "officialSourceUrl": "https://www.indiacode.nic.in/handle/123456789/21734",
          "sourcePublicationOrGazetteDate": "2023-12-25",
          "lastVerifiedAt": "2024-10-27",
          "verificationStatus": "VERIFIED",
          "crossReferences": [
            {
              "targetAct": "IPC",
              "targetSectionNumber": "1, 2, 3, 4",
              "targetHeading": "Title and extent of operation",
              "relationshipType": "CORRESPONDING_PROVISION",
              "applicabilityCaveat": "संक्रमणकालीन नियम लागू होंगे।",
              "statutoryAuthorityNote": "IPC का समेकन"
            }
          ],
          "applicabilityNotes": "1 जुलाई 2024 से लागू",
          "proceduralCaveat": "विधिक सलाह नहीं है।"
        },
        {
          "recordId": "bns_sec_358",
          "act": "BNS",
          "officialActTitle": "The Bharatiya Nyaya Sanhita, 2023",
          "shortName": "BNS, 2023",
          "actYear": 2023,
          "sectionNumber": "358",
          "officialHeading": "Repeal and savings",
          "officialHeadingHindi": "निरसन और व्यावृत्तियां",
          "officialTextOrApprovedSummary": "भारतीय दंड संहिता, 1860 इसके द्वारा निरसित की जाती है।",
          "keyElements": ["IPC 1860 निरसित"],
          "bailableStatus": "लागू नहीं",
          "cognizableStatus": "लागू नहीं",
          "trialCourt": "लागू नहीं",
          "commencementStatus": "IN_FORCE",
          "effectiveFrom": "2024-07-01",
          "effectiveTo": null,
          "sourceTitle": "The Bharatiya Nyaya Sanhita, 2023, Section 358",
          "officialSourceUrl": "https://www.indiacode.nic.in/handle/123456789/21734",
          "sourcePublicationOrGazetteDate": "2023-12-25",
          "lastVerifiedAt": "2024-10-27",
          "verificationStatus": "VERIFIED",
          "crossReferences": [],
          "applicabilityNotes": "व्यावृत्ति खंड",
          "proceduralCaveat": "विधिक सलाह नहीं है।"
        }
      ]
    }
    """.trimIndent()

    @Test
    fun `test valid envelope parses two VERIFIED records successfully`() {
        val result = LegalRecordImportAdapter.parseAndValidate(validTwoRecordsJson)
        assertTrue(result is ImportResult.Success)

        val success = result as ImportResult.Success
        assertEquals(2, success.importedRecords.size)
        assertEquals(2, success.verifiedCount)
        assertEquals(0, success.needsReviewCount)
        assertEquals(0, success.draftCount)

        val first = success.importedRecords[0]
        assertEquals("bns_sec_1", first.recordId)
        assertEquals(LegalAct.BNS, first.act)
        assertEquals("1", first.sectionNumber)
        assertEquals(CommencementStatus.IN_FORCE, first.commencementStatus)
        assertEquals(VerificationStatus.VERIFIED, first.verificationStatus)
        assertNull(first.bailableStatus)
        assertNull(first.effectiveTo)
        assertEquals(1, first.crossReferences.size)
        assertEquals(LegalAct.IPC, first.crossReferences[0].targetAct)
        assertEquals(CrossReferenceType.CORRESPONDING_PROVISION, first.crossReferences[0].relationshipType)
    }

    @Test
    fun `test totalRecords mismatch is rejected safely`() {
        // totalRecords is declared as 5, but records array only has 2
        val mismatchJson = validTwoRecordsJson.replace("\"totalRecords\": 2", "\"totalRecords\": 5")
        val result = LegalRecordImportAdapter.parseAndValidate(mismatchJson)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("totalRecords") })
    }

    @Test
    fun `test malformed JSON is rejected with clear error`() {
        val malformed = "{ \"formatVersion\": \"1.0\", \"records\": [ { incomplete... "
        val result = LegalRecordImportAdapter.parseAndValidate(malformed)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("Malformed JSON") || it.contains("अमान्य JSON") })
    }

    @Test
    fun `test unknown commencementStatus is NEVER defaulted to IN_FORCE and is rejected`() {
        val unknownCommencementJson = validTwoRecordsJson.replace(
            "\"commencementStatus\": \"IN_FORCE\"",
            "\"commencementStatus\": \"UNNOTIFIED_FUTURE_STATUS\""
        )
        val result = LegalRecordImportAdapter.parseAndValidate(unknownCommencementJson)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("commencementStatus") && it.contains("UNNOTIFIED_FUTURE_STATUS") })
    }

    @Test
    fun `test unknown verificationStatus is NEVER defaulted to VERIFIED or PUBLISHED`() {
        val unknownVerificationJson = validTwoRecordsJson.replace(
            "\"verificationStatus\": \"VERIFIED\"",
            "\"verificationStatus\": \"SEMI_VERIFIED_UNCONFIRMED\""
        )
        val result = LegalRecordImportAdapter.parseAndValidate(unknownVerificationJson)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("verificationStatus") && it.contains("SEMI_VERIFIED_UNCONFIRMED") })
    }

    @Test
    fun `test missing required field is rejected`() {
        // SectionNumber missing or empty
        val missingSecNumJson = validTwoRecordsJson.replace("\"sectionNumber\": \"1\"", "\"sectionNumber\": \"\"")
        val result = LegalRecordImportAdapter.parseAndValidate(missingSecNumJson)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("sectionNumber") })
    }

    @Test
    fun `test missing statutory text is rejected`() {
        val missingTextJson = validTwoRecordsJson.replace(
            "\"officialTextOrApprovedSummary\": \"यह अधिनियम भारतीय न्याय संहिता, 2023 कहलाएगा।\"",
            "\"officialTextOrApprovedSummary\": \"\""
        )
        val result = LegalRecordImportAdapter.parseAndValidate(missingTextJson)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("officialTextOrApprovedSummary") })
    }

    @Test
    fun `test duplicate recordId in payload triggers atomic rejection`() {
        // Duplicate recordId in payload: second record also uses "bns_sec_1"
        val duplicateIdJson = validTwoRecordsJson.replace("\"recordId\": \"bns_sec_358\"", "\"recordId\": \"bns_sec_1\"")
        val result = LegalRecordImportAdapter.parseAndValidate(duplicateIdJson)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("डुप्लीकेट recordId") })
    }

    @Test
    fun `test existing database recordId without allowOverwrite triggers rejection`() {
        val existingIds = setOf("bns_sec_1")
        val result = LegalRecordImportAdapter.parseAndValidate(validTwoRecordsJson, existingRecordIds = existingIds, allowOverwrite = false)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("डेटाबेस में पहले से मौजूद") })
    }

    @Test
    fun `test DRAFT and NEEDS_REVIEW records preserve their exact status`() {
        val draftAndReviewJson = validTwoRecordsJson
            .replaceFirst("\"verificationStatus\": \"VERIFIED\"", "\"verificationStatus\": \"NEEDS_REVIEW\"")
            .replaceFirst("\"verificationStatus\": \"VERIFIED\"", "\"verificationStatus\": \"DRAFT\"")

        val result = LegalRecordImportAdapter.parseAndValidate(draftAndReviewJson)
        assertTrue(result is ImportResult.Success)

        val success = result as ImportResult.Success
        assertEquals(0, success.verifiedCount)
        assertEquals(1, success.needsReviewCount)
        assertEquals(1, success.draftCount)
        assertEquals(VerificationStatus.NEEDS_REVIEW, success.importedRecords[0].verificationStatus)
        assertEquals(VerificationStatus.DRAFT, success.importedRecords[1].verificationStatus)
    }

    @Test
    fun `test unsupported formatVersion is safely rejected`() {
        val unsupportedVersion = validTwoRecordsJson.replace("\"formatVersion\": \"1.0\"", "\"formatVersion\": \"2.5\"")
        val result = LegalRecordImportAdapter.parseAndValidate(unsupportedVersion)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("formatVersion") && it.contains("2.5") })
    }

    @Test
    fun `test empty or blank JSON is safely rejected`() {
        val result = LegalRecordImportAdapter.parseAndValidate("   ")
        assertTrue(result is ImportResult.Failure)
    }
}
