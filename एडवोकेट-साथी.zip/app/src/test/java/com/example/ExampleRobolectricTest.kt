package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.OfficialLegalRepository
import com.example.model.CommencementStatus
import com.example.model.LegalAct
import com.example.model.VerificationStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("एडवोकेट साथी", appName)
  }

  @Test
  fun `verify legal repository search returns bns 303`() {
    val results = com.example.data.DemoLegalRepository.searchSections("303", null)
    assertTrue(results.isNotEmpty())
    assertEquals("धारा 303 (चोरी)", results.first().sectionNumber)
  }

  @Test
  fun `verify navigation state backstack handling`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)
    assertEquals(com.example.ui.navigation.AppScreen.Home, viewModel.uiState.value.currentScreen)
    viewModel.navigateTo(com.example.ui.navigation.AppScreen.ImportFir)
    assertEquals(com.example.ui.navigation.AppScreen.ImportFir, viewModel.uiState.value.currentScreen)
    val backHandled = viewModel.navigateBack()
    assertTrue(backHandled)
    assertEquals(com.example.ui.navigation.AppScreen.Home, viewModel.uiState.value.currentScreen)
  }

  @Test
  fun `verify picker cancellation and message state`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)
    viewModel.setDocumentPickerMessage("कोई पीडीएफ फ़ाइल चयनित नहीं की गई (चयन रद्द किया गया)।")
    assertEquals("कोई पीडीएफ फ़ाइल चयनित नहीं की गई (चयन रद्द किया गया)।", viewModel.uiState.value.documentPickerMessage)
    assertNull(viewModel.uiState.value.selectedDocument)
  }

  @Test
  fun `verify manual text entry and sample insertion`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)
    viewModel.insertSampleFirText()
    assertTrue(viewModel.uiState.value.firText.contains("प्राथमिकी सूचना रिपोर्ट"))
    assertEquals(com.example.ocr.ExtractionMethod.MANUAL_ENTRY, viewModel.uiState.value.extractionMethod)

    viewModel.clearFirText()
    assertTrue(viewModel.uiState.value.firText.isEmpty())
  }

  @Test
  fun `verify empty document ocr guard`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)
    viewModel.startOcrProcessing()
    assertFalse(viewModel.uiState.value.isOcrRunning)
    assertEquals("कोई वैध फ़ाइल चयनित नहीं है।", viewModel.uiState.value.ocrErrorNotice)
    assertNotNull(viewModel.uiState.value.ocrRecoveryHelp)
  }

  @Test
  fun `verify bottom navigation items are non null and have valid routes`() {
    val items = com.example.ui.navigation.AppScreen.bottomNavItems
    assertEquals(5, items.size)
    items.forEach { screen ->
      assertNotNull("Bottom nav screen must not be null", screen)
      assertTrue("Route must not be empty", screen.route.isNotEmpty())
      assertTrue("Title must not be empty", screen.titleHindi.isNotEmpty())
      assertNotNull(screen.selectedIcon)
      assertNotNull(screen.unselectedIcon)
    }
  }

  @Test
  fun `verify navigation across all five bottom tabs`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)

    val items = com.example.ui.navigation.AppScreen.bottomNavItems
    items.forEach { screen ->
      viewModel.navigateTo(screen)
      assertEquals(screen, viewModel.uiState.value.currentScreen)
    }
  }

  @Test
  fun `verify ocr cancellation clears running state`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)
    viewModel.onDocumentSelected(
      fileName = "fir_sample.jpg",
      sizeFormatted = "500 KB",
      type = com.example.model.DocumentType.IMAGE,
      uriString = "content://com.example.provider/dummy.jpg"
    )
    viewModel.startOcrProcessing()
    assertTrue(viewModel.uiState.value.isOcrRunning)

    viewModel.cancelOcr()
    assertFalse(viewModel.uiState.value.isOcrRunning)
    assertNull(viewModel.uiState.value.ocrProgress)
  }

  // =========================================================================
  // Milestone 3 Tests: Legal Information Repository, Verification & Sources
  // =========================================================================

  @Test
  fun `verify verified legal records have authentic sources and URLs`() {
    val verifiedRecords = OfficialLegalRepository.searchRecords("", null, VerificationStatus.VERIFIED)
    assertTrue("At least 5 verified primary records must exist", verifiedRecords.size >= 5)

    verifiedRecords.forEach { record ->
      assertEquals(VerificationStatus.VERIFIED, record.verificationStatus)
      assertTrue("isOfficiallyVerified must be true for VERIFIED records", record.verificationStatus.isOfficiallyVerified)
      assertNotNull("Verified record must cite official source", record.sourceTitle)
      assertTrue("Verified record source URL must point to official portal", record.officialSourceUrl?.startsWith("https://") == true)
      assertEquals("Verified record must have commencement status IN_FORCE", CommencementStatus.IN_FORCE, record.commencementStatus)
      assertEquals("Verified record effective date must be 2024-07-01", "2024-07-01", record.effectiveFrom)
    }
  }

  @Test
  fun `verify unverified or review needed records are strictly not marked verified`() {
    val reviewRecords = OfficialLegalRepository.searchRecords("", null, VerificationStatus.NEEDS_REVIEW)
    assertTrue("Review-needed records must exist", reviewRecords.isNotEmpty())

    reviewRecords.forEach { record ->
      assertFalse("NEEDS_REVIEW record must not be marked officially verified", record.verificationStatus.isOfficiallyVerified)
      assertNull("Official source URL must not be fabricated when unverified", record.officialSourceUrl)
      assertTrue("Heading or summary must indicate review status", record.officialTextOrApprovedSummary.contains("समीक्षाधीन"))
    }
  }

  @Test
  fun `verify verification status filtering gates records accurately`() {
    val verifiedOnly = OfficialLegalRepository.searchRecords("", null, VerificationStatus.VERIFIED)
    assertTrue(verifiedOnly.all { it.verificationStatus == VerificationStatus.VERIFIED })

    val reviewOnly = OfficialLegalRepository.searchRecords("", null, VerificationStatus.NEEDS_REVIEW)
    assertTrue(reviewOnly.all { it.verificationStatus == VerificationStatus.NEEDS_REVIEW })

    val demoOnly = OfficialLegalRepository.searchRecords("", null, VerificationStatus.DEMO)
    assertTrue(demoOnly.all { it.verificationStatus == VerificationStatus.DEMO })
  }

  @Test
  fun `verify cross references include date dependent transitional caveats`() {
    val bns358 = OfficialLegalRepository.getRecordById("bns_sec_358")
    assertNotNull(bns358)
    assertEquals(LegalAct.BNS, bns358?.act)
    assertEquals("358", bns358?.sectionNumber)

    val crossRefs = bns358!!.crossReferences
    assertTrue(crossRefs.isNotEmpty())
    val ref = crossRefs.first()
    assertEquals(LegalAct.IPC, ref.targetAct)
    assertTrue("Cross reference must contain incident date caveat", ref.applicabilityCaveat.contains("1 जुलाई 2024"))
  }

  @Test
  fun `verify structured record selection and back navigation in viewModel`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)

    val record = OfficialLegalRepository.getRecordById("bns_sec_1")
    assertNotNull(record)

    viewModel.selectStructuredRecord(record)
    assertEquals(record, viewModel.uiState.value.selectedStructuredRecord)

    val handled = viewModel.navigateBack()
    assertTrue("Back navigation should handle dismissing structured record dialog", handled)
    assertNull(viewModel.uiState.value.selectedStructuredRecord)
  }

  // =========================================================================
  // Milestone 4 Tests: Genuine On-Device PDF Reports & Devanagari Rendering
  // =========================================================================

  @Test
  fun `verify genuine pdf generation produces valid pdf binary with signature`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val generator = com.example.pdf.LocalPdfReportGenerator(context)
    val outputStream = java.io.ByteArrayOutputStream()

    val testData = com.example.pdf.PdfReportData(
      reportTitle = "दस्तावेज़ समीक्षा रिपोर्ट",
      appName = "एडवोकेट साथी",
      documentName = "fir_case_102.pdf",
      documentTypeLabel = "पीडीएफ दस्तावेज़ (PDF)",
      extractionMethodLabel = "डिजिटल पाठ निष्कर्षण",
      pagesProcessed = 1,
      firText = "प्राथमिकी विवरण: चोरी का संज्ञेय अपराध (BNS 303)।",
      includeFirText = true,
      linkedSections = listOfNotNull(OfficialLegalRepository.getRecordById("bns_sec_303")),
      isDemoData = false
    )

    val result = generator.generateToStream(testData, outputStream)
    assertTrue("PDF generation failed: ${result.errorMessage}", result.success)
    assertTrue("PDF must contain at least 1 page", result.pageCount >= 1)
    assertTrue("PDF total bytes must be non-zero", result.totalBytes > 500L)

    val bytes = outputStream.toByteArray()
    assertTrue("Byte array must not be empty", bytes.isNotEmpty())

    // Standard PDF header signature check: '%PDF-'
    val headerString = String(bytes.take(5).toByteArray())
    assertEquals("%PDF-", headerString)
  }

  @Test
  fun `verify multi page pagination for lengthy fir text`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val generator = com.example.pdf.LocalPdfReportGenerator(context)
    val outputStream = java.io.ByteArrayOutputStream()

    // Build long multi-paragraph Hindi text to test pagination overflow
    val longFirTextBuilder = StringBuilder()
    for (i in 1..25) {
      longFirTextBuilder.append("अनुच्छेद $i: दिनांक 15 अगस्त 2024 को शाम 07:30 बजे सिविल लाइन्स क्षेत्र में दो व्यक्तियों द्वारा मारपीट एवं लूटपाट की घटना घटित हुई। परिवादी के अनुसार आरोपी द्वारा घातक हथियार से हमला किया गया और मोबाइल छीन लिया गया।\n\n")
    }

    val testData = com.example.pdf.PdfReportData(
      reportTitle = "दस्तावेज़ समीक्षा रिपोर्ट",
      appName = "एडवोकेट साथी",
      documentName = "extensive_fir_scan.pdf",
      firText = longFirTextBuilder.toString(),
      includeFirText = true,
      linkedSections = listOfNotNull(
        OfficialLegalRepository.getRecordById("bns_sec_303"),
        OfficialLegalRepository.getRecordById("bns_sec_351"),
        OfficialLegalRepository.getRecordById("bnss_sec_173")
      )
    )

    val result = generator.generateToStream(testData, outputStream)
    assertTrue("PDF generation must succeed for long text", result.success)
    assertTrue("Extensive FIR text must span more than 1 page", result.pageCount > 1)
    assertTrue("Total bytes must reflect multi-page content", result.totalBytes > 1000L)
  }

  @Test
  fun `verify devanagari hindi typography and special characters render cleanly`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val generator = com.example.pdf.LocalPdfReportGenerator(context)
    val outputStream = java.io.ByteArrayOutputStream()

    val devanagariRichText = "भारतीय न्याय संहिता, 2023 (बीएनएस) एवं भारतीय नागरिक सुरक्षा संहिता (बीएनएसएस)। " +
        "विधिक अधिकार: निःशुल्क प्राथमिकी प्रति (धारा 173(2)) एवं ज़मानत प्रावधान।"

    val testData = com.example.pdf.PdfReportData(
      reportTitle = "दस्तावेज़ समीक्षा रिपोर्ट",
      firText = devanagariRichText,
      includeFirText = true,
      linkedSections = emptyList()
    )

    val result = generator.generateToStream(testData, outputStream)
    assertTrue("PDF generation with rich Devanagari text must succeed", result.success)
    assertNull("No error message on valid Devanagari generation", result.errorMessage)
    assertTrue("Output PDF size must be valid", result.totalBytes > 0)
  }

  @Test
  fun `verify empty sections in report generates valid notice without crashing`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val generator = com.example.pdf.LocalPdfReportGenerator(context)
    val outputStream = java.io.ByteArrayOutputStream()

    val emptySectionData = com.example.pdf.PdfReportData(
      reportTitle = "दस्तावेज़ समीक्षा रिपोर्ट",
      firText = null,
      includeFirText = false,
      linkedSections = emptyList()
    )

    val result = generator.generateToStream(emptySectionData, outputStream)
    assertTrue("Empty section report must generate successfully", result.success)
    assertEquals(1, result.pageCount)
  }

  @Test
  fun `verify viewModel pdf export state and cancellation`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)

    // Verify toggle for FIR text in report
    assertTrue("Default should include FIR text", viewModel.uiState.value.includeFirTextInReport)
    viewModel.setIncludeFirTextInReport(false)
    assertFalse("Should be toggled to false", viewModel.uiState.value.includeFirTextInReport)
    viewModel.setIncludeFirTextInReport(true)
    assertTrue("Should be toggled back to true", viewModel.uiState.value.includeFirTextInReport)

    // Verify cancellation handler
    viewModel.onPdfExportCancelled()
    assertFalse(viewModel.uiState.value.isGeneratingPdf)
    assertNull(viewModel.uiState.value.pdfExportError)
    assertNull(viewModel.uiState.value.pdfExportSuccessMessage)

    // Verify report data helper
    val reportData = viewModel.createPdfReportData()
    assertEquals("दस्तावेज़ समीक्षा रिपोर्ट", reportData.reportTitle)
    assertEquals("एडवोकेट साथी", reportData.appName)
    assertTrue("Must have default linked sections", reportData.linkedSections.isNotEmpty())
  }

  @Test
  fun `verify generate pdf for share creates file and returns uri`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)

    val shareUri = viewModel.generatePdfForShare()
    assertNotNull("Share URI must be created via FileProvider", shareUri)
    assertEquals("content", shareUri?.scheme)
    assertTrue("Share URI authority must match app fileprovider", shareUri.toString().contains("fileprovider"))
    assertFalse("Generation flag must reset after completion", viewModel.uiState.value.isGeneratingPdf)
    assertTrue("Page count must be recorded", viewModel.uiState.value.pdfLastPageCount >= 1)
  }

  // =========================================================================
  // Milestone 4 Audit Tests: Legal Verification Status Integrity & PDF Cache
  // =========================================================================

  @Test
  fun `verify default linked sections are strictly NEEDS_REVIEW and not falsely marked verified`() {
    val bns303 = OfficialLegalRepository.getRecordById("bns_sec_303")
    val bns351 = OfficialLegalRepository.getRecordById("bns_sec_351")
    val bnss173 = OfficialLegalRepository.getRecordById("bnss_sec_173")

    assertNotNull("BNS 303 must exist in repository", bns303)
    assertNotNull("BNS 351 must exist in repository", bns351)
    assertNotNull("BNSS 173 must exist in repository", bnss173)

    assertEquals("BNS 303 must have status NEEDS_REVIEW", VerificationStatus.NEEDS_REVIEW, bns303?.verificationStatus)
    assertEquals("BNS 351 must have status NEEDS_REVIEW", VerificationStatus.NEEDS_REVIEW, bns351?.verificationStatus)
    assertEquals("BNSS 173 must have status NEEDS_REVIEW", VerificationStatus.NEEDS_REVIEW, bnss173?.verificationStatus)

    assertFalse("BNS 303 must not report officially verified", bns303?.verificationStatus?.isOfficiallyVerified == true)
    assertFalse("BNS 351 must not report officially verified", bns351?.verificationStatus?.isOfficiallyVerified == true)
    assertFalse("BNSS 173 must not report officially verified", bnss173?.verificationStatus?.isOfficiallyVerified == true)

    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)
    val linked = viewModel.uiState.value.linkedReportSections

    assertEquals(3, linked.size)
    linked.forEach { record ->
      assertEquals(
        "Linked section ${record.recordId} in default ViewModel state must be NEEDS_REVIEW",
        VerificationStatus.NEEDS_REVIEW,
        record.verificationStatus
      )
    }
  }

  @Test
  fun `verify pdf cache cleanup removes stale files`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val generator = com.example.pdf.LocalPdfReportGenerator(context)
    val reportsDir = java.io.File(context.cacheDir, "reports")
    reportsDir.mkdirs()

    // Create 7 dummy files
    for (i in 1..7) {
      val f = java.io.File(reportsDir, "test_report_$i.pdf")
      f.writeText("sample pdf data $i")
    }
    assertTrue("At least 7 files created", (reportsDir.listFiles()?.size ?: 0) >= 7)

    // Run cleanup keeping at most 3 files
    generator.cleanupStaleReports(reportsDir = reportsDir, maxAgeMillis = 0L, maxRetainedFiles = 3)
    val remainingFiles = reportsDir.listFiles() ?: emptyArray()
    assertTrue("Cleanup must reduce files to at most 3", remainingFiles.size <= 3)
  }

  @Test
  fun `verify saf cancellation does not leave misleading success or error`() {
    val app = ApplicationProvider.getApplicationContext<android.app.Application>()
    val viewModel = com.example.viewmodel.AdvocateViewModel(app)

    viewModel.onPdfExportCancelled()
    assertFalse(viewModel.uiState.value.isGeneratingPdf)
    assertNull(viewModel.uiState.value.pdfExportSuccessMessage)
    assertNull(viewModel.uiState.value.pdfExportError)
  }
}


