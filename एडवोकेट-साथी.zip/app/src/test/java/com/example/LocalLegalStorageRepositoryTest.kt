package com.example

import com.example.data.OfficialLegalRepository
import com.example.data.importer.ImportResult
import com.example.data.store.LocalLegalRecordStore
import com.example.data.store.LocalStoreCorruptedException
import com.example.model.CommencementStatus
import com.example.model.CrossReferenceType
import com.example.model.LegalAct
import com.example.model.SectionCrossReference
import com.example.model.StructuredLegalRecord
import com.example.model.VerificationStatus
import com.example.pdf.LocalPdfReportGenerator
import com.example.pdf.PdfReportData
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.RuntimeEnvironment
import org.robolectric.annotation.Config
import java.io.File
import java.io.FileOutputStream

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LocalLegalStorageRepositoryTest {

    @get:Rule
    val tempFolder = TemporaryFolder()

    private lateinit var testStorageFile: File
    private lateinit var testStore: LocalLegalRecordStore

    private val sampleValidImportJson = """
    {
      "formatVersion": "1.0",
      "targetApplication": "Advocate Sathi Android (एडवोकेट साथी)",
      "exportTimestamp": "2026-10-27T18:00:00.000Z",
      "totalRecords": 2,
      "filterApplied": "ALL",
      "records": [
        {
          "recordId": "bns_sec_304",
          "act": "BNS",
          "officialActTitle": "The Bharatiya Nyaya Sanhita, 2023",
          "shortName": "BNS, 2023",
          "actYear": 2023,
          "sectionNumber": "304",
          "officialHeading": "Snatching",
          "officialHeadingHindi": "झपटमारी (Snatching)",
          "officialTextOrApprovedSummary": "जो कोई चोरी करने के लिए झपटमारी करता है...",
          "keyElements": ["झपटमारी का नया प्रावधान"],
          "bailableStatus": "गैर-जमानती",
          "cognizableStatus": "संज्ञेय",
          "trialCourt": "मजिस्ट्रेट प्रथम वर्ग",
          "commencementStatus": "IN_FORCE",
          "effectiveFrom": "2024-07-01",
          "effectiveTo": null,
          "sourceTitle": "Gazette of India Act No. 45 of 2023",
          "officialSourceUrl": "https://www.indiacode.nic.in",
          "sourcePublicationOrGazetteDate": "2023-12-25",
          "lastVerifiedAt": "2024-10-27",
          "verificationStatus": "NEEDS_REVIEW",
          "crossReferences": [
            {
              "targetAct": "IPC",
              "targetSectionNumber": "379",
              "targetHeading": "Theft",
              "relationshipType": "NEW_PROVISION_NO_PRIOR_EQUIVALENT",
              "applicabilityCaveat": "1 जुलाई 2024 से नवीन अपराध",
              "statutoryAuthorityNote": "BNS में नया प्रावधान"
            }
          ],
          "applicabilityNotes": "झपटमारी का नया विशिष्ट अपराध धारा 304",
          "proceduralCaveat": "सामान्य विधिक जानकारी"
        },
        {
          "recordId": "bns_sec_318",
          "act": "BNS",
          "officialActTitle": "The Bharatiya Nyaya Sanhita, 2023",
          "shortName": "BNS, 2023",
          "actYear": 2023,
          "sectionNumber": "318",
          "officialHeading": "Cheating",
          "officialHeadingHindi": "छल (Cheating)",
          "officialTextOrApprovedSummary": "जो कोई छल करता है...",
          "keyElements": ["छल की नई परिभाषा"],
          "bailableStatus": "जमानती",
          "cognizableStatus": "संज्ञेय",
          "trialCourt": "कोई भी मजिस्ट्रेट",
          "commencementStatus": "IN_FORCE",
          "effectiveFrom": "2024-07-01",
          "effectiveTo": null,
          "sourceTitle": "Gazette of India Act No. 45 of 2023",
          "officialSourceUrl": null,
          "sourcePublicationOrGazetteDate": "2023-12-25",
          "lastVerifiedAt": null,
          "verificationStatus": "DRAFT",
          "crossReferences": [],
          "applicabilityNotes": "IPC 420 का स्थान",
          "proceduralCaveat": "सामान्य विधिक जानकारी"
        }
      ]
    }
    """.trimIndent()

    @Before
    fun setUp() {
        testStorageFile = File(tempFolder.root, "test_imported_records.json")
        testStore = LocalLegalRecordStore(testStorageFile)
        OfficialLegalRepository.clearImportedRecords(testStore)
        OfficialLegalRepository.initialize(testStore)
    }

    @After
    fun tearDown() {
        OfficialLegalRepository.clearImportedRecords(testStore)
    }

    @Test
    fun `test 1 - loading when no imported record file exists returns empty list`() {
        if (testStorageFile.exists()) {
            testStorageFile.delete()
        }
        val records = testStore.loadImportedRecords()
        assertTrue(records.isEmpty())
        assertEquals(OfficialLegalRepository.builtInRecords.size, OfficialLegalRepository.records.size)
    }

    @Test
    fun `test 2 - saving and reloading records with all 24 fields preserved accurately`() {
        val fullRecord = StructuredLegalRecord(
            recordId = "full_record_test",
            act = LegalAct.BNS,
            officialActTitle = "The Bharatiya Nyaya Sanhita, 2023",
            shortName = "BNS, 2023",
            actYear = 2023,
            sectionNumber = "999",
            officialHeading = "Test Heading",
            officialHeadingHindi = "परीक्षण शीर्षक",
            officialTextOrApprovedSummary = "परीक्षण मूल वैधानिक पाठ",
            keyElements = listOf("तत्व 1", "तत्व 2"),
            bailableStatus = "जमानती",
            cognizableStatus = "संज्ञेय",
            trialCourt = "सत्र न्यायालय",
            commencementStatus = CommencementStatus.IN_FORCE,
            effectiveFrom = "2024-07-01",
            effectiveTo = "2030-12-31",
            sourceTitle = "राजपत्र अधिसूचना",
            officialSourceUrl = "https://www.mha.gov.in",
            sourcePublicationOrGazetteDate = "2023-12-25",
            lastVerifiedAt = "2026-10-27",
            verificationStatus = VerificationStatus.VERIFIED,
            crossReferences = listOf(
                SectionCrossReference(
                    targetAct = LegalAct.IPC,
                    targetSectionNumber = "302",
                    targetHeading = "Murder under IPC",
                    relationshipType = CrossReferenceType.CORRESPONDING_PROVISION,
                    applicabilityCaveat = "संक्रमणकालीन नियम",
                    statutoryAuthorityNote = "प्राधिकरण नोट"
                )
            ),
            applicabilityNotes = "प्रयोज्यता नोट",
            proceduralCaveat = "प्रक्रियात्मक सावधानी"
        )

        val saved = testStore.saveImportedRecords(listOf(fullRecord))
        assertTrue(saved)
        assertTrue(testStorageFile.exists())

        val reloaded = testStore.loadImportedRecords()
        assertEquals(1, reloaded.size)

        val loaded = reloaded[0]
        assertEquals("full_record_test", loaded.recordId)
        assertEquals(LegalAct.BNS, loaded.act)
        assertEquals("The Bharatiya Nyaya Sanhita, 2023", loaded.officialActTitle)
        assertEquals("BNS, 2023", loaded.shortName)
        assertEquals(2023, loaded.actYear)
        assertEquals("999", loaded.sectionNumber)
        assertEquals("Test Heading", loaded.officialHeading)
        assertEquals("परीक्षण शीर्षक", loaded.officialHeadingHindi)
        assertEquals("परीक्षण मूल वैधानिक पाठ", loaded.officialTextOrApprovedSummary)
        assertEquals(listOf("तत्व 1", "तत्व 2"), loaded.keyElements)
        assertEquals("जमानती", loaded.bailableStatus)
        assertEquals("संज्ञेय", loaded.cognizableStatus)
        assertEquals("सत्र न्यायालय", loaded.trialCourt)
        assertEquals(CommencementStatus.IN_FORCE, loaded.commencementStatus)
        assertEquals("2024-07-01", loaded.effectiveFrom)
        assertEquals("2030-12-31", loaded.effectiveTo)
        assertEquals("राजपत्र अधिसूचना", loaded.sourceTitle)
        assertEquals("https://www.mha.gov.in", loaded.officialSourceUrl)
        assertEquals("2023-12-25", loaded.sourcePublicationOrGazetteDate)
        assertEquals("2026-10-27", loaded.lastVerifiedAt)
        assertEquals(VerificationStatus.VERIFIED, loaded.verificationStatus)
        assertEquals(1, loaded.crossReferences.size)
        assertEquals(LegalAct.IPC, loaded.crossReferences[0].targetAct)
        assertEquals("302", loaded.crossReferences[0].targetSectionNumber)
        assertEquals(CrossReferenceType.CORRESPONDING_PROVISION, loaded.crossReferences[0].relationshipType)
        assertEquals("प्रयोज्यता नोट", loaded.applicabilityNotes)
        assertEquals("प्रक्रियात्मक सावधानी", loaded.proceduralCaveat)
    }

    @Test
    fun `test 3 - persistence across repository reinitialization`() {
        val result = OfficialLegalRepository.importJsonPayload(
            jsonString = sampleValidImportJson,
            allowOverwrite = false,
            storeOverride = testStore
        )
        assertTrue(result is ImportResult.Success)

        // Simulate application restart by re-initializing OfficialLegalRepository with a new store pointing to same file
        val newStoreInstance = LocalLegalRecordStore(testStorageFile)
        OfficialLegalRepository.initialize(newStoreInstance)

        val retrievedRecord = OfficialLegalRepository.getRecordById("bns_sec_304")
        assertNotNull(retrievedRecord)
        assertEquals("304", retrievedRecord?.sectionNumber)
        assertEquals(OfficialLegalRepository.builtInRecords.size + 2, OfficialLegalRepository.records.size)
    }

    @Test
    fun `test 4 - merging built-in and imported records without losing built-in entries`() {
        val builtInCountBefore = OfficialLegalRepository.builtInRecords.size
        OfficialLegalRepository.importJsonPayload(sampleValidImportJson, storeOverride = testStore)

        assertEquals(builtInCountBefore + 2, OfficialLegalRepository.records.size)
        // Verify all built-in records are still intact
        OfficialLegalRepository.builtInRecords.forEach { builtIn ->
            assertNotNull(OfficialLegalRepository.getRecordById(builtIn.recordId))
        }
    }

    @Test
    fun `test 5 - imported records available through search and ID lookup`() {
        OfficialLegalRepository.importJsonPayload(sampleValidImportJson, storeOverride = testStore)

        // 1. Direct getRecordById
        val record304 = OfficialLegalRepository.getRecordById("bns_sec_304")
        assertNotNull(record304)
        assertEquals("Snatching", record304?.officialHeading)

        // 2. searchRecords by query
        val searchResults = OfficialLegalRepository.searchRecords("झपटमारी")
        assertEquals(1, searchResults.size)
        assertEquals("bns_sec_304", searchResults[0].recordId)
    }

    @Test
    fun `test 6 - duplicate IDs within a JSON payload triggers atomic rejection`() {
        val duplicateIdJson = sampleValidImportJson.replace("\"recordId\": \"bns_sec_318\"", "\"recordId\": \"bns_sec_304\"")
        val result = OfficialLegalRepository.importJsonPayload(duplicateIdJson, storeOverride = testStore)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("डुप्लीकेट recordId") })
    }

    @Test
    fun `test 7 - collision with a built-in record is rejected by default`() {
        // bns_sec_1 is a built-in record
        val collisionJson = sampleValidImportJson.replace("\"recordId\": \"bns_sec_304\"", "\"recordId\": \"bns_sec_1\"")
        val result = OfficialLegalRepository.importJsonPayload(collisionJson, allowOverwrite = false, storeOverride = testStore)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("डेटाबेस में पहले से मौजूद") || it.contains("built-in") })
    }

    @Test
    fun `test 8 - re-importing an identical record updates without duplicate entries`() {
        // Initial import
        OfficialLegalRepository.importJsonPayload(sampleValidImportJson, allowOverwrite = false, storeOverride = testStore)
        val countAfterFirst = OfficialLegalRepository.records.size

        // Re-import same payload with allowOverwrite=true
        val result = OfficialLegalRepository.importJsonPayload(sampleValidImportJson, allowOverwrite = true, storeOverride = testStore)
        assertTrue(result is ImportResult.Success)

        // Total count should remain identical (no duplicate entries)
        assertEquals(countAfterFirst, OfficialLegalRepository.records.size)
        val occurrences304 = OfficialLegalRepository.records.count { it.recordId == "bns_sec_304" }
        assertEquals(1, occurrences304)
    }

    @Test
    fun `test 9 - invalid JSON is rejected and storage file remains unchanged`() {
        // Save initial valid state
        OfficialLegalRepository.importJsonPayload(sampleValidImportJson, storeOverride = testStore)
        val sizeBefore = OfficialLegalRepository.records.size

        // Try importing corrupted JSON
        val malformedJson = "{ \"formatVersion\": \"1.0\", \"records\": [ { corrupted... "
        val result = OfficialLegalRepository.importJsonPayload(malformedJson, storeOverride = testStore)

        assertTrue(result is ImportResult.Failure)
        // Ensure repository state and store are untouched
        assertEquals(sizeBefore, OfficialLegalRepository.records.size)
        assertNotNull(OfficialLegalRepository.getRecordById("bns_sec_304"))
    }

    @Test
    fun `test 10 - unknown enum values and commencement statuses are rejected`() {
        val invalidEnumJson = sampleValidImportJson.replace("\"commencementStatus\": \"IN_FORCE\"", "\"commencementStatus\": \"UNKNOWN_STATUS_XYZ\"")
        val result = OfficialLegalRepository.importJsonPayload(invalidEnumJson, storeOverride = testStore)

        assertTrue(result is ImportResult.Failure)
        val failure = result as ImportResult.Failure
        assertTrue(failure.errors.any { it.contains("commencementStatus") })
    }

    @Test
    fun `test 11 - failed validation leaves existing stored data unchanged`() {
        // 1. Initial valid import
        OfficialLegalRepository.importJsonPayload(sampleValidImportJson, storeOverride = testStore)
        val initialImportedCount = OfficialLegalRepository.records.size

        // 2. Attempt invalid import payload
        val invalidPayload = sampleValidImportJson.replace("\"officialActTitle\": \"The Bharatiya Nyaya Sanhita, 2023\"", "\"officialActTitle\": \"\"")
        val result = OfficialLegalRepository.importJsonPayload(invalidPayload, storeOverride = testStore)
        assertTrue(result is ImportResult.Failure)

        // 3. Verify existing records are still present in store and repository
        assertEquals(initialImportedCount, OfficialLegalRepository.records.size)
        assertNotNull(OfficialLegalRepository.getRecordById("bns_sec_304"))
        assertNotNull(OfficialLegalRepository.getRecordById("bns_sec_318"))
    }

    @Test
    fun `test 12 - failed file write does not destroy last valid stored file`() {
        // 1. Write initial valid data
        OfficialLegalRepository.importJsonPayload(sampleValidImportJson, storeOverride = testStore)
        assertTrue(testStorageFile.exists())
        val initialContent = testStorageFile.readText()

        // 2. Attempt save with a store pointing to an invalid directory (forces write exception)
        val invalidDirFile = File("/invalid_directory_path/records.json")
        val invalidStore = LocalLegalRecordStore(invalidDirFile)

        try {
            invalidStore.saveImportedRecords(listOf())
        } catch (e: Exception) {
            // Expected exception
        }

        // 3. Verify original valid file remains completely intact
        assertTrue(testStorageFile.exists())
        assertEquals(initialContent, testStorageFile.readText())
    }

    @Test
    fun `test 13 - corrupted local file is reported via exception and not silently erased`() {
        // Write corrupted string into test file
        val corruptContent = "{ \"version\": 1, \"records\": [ { malformed... "
        FileOutputStream(testStorageFile).use { fos ->
            fos.write(corruptContent.toByteArray(Charsets.UTF_8))
        }

        var exceptionThrown: LocalStoreCorruptedException? = null
        try {
            testStore.loadImportedRecords()
        } catch (e: LocalStoreCorruptedException) {
            exceptionThrown = e
        }

        assertNotNull(exceptionThrown)
        // Critical requirement: original file must NOT be deleted or erased
        assertTrue(testStorageFile.exists())
        assertEquals(corruptContent, testStorageFile.readText())
    }

    @Test
    fun `test 14 - DRAFT and NEEDS_REVIEW remain unchanged after import`() {
        val result = OfficialLegalRepository.importJsonPayload(sampleValidImportJson, storeOverride = testStore)
        assertTrue(result is ImportResult.Success)

        val record304 = OfficialLegalRepository.getRecordById("bns_sec_304")
        val record318 = OfficialLegalRepository.getRecordById("bns_sec_318")

        assertNotNull(record304)
        assertNotNull(record318)
        // Must preserve EXACT status without auto-promoting to VERIFIED or PUBLISHED
        assertEquals(VerificationStatus.NEEDS_REVIEW, record304?.verificationStatus)
        assertEquals(VerificationStatus.DRAFT, record318?.verificationStatus)
    }

    @Test
    fun `test 15 - PDF report generation includes imported records when linked`() {
        val context = RuntimeEnvironment.getApplication()
        val pdfGenerator = LocalPdfReportGenerator(context)

        OfficialLegalRepository.importJsonPayload(sampleValidImportJson, storeOverride = testStore)
        val record304 = OfficialLegalRepository.getRecordById("bns_sec_304")
        assertNotNull(record304)

        val reportData = PdfReportData(
            reportTitle = "परीक्षण विधिक रिपोर्ट",
            appName = "एडवोकेट साथी",
            documentName = "test_fir.pdf",
            firText = "झपटमारी की प्राथमिकी धारा 304 BNS",
            linkedSections = listOfNotNull(record304)
        )

        val tempPdfFile = File(tempFolder.root, "generated_test_report.pdf")
        val result = tempPdfFile.outputStream().use { os ->
            pdfGenerator.generateToStream(reportData, os)
        }

        assertTrue(result.success)
        assertTrue(result.pageCount >= 1)
        assertTrue(result.totalBytes > 0L)
        assertTrue(tempPdfFile.length() > 0L)
    }
}
