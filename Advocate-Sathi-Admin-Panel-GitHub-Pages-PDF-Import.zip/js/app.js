// Advocate Sathi - Main Application Controller & UI Binder
// Coordinates tabs, search/filter, CRUD modals, PDF parsing, bulk import, and review queue.

class AdvocateApp {
  constructor() {
    this.store = window.advocateStore;
    this.pdfParser = window.advocatePdfParser;
    this.bulkImporter = window.advocateBulkImporter;
    this.reviewQueue = window.advocateReviewQueue;
    this.backupExport = window.advocateBackupExport;

    this.currentTab = 'dashboard';
    this.editingActCode = null;
    this.editingSectionId = null;
    this.stagedPdfAct = null;
    this.stagedPdfSections = [];

    this.init();
  }

  init() {
    this.bindNavigation();
    this.bindModals();
    this.bindActForm();
    this.bindSectionForm();
    this.bindPdfImport();
    this.bindBulkImport();
    this.bindReviewQueue();
    this.bindBackupExport();
    this.bindSettings();
    this.bindSearchAndFilters();

    this.renderAll();
  }

  // --- TAB NAVIGATION ---
  bindNavigation() {
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const tab = btn.dataset.tab;
        this.switchTab(tab);
      });
    });
  }

  switchTab(tabId) {
    this.currentTab = tabId;

    document.querySelectorAll('.nav-tab-btn').forEach(b => {
      b.classList.toggle('active', b.dataset.tab === tabId);
    });

    document.querySelectorAll('.tab-panel').forEach(p => {
      p.classList.toggle('active', p.id === `tab-${tabId}`);
    });

    // Refresh contents when switching
    if (tabId === 'dashboard') this.renderDashboard();
    else if (tabId === 'act-manager') this.renderActsTable();
    else if (tabId === 'section-manager') this.renderSectionsTable();
    else if (tabId === 'review-queue') this.renderReviewQueue();
    else if (tabId === 'settings-privacy') this.renderAuditLog();
  }

  // --- TOAST NOTIFICATIONS ---
  showToast(message, type = 'info') {
    const container = document.getElementById('toast-container');
    if (!container) return;

    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    let icon = 'ℹ️';
    if (type === 'success') icon = '✅';
    else if (type === 'error') icon = '⚠️';
    else if (type === 'warning') icon = '🔔';

    toast.innerHTML = `<span>${icon}</span> <span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateX(50px)';
      toast.style.transition = 'all 0.3s ease';
      setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  // --- RENDER ALL ---
  renderAll() {
    this.updateStatsCards();
    this.populateActDropdowns();
    this.renderDashboard();
    this.renderActsTable();
    this.renderSectionsTable();
    this.renderReviewQueue();
  }

  // --- STATS & KPI ---
  updateStatsCards() {
    const stats = this.store.getStats();

    const setVal = (id, val) => {
      const el = document.getElementById(id);
      if (el) el.textContent = val;
    };

    setVal('stat-total-acts', stats.totalActs);
    setVal('stat-total-sections', stats.totalSections);
    setVal('stat-drafts', stats.drafts);
    setVal('stat-needs-review', stats.needsReview);
    setVal('stat-verified', stats.verified);
    setVal('stat-published', stats.published);

    // Update tab badges
    const reviewBadge = document.getElementById('tab-badge-review');
    if (reviewBadge) {
      const pendingCount = stats.drafts + stats.needsReview;
      reviewBadge.textContent = pendingCount;
      reviewBadge.style.display = pendingCount > 0 ? 'inline-block' : 'none';
    }
  }

  // --- POPULATE DROPDOWNS ---
  populateActDropdowns() {
    const acts = this.store.getActs();
    const dropdowns = ['filter-sec-act', 'sec-form-act', 'pdf-target-act', 'review-filter-act'];

    dropdowns.forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      const currentVal = el.value;
      const isFilter = id.startsWith('filter') || id.startsWith('review');

      let html = isFilter ? '<option value="">सभी अधिनियम (All Acts)</option>' : '<option value="">अधिनियम चुनें...</option>';
      acts.forEach(a => {
        html += `<option value="${a.code}">${a.hindiShortName} - ${a.englishName}</option>`;
      });

      el.innerHTML = html;
      if (currentVal && acts.some(a => a.code === currentVal)) {
        el.value = currentVal;
      }
    });
  }

  // --- DASHBOARD ---
  renderDashboard() {
    this.updateStatsCards();
    const acts = this.store.getActs();
    const sections = this.store.getSections();
    const tbody = document.getElementById('dashboard-acts-tbody');
    if (!tbody) return;

    if (acts.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:2rem; color:var(--text-muted);">कोई अधिनियम दर्ज नहीं है। ऊपर दिए गए बटन से नया अधिनियम जोड़ें।</td></tr>`;
      return;
    }

    let html = '';
    acts.forEach(act => {
      const actSecs = sections.filter(s => s.actCode === act.code);
      const verifiedCount = actSecs.filter(s => s.verificationStatus === 'VERIFIED' || s.verificationStatus === 'PUBLISHED').length;
      const reviewCount = actSecs.filter(s => s.verificationStatus === 'NEEDS_REVIEW').length;
      const draftCount = actSecs.filter(s => s.verificationStatus === 'DRAFT').length;

      html += `
        <tr>
          <td><span class="badge-tag">${act.code}</span></td>
          <td>
            <strong>${act.hindiFullName}</strong><br>
            <span style="font-size:0.8rem; color:var(--text-muted);">${act.englishName}</span>
          </td>
          <td>${act.year} (${act.actNumber || '—'})</td>
          <td>
            <strong>${actSecs.length}</strong> कुल
            <div style="font-size:0.75rem; color:var(--text-muted);">
              सत्यापित: ${verifiedCount} | समीक्षा: ${reviewCount} | ड्राफ्ट: ${draftCount}
            </div>
          </td>
          <td>
            <span class="status-badge ${act.commencementStatus === 'IN_FORCE' ? 'verified' : 'draft'}">
              ${act.commencementStatus === 'IN_FORCE' ? 'लागू (In Force)' : 'निरसित (Repealed)'}
            </span>
          </td>
          <td>
            <button class="btn btn-sm btn-outline-green" onclick="advocateApp.viewActSections('${act.code}')">धाराएं देखें</button>
            <button class="btn btn-sm btn-secondary" onclick="advocateApp.openActEditModal('${act.code}')">संपादित करें</button>
          </td>
        </tr>
      `;
    });

    tbody.innerHTML = html;
  }

  viewActSections(actCode) {
    document.getElementById('filter-sec-act').value = actCode;
    this.switchTab('section-manager');
    this.renderSectionsTable();
  }

  // --- ACTS TABLE & CRUD ---
  renderActsTable() {
    const acts = this.store.getActs();
    const sections = this.store.getSections();
    const tbody = document.getElementById('acts-table-tbody');
    if (!tbody) return;

    const query = (document.getElementById('search-act-input')?.value || '').toLowerCase();
    const statusFilter = document.getElementById('filter-act-status')?.value || '';

    const filtered = acts.filter(a => {
      const matchQ = !query || 
        a.code.toLowerCase().includes(query) || 
        a.hindiFullName.toLowerCase().includes(query) || 
        a.englishName.toLowerCase().includes(query);
      const matchStatus = !statusFilter || a.commencementStatus === statusFilter;
      return matchQ && matchStatus;
    });

    if (filtered.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:2rem; color:var(--text-muted);">कोई अधिनियम नहीं मिला।</td></tr>`;
      return;
    }

    let html = '';
    filtered.forEach(act => {
      const count = sections.filter(s => s.actCode === act.code).length;
      html += `
        <tr>
          <td><span class="badge-tag">${act.code}</span></td>
          <td><strong>${act.hindiFullName}</strong></td>
          <td>${act.englishName}</td>
          <td>${act.year}</td>
          <td><strong>${count}</strong></td>
          <td>
            <span class="status-badge ${act.commencementStatus === 'IN_FORCE' ? 'verified' : 'draft'}">
              ${act.commencementStatus === 'IN_FORCE' ? 'लागू (In Force)' : 'निरसित (Repealed)'}
            </span>
          </td>
          <td>
            <div style="display:flex; gap:0.4rem;">
              <button class="btn btn-sm btn-secondary" onclick="advocateApp.openActEditModal('${act.code}')">संपादित</button>
              <button class="btn btn-sm btn-danger" onclick="advocateApp.confirmDeleteAct('${act.code}')">हटाएं</button>
            </div>
          </td>
        </tr>
      `;
    });

    tbody.innerHTML = html;
  }

  openActCreateModal() {
    this.editingActCode = null;
    document.getElementById('modal-act-title').textContent = "नया अधिनियम जोड़ें (Add New Act)";
    document.getElementById('act-form').reset();
    document.getElementById('act-form-code').disabled = false;
    document.getElementById('modal-act').classList.add('active');
  }

  openActEditModal(code) {
    const act = this.store.getActByCode(code);
    if (!act) return;

    this.editingActCode = code;
    document.getElementById('modal-act-title').textContent = `अधिनियम संपादित करें: ${act.code}`;
    
    document.getElementById('act-form-code').value = act.code;
    document.getElementById('act-form-code').disabled = true;
    document.getElementById('act-form-hindi-short').value = act.hindiShortName || "";
    document.getElementById('act-form-hindi-full').value = act.hindiFullName || "";
    document.getElementById('act-form-english').value = act.englishName || "";
    document.getElementById('act-form-number').value = act.actNumber || "";
    document.getElementById('act-form-year').value = act.year || "";
    document.getElementById('act-form-enact-date').value = act.enactmentDate || "";
    document.getElementById('act-form-commence-date').value = act.commencementDate || "";
    document.getElementById('act-form-status').value = act.commencementStatus || "IN_FORCE";
    document.getElementById('act-form-repealed').value = act.repealedAct || "";
    document.getElementById('act-form-source-url').value = act.officialSourceUrl || "";
    document.getElementById('act-form-source-title').value = act.sourceTitle || "";
    document.getElementById('act-form-desc').value = act.descriptionHindi || "";

    document.getElementById('modal-act').classList.add('active');
  }

  bindActForm() {
    const form = document.getElementById('act-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      try {
        const actData = {
          code: document.getElementById('act-form-code').value,
          hindiShortName: document.getElementById('act-form-hindi-short').value,
          hindiFullName: document.getElementById('act-form-hindi-full').value,
          englishName: document.getElementById('act-form-english').value,
          actNumber: document.getElementById('act-form-number').value,
          year: document.getElementById('act-form-year').value,
          enactmentDate: document.getElementById('act-form-enact-date').value,
          commencementDate: document.getElementById('act-form-commence-date').value,
          commencementStatus: document.getElementById('act-form-status').value,
          repealedAct: document.getElementById('act-form-repealed').value,
          officialSourceUrl: document.getElementById('act-form-source-url').value,
          sourceTitle: document.getElementById('act-form-source-title').value,
          descriptionHindi: document.getElementById('act-form-desc').value
        };

        this.store.saveAct(actData, !!this.editingActCode);
        document.getElementById('modal-act').classList.remove('active');
        this.renderAll();
        this.showToast(`अधिनियम '${actData.hindiShortName}' सफलतापूर्वक सुरक्षित किया गया`, 'success');
      } catch (err) {
        alert(err.message);
      }
    });
  }

  confirmDeleteAct(code) {
    const act = this.store.getActByCode(code);
    if (!act) return;

    const sections = this.store.getSections({ actCode: code });
    const msg = `क्या आप वाकई अधिनियम '${act.hindiFullName}' (${code}) को हटाना चाहते हैं?\nचेतावनी: इससे संबंधित ${sections.length} धाराएं भी हटा दी जाएंगी।`;
    if (confirm(msg)) {
      this.store.deleteAct(code);
      this.renderAll();
      this.showToast(`अधिनियम ${code} हटा दिया गया`, 'warning');
    }
  }

  // --- SECTIONS TABLE & CRUD ---
  renderSectionsTable() {
    const actCode = document.getElementById('filter-sec-act')?.value || '';
    const status = document.getElementById('filter-sec-status')?.value || '';
    const query = document.getElementById('search-sec-input')?.value || '';
    const bailable = document.getElementById('filter-sec-bailable')?.value || '';
    const cognizable = document.getElementById('filter-sec-cognizable')?.value || '';

    const sections = this.store.getSections({
      actCode,
      status,
      query,
      bailable,
      cognizable
    });

    const tbody = document.getElementById('sections-table-tbody');
    if (!tbody) return;

    if (sections.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center; padding:2rem; color:var(--text-muted);">कोई धारा नहीं मिली। फ़िल्टर बदलें या नई धारा जोड़ें।</td></tr>`;
      return;
    }

    let html = '';
    sections.forEach(s => {
      const statusClass = s.verificationStatus.toLowerCase();
      const statusLabel = this.getStatusLabel(s.verificationStatus);

      html += `
        <tr>
          <td><strong>${s.sectionNumber}</strong></td>
          <td><span class="badge-tag">${s.actCode}</span></td>
          <td>
            <strong>${s.officialHeadingHindi || s.officialHeading}</strong>
            <div style="font-size:0.8rem; color:var(--text-secondary); max-width:350px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">
              ${s.simpleExplanationHindi || s.officialTextOrApprovedSummary || '—'}
            </div>
          </td>
          <td>
            <span class="status-badge ${statusClass}">${statusLabel}</span>
          </td>
          <td>
            <span style="font-size:0.82rem;">${s.bailableStatus || '—'}</span><br>
            <span style="font-size:0.75rem; color:var(--text-muted);">${s.cognizableStatus || '—'}</span>
          </td>
          <td style="font-size:0.82rem; max-width:180px;">${s.punishmentText || '—'}</td>
          <td>
            <div style="display:flex; gap:0.4rem;">
              <button class="btn btn-sm btn-outline-green" onclick="advocateReviewQueue.openReviewModal('${s.recordId}')">समीक्षा</button>
              <button class="btn btn-sm btn-secondary" onclick="advocateApp.openSectionEditModal('${s.recordId}')">संपादित</button>
              <button class="btn btn-sm btn-danger" onclick="advocateApp.confirmDeleteSection('${s.recordId}')">हटाएं</button>
            </div>
          </td>
        </tr>
      `;
    });

    tbody.innerHTML = html;
  }

  openSectionCreateModal() {
    this.editingSectionId = null;
    document.getElementById('modal-sec-title').textContent = "नई धारा जोड़ें (Add New Section)";
    document.getElementById('section-form').reset();
    
    // Set default act if selected in filter
    const actFilter = document.getElementById('filter-sec-act').value;
    if (actFilter) {
      document.getElementById('sec-form-act').value = actFilter;
    }

    document.getElementById('sec-form-status').value = "DRAFT";
    document.getElementById('modal-section').classList.add('active');
  }

  openSectionEditModal(recordId) {
    const s = this.store.getSectionById(recordId);
    if (!s) return;

    this.editingSectionId = recordId;
    document.getElementById('modal-sec-title').textContent = `धारा संपादित करें: ${s.actCode} धारा ${s.sectionNumber}`;

    document.getElementById('sec-form-act').value = s.actCode;
    document.getElementById('sec-form-number').value = s.sectionNumber;
    document.getElementById('sec-form-heading-hi').value = s.officialHeadingHindi || "";
    document.getElementById('sec-form-heading-en').value = s.officialHeading || "";
    document.getElementById('sec-form-official-text').value = s.officialTextOrApprovedSummary || "";
    document.getElementById('sec-form-plain-hindi').value = s.simpleExplanationHindi || "";
    document.getElementById('sec-form-elements').value = (s.keyElements || []).join('\n');
    document.getElementById('sec-form-punishment').value = s.punishmentText || "";
    document.getElementById('sec-form-bailable').value = s.bailableStatus || "";
    document.getElementById('sec-form-cognizable').value = s.cognizableStatus || "";
    document.getElementById('sec-form-court').value = s.trialCourt || "";
    document.getElementById('sec-form-compoundable').value = s.compoundableStatus || "";
    document.getElementById('sec-form-corr-sec').value = s.correspondingSection || "";
    document.getElementById('sec-form-cross-type').value = s.crossReferenceType || "CORRESPONDING_PROVISION";
    document.getElementById('sec-form-source-title').value = s.sourceTitle || "";
    document.getElementById('sec-form-source-url').value = s.officialSourceUrl || "";
    document.getElementById('sec-form-status').value = s.verificationStatus || "DRAFT";
    document.getElementById('sec-form-notes').value = s.reviewNotes || "";

    document.getElementById('modal-section').classList.add('active');
  }

  bindSectionForm() {
    const form = document.getElementById('section-form');
    if (!form) return;

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      try {
        const secData = {
          recordId: this.editingSectionId,
          actCode: document.getElementById('sec-form-act').value,
          sectionNumber: document.getElementById('sec-form-number').value,
          officialHeadingHindi: document.getElementById('sec-form-heading-hi').value,
          officialHeading: document.getElementById('sec-form-heading-en').value,
          officialTextOrApprovedSummary: document.getElementById('sec-form-official-text').value,
          simpleExplanationHindi: document.getElementById('sec-form-plain-hindi').value,
          keyElements: document.getElementById('sec-form-elements').value.split('\n').filter(x => x.trim()),
          punishmentText: document.getElementById('sec-form-punishment').value,
          bailableStatus: document.getElementById('sec-form-bailable').value,
          cognizableStatus: document.getElementById('sec-form-cognizable').value,
          trialCourt: document.getElementById('sec-form-court').value,
          compoundableStatus: document.getElementById('sec-form-compoundable').value,
          correspondingSection: document.getElementById('sec-form-corr-sec').value,
          crossReferenceType: document.getElementById('sec-form-cross-type').value,
          sourceTitle: document.getElementById('sec-form-source-title').value,
          officialSourceUrl: document.getElementById('sec-form-source-url').value,
          verificationStatus: document.getElementById('sec-form-status').value,
          reviewNotes: document.getElementById('sec-form-notes').value
        };

        this.store.saveSection(secData, !!this.editingSectionId);
        document.getElementById('modal-section').classList.remove('active');
        this.renderAll();
        this.showToast(`धारा ${secData.sectionNumber} सफलतापूर्वक सुरक्षित की गई`, 'success');
      } catch (err) {
        alert(err.message);
      }
    });
  }

  confirmDeleteSection(recordId) {
    const s = this.store.getSectionById(recordId);
    if (!s) return;

    if (confirm(`क्या आप वाकई ${s.actCode} धारा ${s.sectionNumber} को हटाना चाहते हैं?`)) {
      this.store.deleteSection(recordId);
      this.renderAll();
      this.showToast(`धारा ${s.sectionNumber} हटा दी गई`, 'warning');
    }
  }

  // --- PDF IMPORT ---
  bindPdfImport() {
    const dropzone = document.getElementById('pdf-dropzone');
    const fileInput = document.getElementById('pdf-file-input');
    const progressWrap = document.getElementById('pdf-progress-wrap');
    const progressBar = document.getElementById('pdf-progress-bar');
    const progressStatus = document.getElementById('pdf-progress-status');
    const scannedNotice = document.getElementById('pdf-scanned-notice');

    // Drag & Drop
    if (dropzone && fileInput) {
      dropzone.addEventListener('click', () => fileInput.click());
      dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
      });
      dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));
      dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        if (e.dataTransfer.files && e.dataTransfer.files[0]) {
          this.processPdfFile(e.dataTransfer.files[0]);
        }
      });
      fileInput.addEventListener('change', (e) => {
        if (e.target.files && e.target.files[0]) {
          this.processPdfFile(e.target.files[0]);
        }
      });
    }

    // Official-source PDF URL import (best effort; browser CORS rules may block some sites).
    const officialUrlInput = document.getElementById('official-pdf-url');
    const officialStatus = document.getElementById('official-pdf-status');
    const fetchOfficialBtn = document.getElementById('btn-fetch-official-pdf');
    const openIndiaCodeBtn = document.getElementById('btn-open-india-code');

    if (openIndiaCodeBtn) {
      openIndiaCodeBtn.addEventListener('click', () => {
        window.open('https://www.indiacode.nic.in/', '_blank', 'noopener,noreferrer');
      });
    }

    if (fetchOfficialBtn && officialUrlInput) {
      fetchOfficialBtn.addEventListener('click', async () => {
        const rawUrl = officialUrlInput.value.trim();
        if (!rawUrl) {
          if (officialStatus) officialStatus.textContent = 'पहले आधिकारिक PDF का सीधा URL डालें।';
          officialUrlInput.focus();
          return;
        }

        let url;
        try {
          url = new URL(rawUrl);
          if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('केवल http/https URL स्वीकार है।');
        } catch (err) {
          if (officialStatus) officialStatus.textContent = 'URL सही नहीं है। आधिकारिक वेबसाइट का पूरा https:// लिंक डालें।';
          return;
        }

        fetchOfficialBtn.disabled = true;
        fetchOfficialBtn.textContent = '⏳ PDF प्राप्त हो रही है…';
        if (officialStatus) officialStatus.textContent = 'सरकारी स्रोत से PDF प्राप्त करने की कोशिश हो रही है।';

        try {
          const response = await fetch(url.href, { method: 'GET', mode: 'cors', credentials: 'omit' });
          if (!response.ok) throw new Error('वेबसाइट ने HTTP ' + response.status + ' लौटाया।');
          const blob = await response.blob();
          const looksLikePdf = blob.type.toLowerCase().includes('pdf') ||
            url.pathname.toLowerCase().endsWith('.pdf') ||
            (blob.size > 4 && (await blob.slice(0, 5).text()).startsWith('%PDF-'));
          if (!looksLikePdf) throw new Error('लिंक से PDF फ़ाइल नहीं मिली। कृपया सीधे PDF डाउनलोड लिंक का उपयोग करें।');
          if (blob.size < 1000) throw new Error('प्राप्त फ़ाइल बहुत छोटी है; यह पूरी PDF नहीं लगती।');

          const filenameFromUrl = decodeURIComponent(url.pathname.split('/').pop() || 'official-act.pdf');
          const safeFilename = filenameFromUrl.toLowerCase().endsWith('.pdf') ? filenameFromUrl : 'official-act.pdf';
          const pdfFile = new File([blob], safeFilename, { type: 'application/pdf' });
          if (officialStatus) officialStatus.textContent = 'PDF प्राप्त हुई (' + Math.round(blob.size / 1024) + ' KB)। अब धाराएँ निकाली जा रही हैं…';
          await this.processPdfFile(pdfFile);
          if (officialStatus) officialStatus.textContent = 'PDF पढ़ने की प्रक्रिया पूरी हुई। नीचे निकाली गई धाराएँ देखें; सभी रिकॉर्ड DRAFT रहेंगे।';
        } catch (err) {
          if (officialStatus) {
            officialStatus.textContent = 'इस वेबसाइट ने ब्राउज़र से सीधे PDF लेने की अनुमति नहीं दी या लिंक PDF नहीं है। सुरक्षा कारणों से इसे बायपास नहीं किया जा सकता। नीचे “India Code खोलें” या लिंक खोलकर PDF डाउनलोड करें, फिर PDF अपलोड विकल्प से फ़ाइल चुनें। विवरण: ' + err.message;
          }
        } finally {
          fetchOfficialBtn.disabled = false;
          fetchOfficialBtn.textContent = '🌐 लिंक से PDF लाएँ';
        }
      });
    }

    // Direct text parse button
    const btnParseText = document.getElementById('btn-parse-raw-text');
    if (btnParseText) {
      btnParseText.addEventListener('click', () => {
        const text = document.getElementById('raw-text-input').value;
        const actCode = document.getElementById('raw-text-act-code').value || 'CUSTOM';
        if (!text.trim()) {
          alert("कृपया वैधानिक या राजपत्र टेक्स्ट पेस्ट करें।");
          return;
        }
        this.processExtractedText(text, actCode);
      });
    }

    // Save staged PDF act & sections
    const btnSaveStaged = document.getElementById('btn-save-staged-pdf');
    if (btnSaveStaged) {
      btnSaveStaged.addEventListener('click', () => this.saveStagedPdfData());
    }
  }

  async processPdfFile(file) {
    if (!file.name.toLowerCase().endsWith('.pdf')) {
      alert("कृपया एक वैध PDF फाइल चुनें।");
      return;
    }

    const progressWrap = document.getElementById('pdf-progress-wrap');
    const progressBar = document.getElementById('pdf-progress-bar');
    const progressStatus = document.getElementById('pdf-progress-status');
    const scannedNotice = document.getElementById('pdf-scanned-notice');

    progressWrap.style.display = 'block';
    scannedNotice.style.display = 'none';

    try {
      const result = await this.pdfParser.extractTextFromPdf(file, ({ page, totalPages, percent }) => {
        progressBar.style.width = `${percent}%`;
        progressStatus.textContent = `पृष्ठ ${page} / ${totalPages} से टेक्स्ट निकाला जा रहा है... (${percent}%)`;
      });

      progressWrap.style.display = 'none';

      if (result.isScannedPdf) {
        // Scanned PDF Notice: Explain offline limitation & trigger fallback
        scannedNotice.style.display = 'flex';
        this.showToast("स्कैन्ड इमेज पीडीएफ मिली। कृपया टेक्स्ट पेस्ट विकल्प का उपयोग करें।", "warning");
        return;
      }

      this.processExtractedText(result.fullText);
    } catch (err) {
      progressWrap.style.display = 'none';
      alert("PDF पढ़ने में त्रुटि: " + err.message);
    }
  }

  processExtractedText(text, forcedActCode = "") {
    const meta = this.pdfParser.extractActMetadata(text);
    const actCode = forcedActCode || meta.detectedShortCode || "NEW_ACT";

    this.stagedPdfAct = {
      code: actCode,
      hindiShortName: `${actCode} (${meta.detectedYear})`,
      hindiFullName: meta.detectedTitleHindi || meta.detectedTitleEnglish || `अधिनियम ${actCode}`,
      englishName: meta.detectedTitleEnglish || `The ${actCode} Act`,
      actNumber: meta.detectedActNumber || "",
      year: meta.detectedYear || new Date().getFullYear(),
      enactmentDate: meta.detectedEnactmentDate || "",
      commencementDate: "",
      commencementStatus: "IN_FORCE",
      repealedAct: "",
      sourceTitle: "Imported Official PDF",
      officialSourceUrl: "",
      descriptionHindi: "पीडीएफ से स्वतः आयातित कानूनी अधिनियम।"
    };

    this.stagedPdfSections = this.pdfParser.parseSectionsFromText(text, actCode);

    this.renderStagedPdfPreview();
  }

  renderStagedPdfPreview() {
    const container = document.getElementById('pdf-results-wrap');
    if (!container) return;

    container.style.display = 'block';
    document.getElementById('staged-act-code').value = this.stagedPdfAct.code;
    document.getElementById('staged-act-name-hi').value = this.stagedPdfAct.hindiFullName;
    document.getElementById('staged-act-name-en').value = this.stagedPdfAct.englishName;
    document.getElementById('staged-act-num').value = this.stagedPdfAct.actNumber;
    document.getElementById('staged-sec-count').textContent = this.stagedPdfSections.length;

    const tbody = document.getElementById('staged-sections-tbody');
    let html = '';
    this.stagedPdfSections.forEach((s, idx) => {
      html += `
        <tr>
          <td><input type="text" class="form-control" value="${s.sectionNumber}" onchange="advocateApp.updateStagedSec(${idx}, 'sectionNumber', this.value)" style="width:70px;"></td>
          <td><input type="text" class="form-control" value="${s.officialHeading}" onchange="advocateApp.updateStagedSec(${idx}, 'officialHeading', this.value)"></td>
          <td>
            <textarea class="form-control" rows="2" style="font-size:0.8rem;" onchange="advocateApp.updateStagedSec(${idx}, 'officialTextOrApprovedSummary', this.value)">${s.officialTextOrApprovedSummary}</textarea>
          </td>
          <td><input type="text" class="form-control" value="${s.punishmentText}" onchange="advocateApp.updateStagedSec(${idx}, 'punishmentText', this.value)"></td>
          <td><span class="status-badge draft">DRAFT (प्रारूप)</span></td>
          <td>
            <button class="btn btn-sm btn-danger" onclick="advocateApp.removeStagedSec(${idx})">हटाएं</button>
          </td>
        </tr>
      `;
    });
    tbody.innerHTML = html;
  }

  updateStagedSec(index, field, value) {
    if (this.stagedPdfSections[index]) {
      this.stagedPdfSections[index][field] = value;
    }
  }

  removeStagedSec(index) {
    this.stagedPdfSections.splice(index, 1);
    this.renderStagedPdfPreview();
  }

  saveStagedPdfData() {
    if (!this.stagedPdfAct || this.stagedPdfSections.length === 0) {
      alert("सुरक्षित करने हेतु कोई डेटा उपलब्ध नहीं है।");
      return;
    }

    try {
      const code = document.getElementById('staged-act-code').value.trim().toUpperCase();
      this.stagedPdfAct.code = code;
      this.stagedPdfAct.hindiFullName = document.getElementById('staged-act-name-hi').value.trim();
      this.stagedPdfAct.englishName = document.getElementById('staged-act-name-en').value.trim();
      this.stagedPdfAct.actNumber = document.getElementById('staged-act-num').value.trim();

      // Check if act exists; if not, create it
      const existingAct = this.store.getActByCode(code);
      if (!existingAct) {
        this.store.saveAct(this.stagedPdfAct, false);
      }

      // Save sections strictly as DRAFT
      let saved = 0;
      this.stagedPdfSections.forEach(s => {
        s.actCode = code;
        s.verificationStatus = 'DRAFT';
        this.store.saveSection(s, false);
        saved++;
      });

      this.renderAll();
      this.showToast(`अधिनियम ${code} एवं ${saved} धाराएं प्रारूप (Draft) के रूप में सुरक्षित की गईं`, 'success');
      
      document.getElementById('pdf-results-wrap').style.display = 'none';
      this.stagedPdfAct = null;
      this.stagedPdfSections = [];
      this.switchTab('section-manager');
    } catch (err) {
      alert("सुरक्षित करने में त्रुटि: " + err.message);
    }
  }

  // --- BULK IMPORT ---
  bindBulkImport() {
    const fileInput = document.getElementById('bulk-file-input');
    const btnDownloadCsv = document.getElementById('btn-download-csv-template');
    const btnDownloadJson = document.getElementById('btn-download-json-template');
    const btnCommit = document.getElementById('btn-commit-bulk-import');

    if (btnDownloadCsv) btnDownloadCsv.addEventListener('click', () => this.bulkImporter.downloadCsvTemplate());
    if (btnDownloadJson) btnDownloadJson.addEventListener('click', () => this.bulkImporter.downloadJsonTemplate());

    if (fileInput) {
      fileInput.addEventListener('change', async (e) => {
        if (!e.target.files || !e.target.files[0]) return;
        const file = e.target.files[0];
        const isJson = file.name.toLowerCase().endsWith('.json');
        const isCsv = file.name.toLowerCase().endsWith('.csv');

        if (!isJson && !isCsv) {
          alert("कृपया .csv या .json फाइल चुनें।");
          return;
        }

        try {
          const text = await file.text();
          const rows = isCsv ? this.bulkImporter.parseCsv(text) : this.bulkImporter.parseJson(text);
          const report = this.bulkImporter.validateRecords(rows, this.store);
          this.renderBulkValidationReport(report);
        } catch (err) {
          alert("फाइल पार्स करने में त्रुटि: " + err.message);
        }
      });
    }

    if (btnCommit) {
      btnCommit.addEventListener('click', () => {
        const strategy = document.querySelector('input[name="conflict-strategy"]:checked')?.value || 'skip';
        try {
          const res = this.bulkImporter.commitImport(strategy, this.store);
          this.renderAll();
          this.showToast(`थोक आयात संपन्न: ${res.insertedCount} नए, ${res.updatedCount} अद्यतन, ${res.skippedCount} छोड़े गए`, 'success');
          document.getElementById('bulk-preview-wrap').style.display = 'none';
          document.getElementById('bulk-file-input').value = '';
          this.switchTab('section-manager');
        } catch (err) {
          alert(err.message);
        }
      });
    }
  }

  renderBulkValidationReport(report) {
    const wrap = document.getElementById('bulk-preview-wrap');
    if (!wrap) return;

    wrap.style.display = 'block';
    document.getElementById('bulk-total-rows').textContent = report.total;
    document.getElementById('bulk-valid-rows').textContent = report.validCount;
    document.getElementById('bulk-invalid-rows').textContent = report.invalidCount;
    document.getElementById('bulk-dup-rows').textContent = report.duplicateCount;

    const tbody = document.getElementById('bulk-preview-tbody');
    let html = '';
    const displayList = report.validRows.concat(report.invalidRows).slice(0, 50);

    displayList.forEach(r => {
      const hasErrors = r.errors && r.errors.length > 0;
      const statusBadge = hasErrors 
        ? `<span class="status-badge" style="background:#FEE2E2; color:#DC2626;">अमान्य</span>`
        : (r.isDuplicate 
            ? `<span class="status-badge needs_review">डुप्लीकेट</span>` 
            : `<span class="status-badge verified">वैध</span>`);

      const messages = (r.errors || []).concat(r.warnings || []).join('; ');

      html += `
        <tr style="${hasErrors ? 'background:#FFF5F5;' : ''}">
          <td>${r.rowNumber}</td>
          <td><strong>${r.actCode}</strong></td>
          <td><strong>${r.sectionNumber}</strong></td>
          <td>${r.officialHeadingHindi || r.officialHeading}</td>
          <td>${statusBadge}</td>
          <td style="font-size:0.8rem; color:${hasErrors ? '#DC2626' : 'var(--text-secondary)'};">${messages || '—'}</td>
        </tr>
      `;
    });

    tbody.innerHTML = html;
  }

  // --- REVIEW QUEUE ---
  bindReviewQueue() {
    const filterAct = document.getElementById('review-filter-act');
    if (filterAct) {
      filterAct.addEventListener('change', () => this.renderReviewQueue());
    }

    // Modal action buttons
    document.getElementById('btn-review-to-needs-review')?.addEventListener('click', () => {
      this.reviewQueue.submitTransition('NEEDS_REVIEW');
    });

    document.getElementById('btn-review-verify')?.addEventListener('click', () => {
      this.reviewQueue.submitTransition('VERIFIED');
    });

    document.getElementById('btn-review-publish')?.addEventListener('click', () => {
      this.reviewQueue.submitTransition('PUBLISHED');
    });

    document.getElementById('btn-review-reject')?.addEventListener('click', () => {
      this.reviewQueue.submitTransition('DRAFT');
    });
  }

  renderReviewQueue() {
    const actFilter = document.getElementById('review-filter-act')?.value || '';
    const pending = this.reviewQueue.getPendingItems(actFilter);
    const tbody = document.getElementById('review-queue-tbody');
    if (!tbody) return;

    if (pending.length === 0) {
      tbody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:2.5rem; color:var(--text-muted);">🎉 समीक्षा कतार रिक्त है! कोई लंबित प्रारूप या समीक्षाधीन धारा नहीं है।</td></tr>`;
      return;
    }

    let html = '';
    pending.forEach(s => {
      const statusClass = s.verificationStatus.toLowerCase();
      const statusLabel = this.getStatusLabel(s.verificationStatus);

      // Identify missing parts
      const missing = [];
      if (!s.officialSourceUrl) missing.push("आधिकारिक यूआरएल नहीं");
      if (!s.simpleExplanationHindi) missing.push("सरल व्याख्या नहीं");
      if (!s.punishmentText || s.punishmentText === "प्रावधान के अनुसार") missing.push("सज़ा विवरण अपुष्ट");

      html += `
        <tr>
          <td><span class="badge-tag">${s.actCode}</span> <strong>${s.sectionNumber}</strong></td>
          <td><strong>${s.officialHeadingHindi || s.officialHeading}</strong></td>
          <td><span class="status-badge ${statusClass}">${statusLabel}</span></td>
          <td>
            <span style="font-size:0.82rem; color:${s.officialSourceUrl ? 'var(--court-green)' : '#DC2626'};">
              ${s.sourceTitle || 'स्रोत दर्ज नहीं'}
            </span>
          </td>
          <td>
            ${missing.length > 0 
              ? `<span style="font-size:0.75rem; color:#B45309; background:#FEF3C7; padding:2px 6px; border-radius:4px;">${missing.join(', ')}</span>`
              : `<span style="font-size:0.75rem; color:#059669;">समीक्षा हेतु तैयार</span>`}
          </td>
          <td>
            <button class="btn btn-sm btn-primary" onclick="advocateReviewQueue.openReviewModal('${s.recordId}')">समीक्षा करें</button>
          </td>
        </tr>
      `;
    });

    tbody.innerHTML = html;
  }

  // --- BACKUP & EXPORT ---
  bindBackupExport() {
    document.getElementById('btn-download-full-backup')?.addEventListener('click', () => {
      this.backupExport.downloadFullBackup();
      this.showToast("पूर्ण बैकअप फाइल डाउनलोड की गई", "success");
    });

    const restoreInput = document.getElementById('restore-file-input');
    if (restoreInput) {
      restoreInput.addEventListener('change', async (e) => {
        if (!e.target.files || !e.target.files[0]) return;
        const file = e.target.files[0];
        if (confirm(`क्या आप वाकई बैकअप फाइल '${file.name}' से डेटा पुनर्स्थापित करना चाहते हैं? वर्तमान डेटा बदल दिया जाएगा।`)) {
          try {
            const res = await this.backupExport.restoreBackupFromFile(file);
            this.renderAll();
            this.showToast(`डेटा पुनर्स्थापित: ${res.actsCount} अधिनियम, ${res.sectionsCount} धाराएं`, "success");
          } catch (err) {
            alert(err.message);
          }
        }
      });
    }

    document.getElementById('btn-export-android-verified')?.addEventListener('click', () => {
      this.backupExport.exportForAndroid(true);
      this.showToast("सत्यापित धाराओं की JSON फाइल डाउनलोड की गई", "success");
    });

    document.getElementById('btn-export-android-all')?.addEventListener('click', () => {
      this.backupExport.exportForAndroid(false);
      this.showToast("सभी धाराओं की JSON फाइल डाउनलोड की गई", "success");
    });

    document.getElementById('btn-export-csv-all')?.addEventListener('click', () => {
      this.backupExport.exportSectionsCsv();
      this.showToast("धाराओं की CSV फाइल डाउनलोड की गई", "success");
    });
  }

  // --- SETTINGS & AUDIT ---
  bindSettings() {
    document.getElementById('btn-reset-seed')?.addEventListener('click', () => {
      if (confirm("क्या आप डेटाबेस को प्रारंभिक आधिकारिक रिकॉर्ड (BNS, BNSS, BSA, IPC, CrPC) पर रीसेट करना चाहते हैं?")) {
        this.store.resetToSeedData();
        this.renderAll();
        this.showToast("डेटाबेस रीसेट किया गया", "success");
      }
    });

    document.getElementById('btn-clear-all')?.addEventListener('click', () => {
      if (confirm("चेतावनी: यह क्रिया सभी अधिनियमों और धाराओं को मिटा देगी। क्या आप निश्चित हैं?") && confirm("अंतिम पुष्टि: सभी डेटा हटा दिया जाए?")) {
        this.store.clearAllData();
        this.renderAll();
        this.showToast("सभी डेटा हटा दिया गया", "warning");
      }
    });
  }

  renderAuditLog() {
    const list = this.store.getAuditLog();
    const tbody = document.getElementById('audit-log-tbody');
    if (!tbody) return;

    if (list.length === 0) {
      tbody.innerHTML = `<tr><td colspan="3" style="text-align:center; padding:1.5rem; color:var(--text-muted);">कोई ऑडिट गतिविधि दर्ज नहीं है।</td></tr>`;
      return;
    }

    let html = '';
    list.forEach(a => {
      const time = new Date(a.timestamp).toLocaleString('hi-IN');
      html += `
        <tr>
          <td style="font-size:0.8rem; color:var(--text-muted);">${time}</td>
          <td><span class="badge-tag">${a.type}</span></td>
          <td>${a.description}</td>
        </tr>
      `;
    });
    tbody.innerHTML = html;
  }

  // --- SEARCH & FILTERS ---
  bindSearchAndFilters() {
    document.getElementById('search-act-input')?.addEventListener('input', () => this.renderActsTable());
    document.getElementById('filter-act-status')?.addEventListener('change', () => this.renderActsTable());

    const secInputs = ['filter-sec-act', 'filter-sec-status', 'search-sec-input', 'filter-sec-bailable', 'filter-sec-cognizable'];
    secInputs.forEach(id => {
      document.getElementById(id)?.addEventListener('input', () => this.renderSectionsTable());
      document.getElementById(id)?.addEventListener('change', () => this.renderSectionsTable());
    });
  }

  // --- MODALS CLOSE BINDING ---
  bindModals() {
    document.querySelectorAll('.modal-close-btn, .modal-cancel-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
      });
    });

    // Close on overlay backdrop click
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) {
          overlay.classList.remove('active');
        }
      });
    });
  }

  getStatusLabel(status) {
    switch (status) {
      case 'DRAFT': return 'प्रारूप (Draft)';
      case 'NEEDS_REVIEW': return 'समीक्षाधीन (Needs Review)';
      case 'VERIFIED': return 'सत्यापित (Verified)';
      case 'PUBLISHED': return 'प्रकाशित (Published)';
      default: return status || 'अज्ञात';
    }
  }
}

// Global initialization
window.addEventListener('DOMContentLoaded', () => {
  window.advocateApp = new AdvocateApp();
});
